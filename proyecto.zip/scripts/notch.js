// Pantalla completa real en Android, incluyendo la zona del notch. Se ejecuta solo al hacer cap add/sync.
const fs=require('fs'),path=require('path');
// Bloquea la orientación en horizontal en el AndroidManifest.xml (idempotente).
const man='android/app/src/main/AndroidManifest.xml';
if(fs.existsSync(man)){let m=fs.readFileSync(man,'utf8');
  if(/screenOrientation=/.test(m))m=m.replace(/android:screenOrientation="[^"]*"/,'android:screenOrientation="sensorLandscape"');
  else m=m.replace(/<activity\b/,'<activity android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(man,m);console.log('orientacion: horizontal bloqueada')}
const root='android/app/src/main/java';
if(!fs.existsSync(root))process.exit(0);
const find=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?find(path.join(d,e.name)):[path.join(d,e.name)]);
const file=find(root).find(f=>f.endsWith('MainActivity.java'));
const pkg=fs.readFileSync(file,'utf8').match(/package\s+([\w.]+);/)[1];
fs.writeFileSync(file,`package ${pkg};

import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams p = getWindow().getAttributes();
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(p);
        }
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
`);
console.log('notch: MainActivity actualizado');
