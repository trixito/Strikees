# Iconos de Android sin sharp: genera los mipmap desde assets/icon-only.png con Pillow
import os
from PIL import Image, ImageDraw
SRC=Image.open('assets/icon-only.png').convert('RGBA')
RES='android/app/src/main/res'
D={'mdpi':(48,108),'hdpi':(72,162),'xhdpi':(96,216),'xxhdpi':(144,324),'xxxhdpi':(192,432)}
for d,(a,f) in D.items():
    p=os.path.join(RES,'mipmap-'+d)
    if not os.path.isdir(p): continue
    SRC.resize((a,a),Image.LANCZOS).save(os.path.join(p,'ic_launcher.png'))
    r=SRC.resize((a,a),Image.LANCZOS);m=Image.new('L',(a,a),0);ImageDraw.Draw(m).ellipse((0,0,a-1,a-1),fill=255)
    o=Image.new('RGBA',(a,a),(0,0,0,0));o.paste(r,(0,0),m);o.save(os.path.join(p,'ic_launcher_round.png'))
    s=int(f*0.62);fg=Image.new('RGBA',(f,f),(0,0,0,0));fg.paste(SRC.resize((s,s),Image.LANCZOS),((f-s)//2,(f-s)//2));fg.save(os.path.join(p,'ic_launcher_foreground.png'))
print('iconos listos')
