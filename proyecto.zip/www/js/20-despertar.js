/* ===== DESPERTAR · cinemática y efectos (estilo Blue Lock Rivals) =====
   - awakeOn() (02-core) llama a awakenStart(): congela el partido, retrato grande con aura, líneas de manga,
     tajo con el nombre del despertar y destello. El despertar empieza al terminar la cinemática.
   - Las habilidades de despertar que usan cin() (05-characters) dibujan un cut-in más corto con el mismo estilo.
   - drawDespertar() se llama desde draw() (05-characters): aura del que está despierto (tú y la IA), viñeta, cinemática,
     destello y temblor de pantalla.
   Sin Math.random en el dibujo: todo es función del tiempo (no altera el azar del partido ni las pruebas). */
(()=>{
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),ease=p=>1-Math.pow(1-clamp(p,0,1),3);
const rnd=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s)};

/* t = título · h = texto corto del HUD · s = frase · c = color principal · c2 = fondo oscuro · fx = tipo de aura */
const AWP={
 Isagi:{t:'METAVISIÓN',h:'METAVISIÓN',s:'Veo el gol antes de que exista',c:'#2fd0ff',c2:'#0a2a7a',fx:'bolt'},
 Bachira:{t:'MONSTER',h:'MONSTER',s:'El monstruo despierta',c:'#ffd21f',c2:'#4a1470',fx:'flame'},
 Nagi:{t:'GENIO',h:'GENIO',s:'El balón me busca a mí',c:'#c36bff',c2:'#240a52',fx:'bolt'},
 Shidou:{t:'DRAGÓN',h:'DRAGÓN',s:'Hambre de gol',c:'#ff5a3d',c2:'#5a0a1a',fx:'flame'},
 Kaiser:{t:'EMPERADOR',h:'EMPERADOR',s:'El campo es mi escenario',c:'#2ff7d0',c2:'#052a3a',fx:'bolt'},
 Loki:{t:'DIOS DE LA VELOCIDAD',h:'GODSPEED',s:'Demasiado lento',c:'#fff36b',c2:'#4a3a00',fx:'speed'},
 'Shidou Repartidor':{t:'NOCHEBUENA',h:'NOCHEBUENA',s:'Entrega especial de Navidad',c:'#ff3b4b',c2:'#0a3a1a',fx:'snow'},
 Trix:{t:'COEXISTENCIA MULTIVERSAL',h:'MULTIVERSO',s:'Todas las realidades, un solo gol',c:'#b86bff',c2:'#1a0a3a',fx:'bolt'}};
const AWD={t:'DESPERTAR',h:'DESPERTAR',s:'Tu ego despierta',c:'#ffcf3a',c2:'#4a1a00',fx:'flame'};
const awProfile=n=>AWP[n]||AWD;

/* ---------- sonido (se suma a SR.sfx del módulo de audio) ---------- */
SR.sfx.awaken=()=>{const{tone,noise}=SR;tone(60,1.3,'sawtooth',.28,420);tone(1200,.5,'square',.08,2400,.55);noise(.6,.3,.45);tone(55,.6,'sine',.4,28,.62);noise(.35,.4,1.3)};
SR.sfx.cutin=()=>{const{tone,noise}=SR;tone(220,.16,'sawtooth',.22,1000);noise(.12,.28)};
SR.sfx.awakenEnd=()=>{SR.tone(700,.5,'triangle',.18,120)};

/* ---------- inicio y extensión del despertar ---------- */
function awakenStart(g){
 const h=human(),n=S.style&&S.style.n,P=awProfile(n);
 g.awm=0;
 g.cin={k:'awaken',n:P.t,sub:P.s,col:P.c,ch:n,t:2.1,d:2.1,fn:()=>{
  const now=performance.now();
  g.aw=15;g.awd=15;g.flash={t0:now,d:450,col:'#fff',a:.85};g.shk={t0:now,d:450,m:7};
  g.fxs.push({t:1.4,x:h.x,y:h.y-95,s:'¡'+P.h+'!'})}};
 SR.sfx.awaken();SR.vib([60,40,120])}
function awakenExtend(g){
 g.aw+=3;g.awd=Math.max(g.awd||15,g.aw);const h=human();
 g.fxs.push({t:1,x:h.x,y:h.y-110,s:'+3 s'})}
function awakenEnd(g){
 g.flash={t0:performance.now(),d:300,col:'#fff',a:.4};
 const h=human();if(h)g.fxs.push({t:1.1,x:h.x,y:h.y-95,s:'Fin del despertar'});SR.sfx.awakenEnd()}
function aiAwakenFx(g,p){
 if(!p._chr&&typeof rivalChr==='function')p._chr=rivalChr(p);
 const P=awProfile(p._chr),now=performance.now();
 g.fxs.push({t:1.4,x:p.x,y:p.y-72,s:'¡'+P.h+'!'});
 (g._sfx=g._sfx||[]).push({kind:'shards',x:p.x,y:p.y-10,col:P.c,t:.5});
 if(!g.flash)g.flash={t0:now,d:220,col:P.c,a:.3};
 g.shk={t0:now,d:250,m:3};SR.sfx.cutin()}

/* ---------- temblor y destello ---------- */
function shake(g,now){
 const s=g.shk;let t='';
 if(s){const k=1-(now-s.t0)/s.d;
  if(k>0)t='translate(-50%,-50%) translate('+((rnd(now)-.5)*2*s.m*k).toFixed(1)+'px,'+((rnd(now+9)-.5)*2*s.m*k).toFixed(1)+'px)';
  else g.shk=null}
 if(cv.style.transform!==t)cv.style.transform=t}
function flash(c,g,now){
 const f=g.flash;if(!f)return;const k=1-(now-f.t0)/f.d;if(k<=0){g.flash=null;return}
 c.save();c.globalAlpha=k*(f.a||.85);c.fillStyle=f.col||'#fff';c.fillRect(0,0,W,H);c.restore()}

/* ---------- aura sobre el jugador despierto (x,y = pies) ---------- */
function aura(c,x,y,P,s,now,seed,dir){
 c.save();c.globalCompositeOperation='lighter';
 const gr=c.createRadialGradient(x,y-26,4,x,y-26,60*s);gr.addColorStop(0,P.c+'88');gr.addColorStop(1,P.c+'00');
 c.fillStyle=gr;c.fillRect(x-70,y-100,140,150);
 c.strokeStyle=P.c;c.globalAlpha=.75;c.lineWidth=2.5+Math.sin(now/90+seed);
 c.beginPath();c.ellipse(x,y,(26+3*Math.sin(now/130+seed))*s,9*s,0,0,7);c.stroke();
 if(P.fx==='flame'){
  for(let i=0;i<9;i++){const ph=(now/650+i/9+seed*.13)%1,px=x+(rnd(i+seed*7)-.5)*30*(1-ph*.4)+Math.sin(now/200+i)*3,py=y-10-ph*84,r=((1-ph)*6+1)*s;
   c.globalAlpha=(1-ph)*.85;c.fillStyle=i%3?P.c:'#fff';c.beginPath();c.ellipse(px,py,r*.8,r*1.6,0,0,7);c.fill()}}
 else if(P.fx==='bolt'){
  const f=Math.floor(now/70);
  for(let k=0;k<3;k++){let px=x+(rnd(f*3+k+seed)-.5)*26,py=y;const pts=[[px,py]];
   for(let j=0;j<4;j++){px+=(rnd(f*7+k*5+j+seed)-.5)*22;py-=16+rnd(f+j+k)*10;pts.push([px,py])}
   for(const[w,col,a]of[[3.4,P.c,.5],[1.4,'#fff',.9]]){c.globalAlpha=a;c.strokeStyle=col;c.lineWidth=w;c.beginPath();pts.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.stroke()}}}
 else if(P.fx==='speed'){
  for(let i=0;i<6;i++){const ly=y-8-i*13,len=26+((i*37+now/6)%34);c.globalAlpha=.55;c.strokeStyle=i%2?P.c:'#fff';c.lineWidth=2;
   c.beginPath();c.moveTo(x-dir*14,ly);c.lineTo(x-dir*(14+len),ly);c.stroke()}}
 else if(P.fx==='snow'){
  c.fillStyle='#fff';
  for(let i=0;i<10;i++){const px=x+(rnd(i+seed)-.5)*50+Math.sin(now/400+i)*4,py=y-90+((now/18+i*37)%100);c.globalAlpha=.8;c.beginPath();c.arc(px,py,1.8,0,7);c.fill()}}
 c.restore()}

/* ---------- cinemática (activación del despertar y cut-ins de habilidades) ---------- */
function portrait(x,y,sc){X=cx;drawChar(x,y,sc,{me:1,dir:1,w:0,suit:SUITS[S.look.s],hair:S.look.h,ch:lookCh()})}
function title(c,s,x,y,maxW,align){
 const sz=clamp(maxW/(s.length*.62),16,60);
 c.save();c.font='italic 900 '+Math.round(sz)+'px sans-serif';c.textAlign=align||'left';c.lineJoin='round';
 c.lineWidth=9;c.strokeStyle='#000';c.strokeText(s,x,y);
 c.fillStyle=c.strokeStyle='#fff';c.lineWidth=2;c.strokeText(s,x,y);c.fillText(s,x,y);c.restore()}
function cine(c,g,now){
 const k=g.cin,p=clamp(1-k.t/k.d,0,1),P=awProfile(k.ch),col=k.col||P.c;
 c.save();
 if(k.k==='awaken'){
  const a1=Math.min(1,p/.08),bar=Math.round(58*ease(p/.12)*(p>.88?(1-p)/.12:1));
  if(p>=.3&&!k._s){k._s=1;g.shk={t0:now,d:500,m:8}}
  c.globalAlpha=a1*.92;let gr=c.createRadialGradient(W*.34,H*.46,20,W*.34,H*.46,W*.8);gr.addColorStop(0,P.c2);gr.addColorStop(1,'#000');
  c.fillStyle=gr;c.fillRect(0,0,W,H);
  /* rayos de manga desde el retrato */
  c.save();c.translate(W*.34,H*.46);c.rotate(now/2600);
  for(let i=0;i<22;i++){const a0=i*Math.PI*2/22,w=Math.PI/22*.55*(.6+rnd(i)*.8);c.fillStyle=i%2?col:'#fff';c.globalAlpha=(i%2?.28:.12)*a1;
   c.beginPath();c.moveTo(0,0);c.arc(0,0,700,a0,a0+w);c.closePath();c.fill()}
  c.restore();
  /* líneas de velocidad */
  if(p>.3){c.strokeStyle='#fff';c.lineWidth=2;
   for(let i=0;i<18;i++){const y=rnd(i)*H,len=80+rnd(i+3)*160,x=((now*(1.4+rnd(i+7))+rnd(i+1)*W*2)%(W+len))-len;c.globalAlpha=.3;c.beginPath();c.moveTo(W-x,y);c.lineTo(W-x-len,y);c.stroke()}}
  /* retrato con aura */
  const pe=ease((p-.08)/.28),px=-160+(293+160)*pe,hy=170;
  c.globalCompositeOperation='lighter';gr=c.createRadialGradient(px-43,hy,10,px-43,hy,230);gr.addColorStop(0,col+'99');gr.addColorStop(1,col+'00');
  c.globalAlpha=pe;c.fillStyle=gr;c.fillRect(0,0,W,H);c.globalCompositeOperation='source-over';
  c.globalAlpha=.35+.65*clamp((p-.26)/.06,0,1);portrait(px,hy+660*.7+Math.sin(now/300)*2,.7);
  /* onda de impacto */
  if(p>.3&&p<.6){const q=(p-.3)/.3;c.globalAlpha=1-q;c.strokeStyle=col;c.lineWidth=8*(1-q)+1;c.beginPath();c.ellipse(293-43,hy,20+q*260,14+q*190,0,0,7);c.stroke()}
  /* tajo con el título */
  const te=ease((p-.34)/.14);
  if(te>0){c.save();c.translate(W*.66,235);c.rotate(-.12);
   c.globalAlpha=.88;c.fillStyle='#000';c.fillRect(250-500*te,-46,500*te,92);
   c.globalAlpha=1;c.fillStyle=col;c.fillRect(250-500*te,-52,500*te,6);c.fillRect(250-500*te,46,500*te,6);
   if(te>.6){c.globalAlpha=clamp((te-.5)*2,0,1);title(c,k.n,244,14,440,'right')}
   if(p>.5){c.globalAlpha=clamp((p-.5)*5,0,1);c.font='italic 800 15px sans-serif';c.textAlign='right';c.fillStyle='#dfe8ff';c.fillText(k.sub||'',244,76)}
   c.restore()}
  /* marca de agua */
  c.globalAlpha=.12*te;c.fillStyle=col;c.font='900 150px sans-serif';c.textAlign='center';c.fillText('覚醒',W*.62,H*.86);
  /* barras de cine y destellos */
  c.globalAlpha=1;c.fillStyle='#000';c.fillRect(0,0,W,bar);c.fillRect(0,H-bar,W,bar);
  if(p<.07){c.globalAlpha=(1-p/.07)*.9;c.fillStyle='#fff';c.fillRect(0,0,W,H)}
  if(p>.86){c.globalAlpha=clamp((p-.86)/.14,0,1)*.95;c.fillStyle='#fff';c.fillRect(0,0,W,H)}
 }else{
  /* cut-in de habilidad: banda diagonal con el retrato */
  const a1=Math.min(1,p/.12),bar=Math.round(40*ease(p/.12)*(p>.88?(1-p)/.12:1)),se=ease(p/.25);
  c.globalAlpha=a1*.55;c.fillStyle='#000';c.fillRect(0,0,W,H);
  c.save();c.beginPath();c.moveTo(-20,150);c.lineTo(W+20,105);c.lineTo(W+20,300);c.lineTo(-20,345);c.closePath();
  c.globalAlpha=a1*.94;let gr=c.createLinearGradient(0,0,W,0);gr.addColorStop(0,'#000');gr.addColorStop(1,P.c2);c.fillStyle=gr;c.fill();c.clip();
  c.strokeStyle='#fff';c.lineWidth=2;
  for(let i=0;i<14;i++){const y=120+rnd(i)*220,len=70+rnd(i+3)*150,x=((now*(1.8+rnd(i+7))+rnd(i+1)*W*2)%(W+len))-len;c.globalAlpha=.28;c.beginPath();c.moveTo(W-x,y);c.lineTo(W-x-len,y);c.stroke()}
  c.globalCompositeOperation='lighter';gr=c.createRadialGradient(W*.72,200,10,W*.72,200,200);gr.addColorStop(0,col+'88');gr.addColorStop(1,col+'00');c.globalAlpha=se;c.fillStyle=gr;c.fillRect(0,0,W,H);c.globalCompositeOperation='source-over';
  c.globalAlpha=se;portrait(W*.72+43+(1-se)*220,200+660*.5,.5);
  c.restore();
  c.globalAlpha=1;c.fillStyle=col;
  c.save();c.translate(0,0);c.rotate(-.075);c.fillRect(-20,262,W+40,5);c.restore();
  c.globalAlpha=se;
  c.font='italic 800 14px sans-serif';c.textAlign='left';c.fillStyle='#dfe8ff';c.fillText((k.ch||'').toUpperCase(),42-(1-se)*60,250);
  title(c,k.n,40-(1-se)*80,296,400,'left');
  c.globalAlpha=1;c.fillStyle='#000';c.fillRect(0,0,W,bar);c.fillRect(0,H-bar,W,bar);
  if(p<.1){c.globalAlpha=(1-p/.1)*.6;c.fillStyle='#fff';c.fillRect(0,0,W,H)}
  if(p>.9){c.globalAlpha=clamp((p-.9)/.1,0,1)*.6;c.fillStyle='#fff';c.fillRect(0,0,W,H)}}
 c.restore()}

/* ---------- punto de entrada desde draw() ---------- */
document.head.appendChild(Object.assign(document.createElement('style'),{textContent:'#game.cine>*:not(#cv){visibility:hidden}'}));   /* sin HUD durante la cinemática */
function drawDespertar(c,g,now){
 shake(g,now);$('game').classList.toggle('cine',!!g.cin);
 const h=human();
 c.save();
 if(g.aw>0&&h){const P=awProfile(S.style&&S.style.n),warn=g.aw<3?.55+.45*Math.sin(now/60):1;
  c.globalAlpha=warn;
  const vg=c.createRadialGradient(W/2,H/2,H*.45,W/2,H/2,W*.75);vg.addColorStop(0,P.c+'00');vg.addColorStop(1,P.c+'44');c.fillStyle=vg;c.fillRect(0,0,W,H);
  aura(c,h.x,h.y+18,P,1,now,0,h.fx<0?-1:1)}
 for(const p of g.ps||[])if(!p.h&&(p._aw||0)>0)aura(c,p.x,p.y+18,awProfile(p._chr),.85,now,p.i+1+p.t*3,p.fx<0?-1:1);
 c.restore();
 if(g.cin)cine(c,g,now);
 flash(c,g,now)}

Object.assign(window,{awProfile,awakenStart,awakenExtend,awakenEnd,aiAwakenFx,drawDespertar});
})();
