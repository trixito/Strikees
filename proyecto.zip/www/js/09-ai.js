/* ai.js · IA con habilidades, marca, presión, pase, apoyo, remate y escalado por dificultad */
const DM=[
 ['Fácil',  .80,.5, .22,.80],
 ['Normal', 1.05,1.0, .65,1.00],
 ['Difícil',1.32,1.5,1.15,1.18],
 ['Pro',    1.58,2.5,1.75,1.35]
];
const getDIdx=()=>{if(typeof G!=='undefined'&&G&&G.rk&&G.rk.d!=null)return G.rk.d; /* Ranked: la dificultad la marca tu rango */
 return Math.max(0,Math.min(DM.length-1,S.diff==null?1:S.diff))};
const CM=()=>DM[getDIdx()][2];

/* ---- habilidades de los rivales ----
   atk = remate/ataque (con balón cerca de la portería) · evd = regate/escape (presionado) · def = robo/defensa (rival con balón cerca)
   Las pesadas avisan 0.4 s antes (círculo rojo + "⚠ nombre"): si las barres a tiempo se interrumpen. */
const SKCLS={direct:'atk',fadeaway:'atk',finalshot:'atk',trapshot:'atk',drive:'atk',bigbang:'atk',kimpact:'atk',magnus:'atk',header:'atk',xbomb:'atk',xsleigh:'atk',godspeed:'atk',trance:'atk',
 nutmeg:'evd',kdribble:'evd',route:'evd',fakevolley:'evd',accel:'evd',tooslow:'evd',xpress:'evd',steal:'def',trap:'def'};
const SKHEAVY=new Set(['direct','finalshot','trapshot','drive','bigbang','kimpact','magnus','xbomb','xsleigh','godspeed']);
const aiSay=(p,s)=>{if(G&&G.fxs)G.fxs.push({t:1,x:p.x,y:p.y-72,s})};
function aiSkillId(p,i){const C=window.CHR;if(!C)return null;if(!p._chr){const n=Object.keys(C);p._chr=window.rivalChr?window.rivalChr(p):n[(p.i+(p.t||0)*2)%n.length]}
 const ch=C[p._chr];return ch?((i===2&&ch.awk&&(p._aw||0)>0)?ch.awk:ch.sk[i]):null}

function aiAbilities(p,g,b,opp,dt,dIdx,skMult){
 if(typeof window.aiCastSkill!=='function')return;
 if(typeof window.aiTickExtra==='function')window.aiTickExtra(p,g,dt);
 if(p._pend||p.fall>0||g.cin)return;
 const now=performance.now(),aw=(p._aw||0)>0;

 /* despertar: no al empezar, y avisa en pantalla */
 if(!aw&&now>(g._aiN||0)&&(g.sc[0]+g.sc[1]>0||g.time<40)&&Math.random()<dt*[0,.06,.22,.48][dIdx]*skMult){
  p._aw=7+dIdx*2;p._gs=1+Math.floor(dIdx/2);aiAwakenFx(g,p);g._aiN=now+900;return}

 /* una habilidad rival a la vez y con respiro entre ellas */
 if(now<(g._aiN||0)||Math.random()>dt*2.4*skMult)return;

 const hasB=b.o===p,oppB=!!b.o&&b.o.t!==p.t,freeB=!b.o,gx=p.t?0:W;
 const dG=Math.abs(gx-p.x),dB=Math.hypot(b.x-p.x,b.y-p.y),dC=oppB?Math.hypot(b.o.x-p.x,b.o.y-p.y):999;
 let dO=999;for(const q of opp)if(q.fall<=0)dO=Math.min(dO,Math.hypot(q.x-p.x,q.y-p.y));
 const ok={atk:(hasB&&dG<300)||(aw&&(hasB||dB<185)),evd:(hasB&&dO<125)||(oppB&&dC<150)||(aw&&hasB),def:(oppB&&dC<130)||(freeB&&dB<150)};
 if(p.role==='DEF'&&!aw)ok.atk=false;                 /* el defensa no gasta habilidades de remate (salvo despierto) */
 if(p.role==='DEF'&&oppB&&dC<170)ok.def=true;            /* …pero sí corta y roba cerca de su área */
 if(p.role==='DEL'&&!aw)ok.def=ok.def&&oppB&&dC<110;      /* el delantero solo roba si lo tiene encima */
 const order=aw?[2,0,1]:[1,0].sort(()=>Math.random()-.5);
 for(const i of order){const c=SKCLS[aiSkillId(p,i)]||'evd';if(!ok[c])continue;
  if(window.aiCastSkill(p,i,skMult)){g._aiN=now+1100/Math.max(.5,skMult);return}}
}

/* ---------- posiciones y roles ----------
   3v3: DEF · MED · DEL (según su ranura 0/1/2) · 2v2: DEF · DEL · 1v1: MED.
   Cada rol tiene su zona (u = progreso: 0 = su portería, 1 = la portería rival) y su manera de apoyar, defender y jugar con balón:
   DEF  cierra y marca por detrás del atacante rival más adelantado, despeja y reparte; casi no remata.
   MED  corta líneas de pase, apoya en diagonal y reparte hacia el delantero; remata desde media distancia.
   DEL  se desmarca al espacio / segundo palo, presiona alto y es el que más remata. */
const ROLES={1:['MED'],2:['DEF','DEL'],3:['DEF','MED','DEL']};
const RZ={DEF:{a:[.09,.40],d:[.07,.34]},MED:{a:[.26,.72],d:[.20,.56]},DEL:{a:[.50,.90],d:[.38,.66]}};
const PASSR={DEF:2.4,MED:1.5,DEL:.5},SPR={DEF:.98,MED:1,DEL:1.04},HX={DEF:.14,MED:.31,DEL:.43};
const roleOf=(g,p)=>{const n=g.ps.filter(q=>q.t===p.t).length;return(ROLES[n]||ROLES[3])[p.i]||'MED'};
window.aiRoles=ROLES;

function aiTick(p,g,b,dt){
 const t=p.t,lv=g.lvl,atk=t?-1:1,gx=t?0:W,og=t?W:0,role=p.role||(p.role=roleOf(g,p)),mates=g.ps.filter(q=>q.t==t&&q!==p),opp=g.ps.filter(q=>q.t!=t);
 const dist=(a,c)=>Math.hypot(a.x-c.x,a.y-c.y),cl=(v,a,c)=>Math.max(a,Math.min(c,v));
 const X=u=>t?W*(1-u):W*u,U=x=>t?1-x/W:x/W;                                  /* progreso <-> x */
 const dIdx=getDIdx(),[,,,skMult,statMult]=DM[dIdx];
 const base=(t?178:166)*lv*statMult*SPR[role];let tx=p.x,ty=p.y,sp=base,slow=false;
 const ref=b.o||b,team=g.ps.filter(q=>q.t==t).sort((a,c)=>dist(a,ref)-dist(c,ref)),rank=team.indexOf(p);
 const k=g.kp&&g.kp[t?0:1],ub=U(b.x);
 const inZone=(r,u,m)=>{const z=RZ[r][m];return u>=z[0]-.04&&u<=z[1]+.04};
 /* quién (de la IA de mi equipo) va a por un punto: el más cercano, con penalización si queda fuera de su zona */
 const pick=(pt,u,m)=>{let best=null,bs=1e9;for(const q of g.ps){if(q.t!=t||q.h||q.fall>0)continue;const s=dist(q,pt)+(inZone(q.role||roleOf(g,q),u,m)?0:200);if(s<bs){bs=s;best=q}}return best};
 if(b.o===p){
  /* CON BALÓN: avanza esquivando rivales, regatea, despeja/pasa/remata según su rol */
  let dx=gx-p.x,dy=H/2-p.y;const m=Math.hypot(dx,dy)||1;dx/=m;dy/=m;let thr=null,td=999;
  for(const q of opp){const d=dist(p,q)||1;if(q.fall<=0&&d<120){const w=(120-d)/120;dx+=(p.x-q.x)/d*w*1.8;dy+=(p.y-q.y)/d*w*1.8}if(d<td){td=d;thr=q}}
  if(p.y<50)dy+=.6;if(p.y>H-50)dy-=.6;
  const up=U(p.x),far=role=='DEF'&&up>RZ.DEF.a[1]+.06;                        /* el defensa no se va de viaje */
  if(far){dx*=.4;sp*=.8}
  const m2=Math.hypot(dx,dy)||1;tx=p.x+dx/m2*100;ty=p.y+dy/m2*100;
  if(thr&&td<62&&p.drc<=0&&Math.random()<dt*2.4*lv*(role=='DEF'?.5:1))dribble(p);
  const lane=(ax,ay,bx,by,skip)=>{for(const q of opp){if(q===skip)continue;const lx=bx-ax,ly=by-ay,l2=lx*lx+ly*ly||1,u=cl(((q.x-ax)*lx+(q.y-ay)*ly)/l2,0,1);if(Math.hypot(q.x-(ax+lx*u),q.y-(ay+ly*u))<26)return false}return true};
  const dgx=Math.abs(gx-p.x),shR=role=='DEL'?290+20*lv:role=='MED'?235+20*lv:150+10*lv;
  const pressed=thr&&td<80&&thr.fall<=0;
  /* el jugador pidió el pase (botón Pass sin balón): el compañero con balón se lo da tras un instante de reacción */
  const rq=g.req,hu=mates.find(q=>q.h);
  if(rq&&hu&&!p.h&&p.kc<=0&&dgx>130&&dist(p,hu)>45){const age=performance.now()-rq;
   if(age>1800)g.req=0;else if(age>200&&hu.fall<=0&&(lane(p.x,p.y,hu.x,hu.y)||age>700)){g.req=0;p.kc=.7;kickBall(p,hu.x+hu.vx*.35,hu.y+hu.vy*.35,Math.min(760,320+dist(p,hu)*.9))}}
  if(p.kc<=0&&dgx<shR&&dgx>30){const ky=k?k.y:H/2;const aimY=cl((ky>H/2?GY0+12:GY1-12)+(Math.random()-.5)*(16/lv),GY0+8,GY1-8);
   if(lane(p.x,p.y,gx,aimY)||Math.random()<dt*(role=='DEL'?1.2:.8)){p.kc=.9;kickBall(p,gx,aimY,Math.min(900,600+160*lv))}}
  else if(p.kc<=0&&role=='DEF'&&up<.32&&pressed&&td<85){
   /* despeje del defensa: balón largo al más adelantado (o a la banda lejana) */
   const fw=mates.filter(q=>q.fall<=0).sort((a,c)=>(c.x-a.x)*atk)[0];
   p.kc=.8;kickBall(p,fw?fw.x+fw.vx*.3:X(.8),fw?fw.y+fw.vy*.3:(p.y>H/2?H*.15:H*.85),720)}
  else if(p.kc<=0&&mates.length){let best=null,bs=-1e9;
   for(const q of mates){const d=dist(p,q),prog=(q.x-p.x)*atk;if(d<(role=='DEF'?60:90)||d>(role=='DEF'?460:380)||q.fall>0)continue;if(prog<(pressed?-40:role=='DEF'?10:25))continue;
    let od=999;for(const o of opp)od=Math.min(od,dist(o,q));if(od<65||!lane(p.x,p.y,q.x,q.y))continue;
    const rb=role=='DEL'?0:(q.role=='DEL'?55:q.role=='MED'?25:0),s=prog*.5+od*.8+rb;if(s>bs){bs=s;best=q}}
   if(best&&((pressed&&Math.random()<dt*4)||(Math.random()<dt*PASSR[role]*lv))){p.kc=.7;const d=dist(p,best);kickBall(p,best.x+best.vx*.35,best.y+best.vy*.35,Math.min(760,320+d*.9))}}
 }else if(b.o&&b.o.t==t){
  /* SU EQUIPO TIENE EL BALÓN: cada rol ocupa su espacio */
  const c=b.o,uc=U(c.x),side=c.y>H/2?-1:1;
  if(role=='DEF'){tx=X(cl(uc*.5+.04,RZ.DEF.a[0],RZ.DEF.a[1]));ty=H/2+(c.y-H/2)*.35}                        /* se queda atrás cubriendo */
  else if(role=='MED'){tx=cl(X(cl(uc-.08,RZ.MED.a[0],RZ.MED.a[1])),PR+10,W-PR-10);ty=cl(c.y+side*95,40,H-40)}   /* apoyo en diagonal, por detrás */
  else{tx=X(cl(Math.max(uc+.13,.58),RZ.DEL.a[0],RZ.DEL.a[1]));                                              /* desmarque: lado contrario / segundo palo */
   ty=uc>.62?cl(H/2+(c.y>H/2?-1:1)*52,GY0-10,GY1+10):(c.y>H/2?H*.27:H*.73)}
  for(const q of mates){const d=dist(p,q);if(d<60&&d>1){tx+=(p.x-q.x)/d*30;ty+=(p.y-q.y)/d*30}}
  sp=base*.95;slow=true;
 }else if(b.o){
  /* RIVAL CON BALÓN: presiona quien le toca por zona; los demás marcan según su rol */
  const c=b.o,du=U(c.x),pr=pick(c,du,'d');
  if(pr===p||(!pr&&rank==0)){const d=dist(p,c),sm=(role=='DEF'&&du<.32)?1.5:1;
   if(d>110){tx=c.x+c.vx*.3+Math.sign(og-c.x||1)*30;ty=c.y+c.vy*.3}else{tx=c.x;ty=c.y;sp*=1.08}
   if(p.slc<=0&&p.fall<=0&&p.sl<=0&&p.dr<=0&&c.dr<=0){
    if(d<PR*2+4){if(Math.random()<dt*3*lv*sm){face(p,c.x-p.x,c.y-p.y);slide(p)}}
    else if(d<95&&Math.random()<dt*1.1*lv*sm){face(p,c.x-p.x,c.y-p.y);slide(p)}}
  }else if(role=='DEF'){
   let thr2=null,bd=1e9;for(const q of opp){if(q===c)continue;const s=U(q.x);if(s<bd){bd=s;thr2=q}}              /* atacante rival más cerca de mi portería */
   if(du<.32){const ux=og-c.x,uy=H/2-c.y,m=Math.hypot(ux,uy)||1;tx=c.x+ux/m*70;ty=c.y+uy/m*70}               /* cierra el ángulo de tiro */
   else if(thr2){const ux=og-thr2.x,uy=H/2-thr2.y,m=Math.hypot(ux,uy)||1;tx=thr2.x+ux/m*44;ty=thr2.y+uy/m*44}   /* marca por detrás */
   else{tx=X(.18);ty=H/2}
   slow=true}
  else if(role=='MED'){
   let rcv=null,bs=-1e9;for(const q of opp){if(q===c)continue;const s=-U(q.x)*100-dist(q,c)*.1;if(s>bs){bs=s;rcv=q}}
   if(rcv){tx=(c.x+rcv.x)/2+Math.sign(og-c.x||1)*18;ty=(c.y+rcv.y)/2}else{tx=c.x+Math.sign(og-c.x||1)*90;ty=c.y}  /* corta la línea de pase */
   slow=true}
  else{tx=X(cl(.56,RZ.DEL.d[0],RZ.DEL.d[1]));ty=H/2+(c.y>H/2?-1:1)*110;slow=true}                             /* salida de contraataque */
 }else{
  /* BALÓN SUELTO: va quien le toca por zona; los demás vuelven a su posición de rol */
  const ch=pick(b,ub,'a');
  if(ch===p||(!ch&&rank==0)||(rank==1&&role=='MED'&&dist(p,b)<150)){tx=b.x+b.vx*.22;ty=b.y+b.vy*.22}
  else{const hu=role=='DEF'?cl(ub*.5+.05,.07,.38):role=='MED'?cl(ub-.08,.24,.66):cl(ub+.12,.46,.80);
   tx=X(hu);ty=cl(p.hy+(b.y-H/2)*(role=='DEF'?.4:.3),40,H-40);slow=true}
 }
 let dx=tx-p.x,dy=ty-p.y;const d=Math.hypot(dx,dy);if(d>6){dx/=d;dy/=d;if(slow)sp*=Math.min(1,d/40+.35)}else{dx=dy=0}
 aiAbilities(p,g,b,opp,dt,dIdx,skMult);
 return[dx,dy,sp]
}
/* portero: lee la trayectoria del tiro y cubre el ángulo cuando se acerca un atacante */
/* el portero roba al que entra con el balón pegado (un regate justo a tiempo lo deja pasar) */
function kpSteal(g,dt){const b=g.b,o=b.o;if(!o)return;
 g.kp.forEach((k,i)=>{k.cd=Math.max(0,(k.cd||0)-dt);if(o.t!==(i?0:1)||k.cd>0||o.fall>0)return;
  const dir=i?-1:1,gx=i?W:0,d=Math.hypot(o.x-k.x,o.y-k.y),mouth=o.y>GY0-6&&o.y<GY1+6&&Math.abs(o.x-gx)<30;
  if(d>=62&&!mouth)return;
  if(o.dr>0){k.cd=1.3;g.fxs.push({t:1,x:o.x,y:o.y-60,s:'¡Regate al portero!'});return}
  b.o=null;b.x=k.x+dir*26;b.y=k.y;b.vx=dir*(360+Math.random()*120);b.vy=(Math.random()-.5)*280;k.cd=.9;
  o.stun=.7;o.pk=1;o.vx=o.vy=0;g.fxs.push({t:1,x:k.x,y:k.y-60,s:'¡El portero la roba!'})})}
(()=>{const uK=upd;upd=function(dt){const g0=G;if(g0&&g0.kp&&!g0.end&&g0.pause<=0&&!g0.cin)kpSteal(g0,dt);uK(dt);const g=G;if(!g||!g.kp||g.end||g.pause>0||innerHeight>innerWidth)return;const b=g.b;
 g.kp.forEach((k,i)=>{let ty=null;const dirIn=i?1:-1;
  if(!b.o&&b.vx*dirIn>120){const tt=(k.x-b.x)/b.vx;if(tt>0&&tt<1.2)ty=b.y+b.vy*tt}
  else if(b.o&&b.o.t==(i?0:1)&&Math.abs(b.o.x-k.x)<360)ty=H/2+(b.o.y-H/2)*.4;
  if(ty!==null){ty=Math.max(GY0+12,Math.min(GY1-12,ty));const mx=i?150*g.lvl:115,dy=ty-k.y;k.y+=Math.max(-mx*dt,Math.min(mx*dt,dy))}})}})();
/* selector de dificultad en el panel Campo */
(()=>{const d0=doorP;doorP=function(){d0();const dm=$('dm');if(!dm)return;const lb=document.createElement('b');lb.textContent='Dificultad IA';const row=document.createElement('div');row.className='rw';
 const paint=()=>[...row.children].forEach((e,k)=>e.className=k==(S.diff==null?1:S.diff)?'on':'g');
 DM.forEach((x,k)=>{const bt=document.createElement('button');bt.textContent=x[0]+' ×'+x[2];bt.onclick=()=>{S.diff=k;save();paint()};row.appendChild(bt)});paint();dm.parentNode.insertBefore(lb,dm);dm.parentNode.insertBefore(row,dm)};
 const st0=start;start=function(l,lb){st0(l,lb);const g=G,dIdx=getDIdx();g.lvl*=DM[dIdx][1];g._diffIdx=dIdx;
  for(const p of g.ps){p.role=roleOf(g,p);if(!p.h){const fx=g.ps.filter(q=>q.t===p.t).length==1?.3:HX[p.role];p.hx=(p.t?1-fx:fx)*W;p.x=p.hx}}}})();

/* ---- aviso + interrupción de las habilidades rivales ---- */
(()=>{const cast0=window.aiCastSkill,tick0=window.aiTickExtra;if(!cast0)return;
 window.aiCastSkill=function(p,i,mult){const g=G;if(!g||p._pend)return false;const id=aiSkillId(p,i);if(!id)return cast0(p,i,mult);
  const d=SKD[id]||{};
  if(d.need&&g.b.o!==p)return false;
  if(d.cd>=99&&!((p._aw||0)>0))return false;
  if(p._skcd&&p._skcd[i]>0)return false;
  if(SKHEAVY.has(id)){p._pend={i,m:mult,t:.42,id};aiSay(p,'⚠ '+d.n);return true}
  const ok=cast0(p,i,mult);if(ok)aiSay(p,d.n);return ok};
 window.aiTickExtra=function(p,g,dt){if(tick0)tick0(p,g,dt);const w=p._pend;if(!w)return;
  if(p.fall>0||(SKD[w.id].need&&g.b.o!==p)){p._pend=null;if(p.fall>0)aiSay(p,'¡Interrumpido!');return}
  w.t-=dt;if(w.t<=0){p._pend=null;cast0(p,w.i,w.m)}};
 const dr0=draw;draw=function(){dr0();if(!G||G.end||!G.ps)return;
  for(const p of G.ps){const w=p._pend;if(!w)continue;const k=Math.max(0,w.t/.42);
   cx.save();cx.strokeStyle='#c4372f';cx.lineWidth=3;cx.setLineDash([7,5]);cx.beginPath();cx.ellipse(p.x,p.y+18,16+44*k,7+16*k,0,0,7);cx.stroke();cx.restore()}};
 const st1=start;start=function(l,lb){st1(l,lb);if(G)G._aiN=performance.now()+3500};
})();

/* etiqueta de rol sobre cada jugador de la IA */
(()=>{const dr1=draw;draw=function(){dr1();const g=G;if(!g||g.end||!g.ps||!g.ps[0]||!g.ps[0].role)return;
 cx.save();cx.font='bold 10px sans-serif';cx.textAlign='center';cx.lineJoin='round';cx.lineWidth=3;
 for(const p of g.ps){if(p.h||p.fall>0||(p._pend))continue;cx.globalAlpha=.8;cx.strokeStyle=p.t?'#e8233b':'#1f6bff';cx.fillStyle='#fff';cx.strokeText(p.role,p.x,p.y-44);cx.fillText(p.role,p.x,p.y-44)}
 cx.restore()}})();

/* Pass sin balón = pedir el pase: el compañero que lleva la pelota te la da (ver aiTick) */
function askPass(g,p){const b=g.b;if(!b.o||b.o.t!==0||b.o.h)return false;const n=performance.now();if(g.req&&n-g.req<600)return false;
 g.req=n;g.fxs.push({t:1,x:p.x,y:p.y-60,s:'¡Pásala!'});return true}
(()=>{const dr2=draw;draw=function(){dr2();const g=G,e=document.querySelector('#bps i');if(!e)return;const t=g&&!g.end&&g.ps&&g.b.o!==human()?'Pedir':'Pass';if(e.textContent!==t)e.textContent=t}})();
