/* ai.js · IA nueva: marca, presiona, pasa, apoya y remata a la esquina contraria al portero. Dificultad en el panel Campo. */
const DM=[['Fácil',.85,.5],['Normal',1.1,1],['Difícil',1.35,1.5],['Pro',1.6,2.5]],CM=()=>DM[S.diff==null?1:S.diff][2];
function aiTick(p,g,b,dt){
 const t=p.t,lv=g.lvl,atk=t?-1:1,gx=t?0:W,og=t?W:0,mates=g.ps.filter(q=>q.t==t&&q!==p),opp=g.ps.filter(q=>q.t!=t);
 const dist=(a,c)=>Math.hypot(a.x-c.x,a.y-c.y),cl=(v,a,c)=>Math.max(a,Math.min(c,v));
 const base=(t?178:166)*lv;let tx=p.x,ty=p.y,sp=base,slow=false;
 const ref=b.o||b,team=g.ps.filter(q=>q.t==t).sort((a,c)=>dist(a,ref)-dist(c,ref)),rank=team.indexOf(p);
 const k=g.kp&&g.kp[t?0:1];
 if(b.o===p){
  /* CON BALÓN: avanza esquivando rivales, regatea, pasa si está presionado y remata a la esquina */
  let dx=gx-p.x,dy=H/2-p.y;const m=Math.hypot(dx,dy)||1;dx/=m;dy/=m;let thr=null,td=999;
  for(const q of opp){const d=dist(p,q)||1;if(q.fall<=0&&d<120){const w=(120-d)/120;dx+=(p.x-q.x)/d*w*1.8;dy+=(p.y-q.y)/d*w*1.8}if(d<td){td=d;thr=q}}
  if(p.y<50)dy+=.6;if(p.y>H-50)dy-=.6;const m2=Math.hypot(dx,dy)||1;tx=p.x+dx/m2*100;ty=p.y+dy/m2*100;
  if(thr&&td<62&&p.drc<=0&&Math.random()<dt*2.4*lv)dribble(p);
  const lane=(ax,ay,bx,by,skip)=>{for(const q of opp){if(q===skip)continue;const lx=bx-ax,ly=by-ay,l2=lx*lx+ly*ly||1,u=cl(((q.x-ax)*lx+(q.y-ay)*ly)/l2,0,1);if(Math.hypot(q.x-(ax+lx*u),q.y-(ay+ly*u))<26)return false}return true};
  const dgx=Math.abs(gx-p.x);
  if(p.kc<=0&&dgx<250+20*lv&&dgx>30){const ky=k?k.y:H/2;const aimY=cl((ky>H/2?GY0+12:GY1-12)+(Math.random()-.5)*(16/lv),GY0+8,GY1-8);
   if(lane(p.x,p.y,gx,aimY)||Math.random()<dt*.8){p.kc=.9;kickBall(p,gx,aimY,Math.min(900,600+160*lv))}}
  else if(p.kc<=0&&mates.length){const pressed=thr&&td<80&&thr.fall<=0;let best=null,bs=-1e9;
   for(const q of mates){const d=dist(p,q),prog=(q.x-p.x)*atk;if(d<90||d>380||q.fall>0)continue;if(prog<(pressed?-40:25))continue;
    let od=999;for(const o of opp)od=Math.min(od,dist(o,q));if(od<65||!lane(p.x,p.y,q.x,q.y))continue;const s=prog*.5+od*.8;if(s>bs){bs=s;best=q}}
   if(best&&((pressed&&Math.random()<dt*4)||(Math.random()<dt*.9*lv))){p.kc=.7;const d=dist(p,best);kickBall(p,best.x+best.vx*.35,best.y+best.vy*.35,Math.min(760,320+d*.9))}}
 }else if(b.o&&b.o.t==t){
  /* SU EQUIPO TIENE EL BALÓN: apoyo en espacio libre, uno se queda atrás */
  const c=b.o,side=p.i%2?1:-1;
  if(p.i==0&&mates.length){tx=cl(c.x-atk*150,40,W-40);ty=cl(H/2+(c.y-H/2)*.5,50,H-50)}
  else{tx=cl(c.x+atk*(100+40*(p.i%3)),PR+10,W-PR-10);ty=cl(c.y+side*(90+30*(p.i%2)),40,H-40)}
  for(const q of mates){const d=dist(p,q);if(d<60&&d>1){tx+=(p.x-q.x)/d*30;ty+=(p.y-q.y)/d*30}}
  sp=base*.95;slow=true;
 }else if(b.o){
  /* RIVAL CON BALÓN: el más cercano presiona e intenta robar/barrer, el resto marca por detrás */
  const c=b.o,pressAI=team.filter(q=>!q.h)[0]===p||rank==0;
  if(pressAI){const d=dist(p,c);
   if(d>110){tx=c.x+c.vx*.3+Math.sign(og-c.x||1)*30;ty=c.y+c.vy*.3}else{tx=c.x;ty=c.y;sp*=1.08}
   if(p.slc<=0&&p.fall<=0&&p.sl<=0&&p.dr<=0&&c.dr<=0){
    if(d<PR*2+4){if(Math.random()<dt*3*lv){face(p,c.x-p.x,c.y-p.y);slide(p)}}
    else if(d<95&&Math.random()<dt*1.1*lv){face(p,c.x-p.x,c.y-p.y);slide(p)}}
  }else if(p.i==0&&mates.length){tx=og+(t?-1:1)*(t?W*.16:W*.16);tx=t?W*.84:W*.16;ty=cl(H/2+(c.y-H/2)*.5,50,H-50);slow=true}
  else{let q0=null,bd=1e9;for(const q of opp){if(q===c)continue;const d=dist(p,q);if(d<bd){bd=d;q0=q}}
   if(q0){const ux=og-q0.x,uy=H/2-q0.y,m=Math.hypot(ux,uy)||1;tx=q0.x+ux/m*42;ty=q0.y+uy/m*42}else{tx=c.x+Math.sign(og-c.x||1)*60;ty=c.y}slow=true}
 }else{
  /* BALÓN SUELTO: va el más cercano (y el segundo si está cerca), el resto mantiene la formación */
  if(rank==0||(rank==1&&dist(p,b)<150)){tx=b.x+b.vx*.22;ty=b.y+b.vy*.22}
  else{tx=p.hx+(b.x-W/2)*.35;ty=p.hy+(b.y-H/2)*.3;slow=true}
 }
 let dx=tx-p.x,dy=ty-p.y;const d=Math.hypot(dx,dy);if(d>6){dx/=d;dy/=d;if(slow)sp*=Math.min(1,d/40+.35)}else{dx=dy=0}
 return[dx,dy,sp]}
/* portero: lee la trayectoria del tiro y cubre el ángulo cuando se acerca un atacante */
(()=>{const uK=upd;upd=function(dt){uK(dt);const g=G;if(!g||!g.kp||g.end||g.pause>0||innerHeight>innerWidth)return;const b=g.b;
 g.kp.forEach((k,i)=>{let ty=null;const dirIn=i?1:-1;
  if(!b.o&&b.vx*dirIn>120){const tt=(k.x-b.x)/b.vx;if(tt>0&&tt<1.2)ty=b.y+b.vy*tt}
  else if(b.o&&b.o.t==(i?0:1)&&Math.abs(b.o.x-k.x)<360)ty=H/2+(b.o.y-H/2)*.4;
  if(ty!==null){ty=Math.max(GY0+12,Math.min(GY1-12,ty));const mx=i?150*g.lvl:115,dy=ty-k.y;k.y+=Math.max(-mx*dt,Math.min(mx*dt,dy))}})}})();
/* selector de dificultad en el panel Campo */
(()=>{const d0=doorP;doorP=function(){d0();const dm=$('dm');if(!dm)return;const lb=document.createElement('b');lb.textContent='Dificultad IA';const row=document.createElement('div');row.className='rw';
 const paint=()=>[...row.children].forEach((e,k)=>e.className=k==(S.diff==null?1:S.diff)?'on':'g');
 DM.forEach((x,k)=>{const bt=document.createElement('button');bt.textContent=x[0]+' ×'+x[2];bt.onclick=()=>{S.diff=k;save();paint()};row.appendChild(bt)});paint();dm.parentNode.insertBefore(lb,dm);dm.parentNode.insertBefore(row,dm)};
 const st0=start;start=function(l,lb){st0(l,lb);const g=G;g.lvl*=DM[S.diff==null?1:S.diff][1]}})();
