/* ai.js · IA con habilidades, marca, presión, pase, apoyo, remate y escalado por dificultad */
const DM=[
 ['Fácil',  .80,.5, .22,.80],
 ['Normal', 1.05,1.0, .65,1.00],
 ['Difícil',1.32,1.5,1.15,1.18],
 ['Pro',    1.58,2.5,1.75,1.35]
];
const getDIdx=()=>Math.max(0,Math.min(DM.length-1,S.diff==null?1:S.diff));
const CM=()=>DM[getDIdx()][2];

/* ---- habilidades de los rivales ----
   atk = remate/ataque (con balón cerca de la portería) · evd = regate/escape (presionado) · def = robo/defensa (rival con balón cerca)
   Las pesadas avisan 0.4 s antes (círculo rojo + "⚠ nombre"): si las barres a tiempo se interrumpen. */
const SKCLS={direct:'atk',fadeaway:'atk',finalshot:'atk',trapshot:'atk',drive:'atk',bigbang:'atk',kimpact:'atk',magnus:'atk',header:'atk',xbomb:'atk',xsleigh:'atk',godspeed:'atk',trance:'atk',
 nutmeg:'evd',kdribble:'evd',route:'evd',fakevolley:'evd',accel:'evd',tooslow:'evd',xpress:'evd',steal:'def',trap:'def'};
const SKHEAVY=new Set(['direct','finalshot','trapshot','drive','bigbang','kimpact','magnus','xbomb','xsleigh','godspeed']);
const aiSay=(p,s)=>{if(G&&G.fxs)G.fxs.push({t:1,x:p.x,y:p.y-72,s})};
function aiSkillId(p,i){const C=window.CHR;if(!C)return null;if(!p._chr){const n=Object.keys(C);p._chr=n[(p.i+(p.t||0)*2)%n.length]}
 const ch=C[p._chr];return ch?((i===2&&ch.awk&&(p._aw||0)>0)?ch.awk:ch.sk[i]):null}

function aiAbilities(p,g,b,opp,dt,dIdx,skMult){
 if(typeof window.aiCastSkill!=='function')return;
 if(typeof window.aiTickExtra==='function')window.aiTickExtra(p,g,dt);
 if(p._pend||p.fall>0||g.cin)return;
 const now=performance.now(),aw=(p._aw||0)>0;

 /* despertar: no al empezar, y avisa en pantalla */
 if(!aw&&now>(g._aiN||0)&&(g.sc[0]+g.sc[1]>0||g.time<40)&&Math.random()<dt*[0,.06,.22,.48][dIdx]*skMult){
  p._aw=7+dIdx*2;p._gs=1+Math.floor(dIdx/2);aiSay(p,'¡DESPERTAR!');g._aiN=now+900;return}

 /* una habilidad rival a la vez y con respiro entre ellas */
 if(now<(g._aiN||0)||Math.random()>dt*2.4*skMult)return;

 const hasB=b.o===p,oppB=!!b.o&&b.o.t!==p.t,freeB=!b.o,gx=p.t?0:W;
 const dG=Math.abs(gx-p.x),dB=Math.hypot(b.x-p.x,b.y-p.y),dC=oppB?Math.hypot(b.o.x-p.x,b.o.y-p.y):999;
 let dO=999;for(const q of opp)if(q.fall<=0)dO=Math.min(dO,Math.hypot(q.x-p.x,q.y-p.y));
 const ok={atk:(hasB&&dG<300)||(aw&&(hasB||dB<185)),evd:(hasB&&dO<125)||(oppB&&dC<150)||(aw&&hasB),def:(oppB&&dC<130)||(freeB&&dB<150)};
 const order=aw?[2,0,1]:[1,0].sort(()=>Math.random()-.5);
 for(const i of order){const c=SKCLS[aiSkillId(p,i)]||'evd';if(!ok[c])continue;
  if(window.aiCastSkill(p,i,skMult)){g._aiN=now+1100/Math.max(.5,skMult);return}}
}

function aiTick(p,g,b,dt){
 const t=p.t,lv=g.lvl,atk=t?-1:1,gx=t?0:W,og=t?W:0,mates=g.ps.filter(q=>q.t==t&&q!==p),opp=g.ps.filter(q=>q.t!=t);
 const dist=(a,c)=>Math.hypot(a.x-c.x,a.y-c.y),cl=(v,a,c)=>Math.max(a,Math.min(c,v));
 const dIdx=getDIdx(),[,,,skMult,statMult]=DM[dIdx];
 const base=(t?178:166)*lv*statMult;let tx=p.x,ty=p.y,sp=base,slow=false;
 const ref=b.o||b,team=g.ps.filter(q=>q.t==t).sort((a,c)=>dist(a,ref)-dist(c,ref)),rank=team.indexOf(p);
 const k=g.kp&&g.kp[t?0:1];
 if(b.o===p){
  /* CON BALÓN: avanza esquivando rivales, regatea, pasa si está presionado y remata a la esquina */
  let dx=gx-p.x,dy=H/2-p.y;const m=Math.hypot(dx,dy)||1;dx/=m;dy/=m;let thr=null,td=999;
  for(const q of opp){const d=dist(p,q)||1;if(q.fall<=0&&d<120){const w=(120-d)/120;dx+=(p.x-q.x)/d*w*1.8;dy+=(p.y-q.y)/d*w*1.8}if(d<td){td=d;thr=q}}
  if(p.y<50)dy+=.6;if(p.y>H-50)dy-=.6;const m2=Math.hypot(dx,dy)||1;tx=p.x+dx/m2*100;ty=p.y+dy/m2*100;
  if(thr&&td<62&&p.drc<=0&&Math.random()<dt*2.4*lv)dribble(p);
  const lane=(ax,ay,bx,by,skip)=>{for(const q of opp){if(q===skip)continue;const lx=bx-ax,ly=by-ay,l2=lx*lx+ly*ly||1,u=cl(((q.x-ax)*lx+(q.y-ay)*ly)/l2,0,1);if(Math.hypot(q.x-(ax+lx*u),q.y-(ay+ly*u))<26)return false}return true};
  const dgx=Math.abs(gx-p.x);
  if(p.kc<=0&&dgx<250+20*lv&&dgx>30){const ky=k?k.y:H/2;const aimY=cl((ky>H/2?GY0+12:GY1-12)+(Math.random()-.5)*(16/lv),GY0+8,GY1-8);
   if(lane(p.x,p.y,gx,aimY)||Math.random()<dt*.8){p.kc=.9;kickBall(p,gx,aimY,Math.min(900,600+160*lv))}}
  else if(p.kc<=0&&mates.length){const pressed=thr&&td<80&&thr.fall<=0;let best=null,bs=-1e9;
   for(const q of mates){const d=dist(p,q),prog=(q.x-p.x)*atk;if(d<90||d>380||q.fall>0)continue;if(prog<(pressed?-40:25))continue;
    let od=999;for(const o of opp)od=Math.min(od,dist(o,q));if(od<65||!lane(p.x,p.y,q.x,q.y))continue;const s=prog*.5+od*.8;if(s>bs){bs=s;best=q}}
   if(best&&((pressed&&Math.random()<dt*4)||(Math.random()<dt*.9*lv))){p.kc=.7;const d=dist(p,best);kickBall(p,best.x+best.vx*.35,best.y+best.vy*.35,Math.min(760,320+d*.9))}}
 }else if(b.o&&b.o.t==t){
  /* SU EQUIPO TIENE EL BALÓN: apoyo en espacio libre, uno se queda atrás */
  const c=b.o,side=p.i%2?1:-1;
  if(p.i==0&&mates.length){tx=cl(c.x-atk*150,40,W-40);ty=cl(H/2+(c.y-H/2)*.5,50,H-50)}
  else{tx=cl(c.x+atk*(100+40*(p.i%3)),PR+10,W-PR-10);ty=cl(c.y+side*(90+30*(p.i%2)),40,H-40)}
  for(const q of mates){const d=dist(p,q);if(d<60&&d>1){tx+=(p.x-q.x)/d*30;ty+=(p.y-q.y)/d*30}}
  sp=base*.95;slow=true;
 }else if(b.o){
  /* RIVAL CON BALÓN: el más cercano presiona e intenta robar/barrer, el resto marca por detrás */
  const c=b.o,pressAI=team.filter(q=>!q.h)[0]===p||rank==0;
  if(pressAI){const d=dist(p,c);
   if(d>110){tx=c.x+c.vx*.3+Math.sign(og-c.x||1)*30;ty=c.y+c.vy*.3}else{tx=c.x;ty=c.y;sp*=1.08}
   if(p.slc<=0&&p.fall<=0&&p.sl<=0&&p.dr<=0&&c.dr<=0){
    if(d<PR*2+4){if(Math.random()<dt*3*lv){face(p,c.x-p.x,c.y-p.y);slide(p)}}
    else if(d<95&&Math.random()<dt*1.1*lv){face(p,c.x-p.x,c.y-p.y);slide(p)}}
  }else if(p.i==0&&mates.length){tx=t?W*.84:W*.16;ty=cl(H/2+(c.y-H/2)*.5,50,H-50);slow=true}
  else{let q0=null,bd=1e9;for(const q of opp){if(q===c)continue;const d=dist(p,q);if(d<bd){bd=d;q0=q}}
   if(q0){const ux=og-q0.x,uy=H/2-q0.y,m=Math.hypot(ux,uy)||1;tx=q0.x+ux/m*42;ty=q0.y+uy/m*42}else{tx=c.x+Math.sign(og-c.x||1)*60;ty=c.y}slow=true}
 }else{
  /* BALÓN SUELTO: va el más cercano (y el segundo si está cerca), el resto mantiene la formación */
  if(rank==0||(rank==1&&dist(p,b)<150)){tx=b.x+b.vx*.22;ty=b.y+b.vy*.22}
  else{tx=p.hx+(b.x-W/2)*.35;ty=p.hy+(b.y-H/2)*.3;slow=true}
 }
 let dx=tx-p.x,dy=ty-p.y;const d=Math.hypot(dx,dy);if(d>6){dx/=d;dy/=d;if(slow)sp*=Math.min(1,d/40+.35)}else{dx=dy=0}
 aiAbilities(p,g,b,opp,dt,dIdx,skMult);
 return[dx,dy,sp]
}
/* portero: lee la trayectoria del tiro y cubre el ángulo cuando se acerca un atacante */
/* el portero roba al que entra con el balón pegado (un regate justo a tiempo lo deja pasar) */
function kpSteal(g,dt){const b=g.b,o=b.o;if(!o)return;
 g.kp.forEach((k,i)=>{k.cd=Math.max(0,(k.cd||0)-dt);if(o.t!==(i?0:1)||k.cd>0||o.fall>0)return;
  const dir=i?-1:1,gx=i?W:0,d=Math.hypot(o.x-k.x,o.y-k.y),mouth=o.y>GY0-6&&o.y<GY1+6&&Math.abs(o.x-gx)<30;
  if(d>=62&&!mouth)return;
  if(o.dr>0){k.cd=1.3;g.fxs.push({t:1,x:o.x,y:o.y-60,s:'¡Regate al portero!'});return}
  b.o=null;b.x=k.x+dir*26;b.y=k.y;b.vx=dir*(360+Math.random()*120);b.vy=(Math.random()-.5)*280;k.cd=.9;
  o.stun=.7;o.pk=1;o.vx=o.vy=0;g.fxs.push({t:1,x:k.x,y:k.y-60,s:'¡El portero la roba!'})})}
(()=>{const uK=upd;upd=function(dt){const g0=G;if(g0&&g0.kp&&!g0.end&&g0.pause<=0&&!g0.cin)kpSteal(g0,dt);uK(dt);const g=G;if(!g||!g.kp||g.end||g.pause>0||innerHeight>innerWidth)return;const b=g.b;
 g.kp.forEach((k,i)=>{let ty=null;const dirIn=i?1:-1;
  if(!b.o&&b.vx*dirIn>120){const tt=(k.x-b.x)/b.vx;if(tt>0&&tt<1.2)ty=b.y+b.vy*tt}
  else if(b.o&&b.o.t==(i?0:1)&&Math.abs(b.o.x-k.x)<360)ty=H/2+(b.o.y-H/2)*.4;
  if(ty!==null){ty=Math.max(GY0+12,Math.min(GY1-12,ty));const mx=i?150*g.lvl:115,dy=ty-k.y;k.y+=Math.max(-mx*dt,Math.min(mx*dt,dy))}})}})();
/* selector de dificultad en el panel Campo */
(()=>{const d0=doorP;doorP=function(){d0();const dm=$('dm');if(!dm)return;const lb=document.createElement('b');lb.textContent='Dificultad IA';const row=document.createElement('div');row.className='rw';
 const paint=()=>[...row.children].forEach((e,k)=>e.className=k==(S.diff==null?1:S.diff)?'on':'g');
 DM.forEach((x,k)=>{const bt=document.createElement('button');bt.textContent=x[0]+' ×'+x[2];bt.onclick=()=>{S.diff=k;save();paint()};row.appendChild(bt)});paint();dm.parentNode.insertBefore(lb,dm);dm.parentNode.insertBefore(row,dm)};
 const st0=start;start=function(l,lb){st0(l,lb);const g=G,dIdx=getDIdx();g.lvl*=DM[dIdx][1];g._diffIdx=dIdx}})();

/* ---- aviso + interrupción de las habilidades rivales ---- */
(()=>{const cast0=window.aiCastSkill,tick0=window.aiTickExtra;if(!cast0)return;
 window.aiCastSkill=function(p,i,mult){const g=G;if(!g||p._pend)return false;const id=aiSkillId(p,i);if(!id)return cast0(p,i,mult);
  const d=SKD[id]||{};
  if(d.need&&g.b.o!==p)return false;
  if(d.cd>=99&&!((p._aw||0)>0))return false;
  if(p._skcd&&p._skcd[i]>0)return false;
  if(SKHEAVY.has(id)){p._pend={i,m:mult,t:.42,id};aiSay(p,'⚠ '+d.n);return true}
  const ok=cast0(p,i,mult);if(ok)aiSay(p,d.n);return ok};
 window.aiTickExtra=function(p,g,dt){if(tick0)tick0(p,g,dt);const w=p._pend;if(!w)return;
  if(p.fall>0||(SKD[w.id].need&&g.b.o!==p)){p._pend=null;if(p.fall>0)aiSay(p,'¡Interrumpido!');return}
  w.t-=dt;if(w.t<=0){p._pend=null;cast0(p,w.i,w.m)}};
 const dr0=draw;draw=function(){dr0();if(!G||G.end||!G.ps)return;
  for(const p of G.ps){const w=p._pend;if(!w)continue;const k=Math.max(0,w.t/.42);
   cx.save();cx.strokeStyle='#c4372f';cx.lineWidth=3;cx.setLineDash([7,5]);cx.beginPath();cx.ellipse(p.x,p.y+18,16+44*k,7+16*k,0,0,7);cx.stroke();cx.restore()}};
 const st1=start;start=function(l,lb){st1(l,lb);if(G)G._aiN=performance.now()+3500};
})();
