/* ===== Estilo lápiz (sketch) para la pantalla de Roll (canvas) =====
   Papel con grano, trazo de grafito torcido (siempre igual entre frames), rayado de color y texto a mano. */
const SKP={ink:'#2b2b30',pap:'#f5f0e4',pap2:'#fcf9f1',font:'"Patrick Hand","Segoe Print","Bradley Hand","Chalkboard SE","Comic Sans MS","Coming Soon",casual,sans-serif'};
const skHash=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s)};
function skRgb(h){if(typeof h!=='string'||h[0]!=='#')return null;if(h.length==4)h='#'+h[1]+h[1]+h[2]+h[2]+h[3]+h[3];if(h.length!=7)return null;return[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)]}
const skMix=(h,t,a)=>{const c=skRgb(h),d=skRgb(t);if(!c||!d)return h;return'rgb('+c.map((v,i)=>Math.round(v*(1-a)+d[i]*a)).join(',')+')'};
const skInk=col=>{const c=skRgb(col);if(!c)return SKP.ink;const l=(c[0]*.3+c[1]*.59+c[2]*.11)/255;return l>.86?SKP.ink:skMix(col,'#1c1c22',.45)};

/* rectángulo "dibujado a mano": esquinas y lados con pequeñas desviaciones fijas */
function skPath(c,x,y,w,h,seed,j){j=j==null?1.6:j;const r=Math.min(10,h/3),pts=[];let k=0;
 const push=(px,py)=>{pts.push([px+(skHash(seed+k)-.5)*2*j,py+(skHash(seed+k+.5)-.5)*2*j]);k++};
 const edge=(x0,y0,x1,y1)=>{const n=Math.max(1,Math.round(Math.hypot(x1-x0,y1-y0)/26));for(let i=0;i<n;i++){const t=i/n;push(x0+(x1-x0)*t,y0+(y1-y0)*t)}};
 edge(x+r,y,x+w-r,y);edge(x+w-r,y,x+w,y+r);edge(x+w,y+r,x+w,y+h-r);edge(x+w,y+h-r,x+w-r,y+h);edge(x+w-r,y+h,x+r,y+h);edge(x+r,y+h,x,y+h-r);edge(x,y+h-r,x,y+r);edge(x,y+r,x+r,y);
 const L=pts.length;c.beginPath();c.moveTo((pts[0][0]+pts[L-1][0])/2,(pts[0][1]+pts[L-1][1])/2);
 for(let i=0;i<L;i++){const a=pts[i],b=pts[(i+1)%L];c.quadraticCurveTo(a[0],a[1],(a[0]+b[0])/2,(a[1]+b[1])/2)}c.closePath()}
function skBox(c,x,y,w,h,fill,hatch,o){o=o||{};const sd=Math.round(x*7+y*13+w*3),j=o.j;
 c.save();c.lineJoin=c.lineCap='round';
 skPath(c,x+3,y+4,w,h,sd+9,j);c.strokeStyle='rgba(43,43,48,.35)';c.lineWidth=1.6;c.stroke();            /* contorno fantasma */
 skPath(c,x,y,w,h,sd,j);c.fillStyle=fill;c.fill();
 if(hatch){c.save();skPath(c,x,y,w,h,sd,j);c.clip();c.strokeStyle=hatch;c.globalAlpha=o.ha==null?.5:o.ha;c.lineWidth=1.3;c.beginPath();const g=o.gap||6;for(let i=-h;i<w;i+=g){c.moveTo(x+i,y+h);c.lineTo(x+i+h,y)}c.stroke();c.restore()}
 skPath(c,x,y,w,h,sd,j);c.strokeStyle=SKP.ink;c.lineWidth=o.lw||2.6;c.globalAlpha=.95;c.stroke();          /* trazo principal */
 skPath(c,x-.5,y+.5,w,h,sd+5,(j==null?1.6:j)*1.2);c.globalAlpha=.4;c.lineWidth=1.2;c.stroke();            /* segundo trazo */
 c.restore()}
function skTx(c,s,x,y,sz,col,mw){c.save();c.font='800 '+Math.round(sz*1.02)+'px '+SKP.font;c.textAlign='center';c.lineJoin='round';const ink=skInk(col);c.fillStyle=ink;c.strokeStyle=ink;c.lineWidth=.7;
 if(mw){c.strokeText(s,x,y,mw);c.fillText(s,x,y,mw)}else{c.strokeText(s,x,y);c.fillText(s,x,y)}c.restore()}
function skBtn(c,x,y,w,h,s,bg,sz){const q=skRgb(bg),dark=q&&(q[0]*.3+q[1]*.59+q[2]*.11)/255<.5;       /* Omori: blanco con tinta, o negro invertido si es un botón principal */
 skBox(c,x,y,w,h,dark?'#111':'#fff',null,{lw:2.8});
 if(dark){c.save();c.font='800 '+Math.round(sz*1.02)+'px '+SKP.font;c.textAlign='center';c.fillStyle='#fff';c.fillText(s,x+w/2,y+h/2+sz*.33,w-14);c.restore()}
 else skTx(c,s,x+w/2,y+h/2+sz*.33,sz,'#fff',w-14)}
function crect(c,x,y,w,h,fill,line){skBox(c,x,y,w,h,SKP.pap2,line,{gap:7,ha:.45,j:1.4})}
let skPapC=null;
function skPaper(c){if(!skPapC){const k=document.createElement('canvas');k.width=W;k.height=H;const q=k.getContext('2d');q.fillStyle=SKP.pap;q.fillRect(0,0,W,H);
 const g=q.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,W*.62);g.addColorStop(0,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(120,105,80,.22)');q.fillStyle=g;q.fillRect(0,0,W,H);
 for(let i=0;i<2600;i++){q.fillStyle='rgba(60,50,40,'+(skHash(i)*.07).toFixed(3)+')';q.fillRect(skHash(i+.3)*W,skHash(i+.7)*H,1+skHash(i+.9)*1.5,1)}
 q.strokeStyle='rgba(43,43,48,.07)';q.lineWidth=1.2;for(let i=0;i<40;i++){const px=skHash(i+50)*W,py=skHash(i+80)*H,l=20+skHash(i+9)*40;q.beginPath();q.moveTo(px,py);q.lineTo(px+l,py-l*.7);q.stroke()}
 skPapC=k}c.drawImage(skPapC,0,0)}
function skFloor(c){c.save();c.strokeStyle='rgba(43,43,48,.13)';c.lineWidth=1.1;c.beginPath();for(let i=-200;i<W;i+=9){c.moveTo(i,450);c.lineTo(i+200,250)}c.stroke();c.restore()}
