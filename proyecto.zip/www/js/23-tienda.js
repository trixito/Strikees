/* ===== TIENDA · sobres de Festejos y Cosméticos ===== */
(()=>{
/* [id, nombre, rareza, tipo (head|aura), color] */
const COS=[['gorra','Gorra',0,'head','#e8233b'],['cinta','Cinta de capitán',0,'head','#ffd21f'],['azul','Aura azul',1,'aura','47,208,255'],
 ['cuernos','Cuernos',2,'head','#b3122a'],['verde','Aura tóxica',2,'aura','120,255,60'],['aureola','Aureola',3,'head','#fff3a0'],['oro','Aura dorada',4,'aura','255,200,30'],['corona','Corona',5,'head','#ffd21f']];
const FEST={fuego:1,rayo:2,s67:3,ayano:4},W8=[50,28,14,6,2,1];
const PACKS={fest:{n:'Sobre de Festejos',coins:80,gems:8,items:()=>CEL.filter(e=>e.id in FEST).map(e=>[e.id,e.n,FEST[e.id]])},
 cos:{n:'Sobre de Cosméticos',coins:60,gems:6,items:()=>COS.map(c=>[c[0],c[1],c[2]])}};
S.celOwn=S.celOwn||[...new Set(['clasico',S.cel||'clasico'])];S.cosOwn=S.cosOwn||[];S.cos=S.cos||{};save();

function open(type,cur){const p=PACKS[type];if((S[cur]||0)<p[cur])return{ok:false,msg:cur==='coins'?'Te faltan monedas':'Te faltan gemas'};
 const it=p.items(),tot=it.reduce((a,x)=>a+W8[x[2]],0);let r=Math.random()*tot,x=it[it.length-1];for(const q of it){if(r<W8[q[2]]){x=q;break}r-=W8[q[2]]}
 S[cur]-=p[cur];const own=type==='fest'?S.celOwn:S.cosOwn,dup=own.includes(x[0]),back=10*(x[2]+1);
 if(dup)S.coins+=back;else own.push(x[0]);save();return{ok:true,item:x,dup,back}}

function box(){const d=document.createElement('div');d.className='sr-box';d.style.cssText='position:fixed;inset:0;z-index:20;background:rgba(5,8,20,.92);display:flex;align-items:center;justify-content:center';
 const i=document.createElement('div');i.style.cssText='background:var(--card);color:var(--fg);border-radius:16px;padding:14px;width:min(440px,94vw);max-height:92vh;overflow:auto;touch-action:pan-y;display:flex;flex-direction:column;gap:8px;text-align:center';
 d.appendChild(i);document.body.appendChild(d);
 return{d,clear:h=>i.innerHTML=h,add:(t,cls,fn)=>{const b=document.createElement('button');b.innerHTML=t;b.className=cls||'';b.onclick=fn;i.appendChild(b);return b}}}
const money=()=>'<small>'+S.coins+' '+ico('coin')+' · '+(S.gems||0)+' '+ico('gem')+'</small>';

function shop(msg){const u=box(),go=f=>()=>{u.d.remove();f()};
 u.clear('<b style="font-size:20px">Tienda</b>'+money()+(msg?'<b>'+msg+'</b>':''));
 for(const k in PACKS){const p=PACKS[k];u.add(p.n+' · '+p.coins+' '+ico('coin'),'',go(()=>pack(k,'coins')));u.add(p.n+' · '+p.gems+' '+ico('gem'),'r',go(()=>pack(k,'gems')))}
 u.add('Roll de Flows','',go(()=>SRFlows.open()));
 u.add('Mis festejos','g',go(()=>celP()));u.add('Mis cosméticos','g',go(()=>mine()));u.add('Cerrar','g',go(()=>{}))}

function pack(type,cur){const r=open(type,cur);if(!r.ok)return shop(r.msg);
 const u=box(),col=RC[r.item[2]];
 u.clear('<b>'+PACKS[type].n+'</b>');
 const envelope=u.add('<div style="font-size:40px">✦</div>Toca para abrir','r',()=>{
  u.clear('<div style="border:4px solid '+col+';border-radius:14px;padding:26px 8px;box-shadow:0 0 30px '+col+'"><b style="color:'+col+';text-shadow:0 0 3px #000">'+RN[r.item[2]]+'</b><br><big>'+r.item[1]+'</big><br><small>'+(r.dup?'Repetido: +'+r.back+' monedas':'¡Nuevo!')+'</small></div>'+money());
  if(!r.dup)u.add('Equipar','',()=>{if(type==='fest')S.cel=r.item[0];else{const c=COS.find(c=>c[0]===r.item[0]);S.cos[c[3]]=c[0]}save();u.d.remove();shop()});
  u.add('Abrir otro','r',()=>{u.d.remove();pack(type,cur)});u.add('Volver','g',()=>{u.d.remove();shop()})});
 envelope.style.cssText='height:190px;background:linear-gradient(135deg,#1f6bff,#8a2be2 50%,#e8233b);border:3px solid #fff'}

function mine(){const u=box();u.clear('<b>Mis cosméticos</b>'+(S.cosOwn.length?'<small>Toca para poner o quitar (1 de cabeza y 1 aura)</small>':'<small>Aún no tienes. Abre un sobre.</small>'));
 for(const c of COS.filter(c=>S.cosOwn.includes(c[0]))){const on=S.cos[c[3]]===c[0];u.add(c[1]+' · '+RN[c[2]]+(on?' (puesto)':''),on?'on':'g',()=>{S.cos[c[3]]=on?null:c[0];save();u.d.remove();mine()})}
 u.add('Volver','r',()=>{u.d.remove();shop()})}

/* dibujo: coordenadas de la plantilla (pies en 400,890; cabeza en 338,230) */
function aura(x,y,s,rgb){const c=X;c.save();const r=420*s,cy=y-380*s,g=c.createRadialGradient(x,cy,r*.15,x,cy,r);g.addColorStop(0,'rgba('+rgb+',.6)');g.addColorStop(1,'rgba('+rgb+',0)');c.fillStyle=g;c.beginPath();c.arc(x,cy,r,0,7);c.fill();c.restore()}
function head(x,y,s,dir,it){const c=X;c.save();c.translate(x,y);c.scale(s*(dir||1),s);c.translate(-62,-740);c.fillStyle=it[4];c.strokeStyle='#05050f';c.lineWidth=10;c.lineJoin='round';
 const poly=p=>{c.beginPath();p.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.closePath();c.fill();c.stroke()};
 if(it[0]==='gorra'){poly([[-90,0],[-75,-65],[0,-90],[75,-65],[90,0]]);poly([[60,-14],[160,0],[70,14]])}
 else if(it[0]==='cinta')poly([[-98,18],[98,0],[98,36],[-98,54]]);
 else if(it[0]==='cuernos'){poly([[-80,0],[-130,-110],[-35,-35]]);poly([[80,0],[130,-110],[35,-35]])}
 else if(it[0]==='aureola'){c.beginPath();c.ellipse(0,-115,95,28,0,0,7);c.lineWidth=34;c.stroke();c.strokeStyle=it[4];c.lineWidth=18;c.stroke()}
 else poly([[-85,-20],[-100,-140],[-45,-80],[0,-160],[45,-80],[100,-140],[85,-20]]);
 c.restore()}
const dc=drawChar;drawChar=function(x,y,sc,o){const mine=o&&o.me&&!o.rot,a=mine&&COS.find(c=>c[0]===S.cos.aura),h=mine&&COS.find(c=>c[0]===S.cos.head);
 if(a)aura(x,y,sc,a[4]);const r=dc.apply(this,arguments);if(h)head(x,y,sc,o.dir,h);return r};

/* festejos: solo se equipan los que ya tienes */
const cp=celP;celP=function(){cp();const L=$('cl');if(!L||!L.children)return;CEL.forEach((e,i)=>{const b=L.children[i];if(b&&!S.celOwn.includes(e.id)){b.disabled=true;b.style.opacity=.45;b.innerHTML+='<br><span class=rkm>Sale en el Sobre de Festejos</span>'}})};

const st=STN.find(s=>s.id==='cel');if(st)st.n='Tienda';
const it=inter;inter=function(id){if(id==='cel'){if(!PN&&!document.querySelector('.sr-box'))shop();return}return it.apply(this,arguments)};
window.SRShop={COS,PACKS,open,shop};
})();
