/* ===== FLOWS · segunda pieza de equipo (como en Blue Lock Rivals) =====
   El Flow ya existía como barra (se llena con goles y se activa 12 s). Ahora cada jugador equipa UN Flow
   que cambia qué pasa mientras está activo. Se consiguen en la estación "Flows" del mapa inicial. */
(()=>{
const COST=40,ODDS=[50,26,13,6,3,1.5,.5];
/* [nombre, rareza, descripción, efectos]  spd/pow/slow/mag = fracción · cd = recarga extra · dur = segundos extra · stam = stamina infinita · gol = % de DESPERTAR por gol */
const FL=[
 ['Instinto Básico',0,'Corres más rápido durante el Flow',{spd:.18}],
 ['Pulso Firme',0,'El Flow dura 4 segundos más',{dur:4}],
 ['Ojo de Halcón',1,'Tus tiros salen más fuertes',{pow:.18}],
 ['Segundo Aire',1,'Stamina infinita durante el Flow',{stam:1}],
 ['Metavisión',2,'Los rivales cercanos se mueven más lento',{slow:.35}],
 ['Mente Fría',2,'Tus habilidades se recargan el doble de rápido',{cd:1}],
 ['Hambre de Gol',3,'Un gol durante el Flow carga el DESPERTAR',{gol:45}],
 ['Imán del Egoísta',4,'El balón suelto se te pega cerca',{mag:3.2}],
 ['Instinto Supremo',5,'Más velocidad, más tiro y recarga rápida',{spd:.22,pow:.22,cd:1}],
 ['Rey del Campo',6,'Todo mejorado, Flow +6 s y goles cargan el DESPERTAR',{spd:.25,pow:.25,cd:1,dur:6,stam:1,gol:45}]];
const info=n=>FL.find(f=>f[0]===n)||null;
S.flowOwn=S.flowOwn||[];
const cur=()=>info(S.flow);
const eff=g=>{const f=g&&g.fl>0&&cur();return f?f[3]:null};
const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
const coinsLabel=()=>{const c=document.getElementById('coins');if(c&&typeof ico==='function')c.innerHTML=S.coins+' '+ico('coin')+' · '+ico('gem')+' '+(S.gems||0)};

/* ---------- API pública (códigos, Pase, pruebas) ---------- */
function give(n){const f=info(n);if(!f)return{ok:false,msg:'Ese Flow no existe'};
 if(S.flowOwn.includes(n)){const c=10*(f[1]+1);S.coins+=c;save();coinsLabel();return{ok:true,dup:true,coins:c,msg:n+' repetido: +'+c+' monedas'}}
 S.flowOwn.push(n);if(!S.flow)S.flow=n;save();return{ok:true,dup:false,msg:'Nuevo Flow: '+n}}
const PREM=10,PODDS=[0,30,40,20,7,2.5,.5];
function spin(prem){const free=!prem&&!S.flowFreeUsed;
 if(prem){if((S.gems||0)<PREM)return{ok:false,msg:'Te faltan gemas ('+PREM+')'}}else if(!free&&S.coins<COST)return{ok:false,msg:'Te faltan monedas ('+COST+')'};
 const od=prem?PODDS:ODDS;let r=Math.random()*od.reduce((a,b)=>a+b,0),i=0;for(;i<od.length-1;i++){if(r<od[i])break;r-=od[i]}
 if(!prem){S.flowPity=(S.flowPity||0)+1;if(S.flowPity>=30&&i<2)i=2;if(i>=2)S.flowPity=0}
 const pool=FL.filter(f=>f[1]===i),f=pool[Math.floor(Math.random()*pool.length)]||FL[0];
 if(prem)S.gems-=PREM;else if(free)S.flowFreeUsed=1;else S.coins-=COST;
 const g=give(f[0]);g.flow=f;save();coinsLabel();return g}
window.SRFlows={FL,give,spin,cost:COST,info,open:()=>openFlows()};

/* ---------- menú de Flows ---------- */
function openFlows(){if(document.getElementById('flm'))return;
 const d=document.createElement('div');d.id='flm';d.className='sr-box';
 d.style.cssText='position:fixed;inset:0;z-index:20;background:rgba(5,8,20,.92);display:flex;align-items:center;justify-content:center';
 const inner=document.createElement('div');inner.style.cssText='background:var(--card);color:var(--fg);border-radius:16px;padding:14px;width:min(440px,94vw);max-height:92vh;overflow:auto;touch-action:pan-y;display:flex;flex-direction:column;gap:8px;text-align:center';
 d.appendChild(inner);document.body.appendChild(d);let msg='',busy=0,show=cur();
 const add=(t,cls,fn)=>{const b=document.createElement('button');b.innerHTML=t;b.className=cls||'';b.onclick=fn;inner.appendChild(b);return b};
 const card=f=>f?'<b style="color:'+RC[f[1]]+';text-shadow:0 0 2px #000,0 0 3px #000">'+RN[f[1]]+'</b><br><big>'+f[0]+'</big><br><small>'+f[2]+'</small>':'<small>Aún no tienes un Flow. ¡Tu primer giro es gratis!</small>';
 const roll=prem=>{if(busy)return;const r=spin(prem);if(!r.ok){msg=r.msg;return draw()}
  busy=1;msg='';let k=0;const end=()=>{busy=0;show=r.flow;msg=r.dup?r.msg:'¡Flow nuevo!';draw()};
  if(S.skip)return end();
  const step=()=>{if(!busy||!d.isConnected)return;if(k>=18)return end();const el=document.getElementById('flreel');if(el)el.innerHTML=card(FL[(k*3)%FL.length]);setTimeout(step,50+k*k/2);k++};
  draw();step()};
 const draw=()=>{inner.innerHTML='';const free=!S.flowFreeUsed;
  inner.insertAdjacentHTML('beforeend','<b style="font-size:20px">Roll de Flows</b><div id="flreel" style="min-height:84px;border:3px solid #2fd0ff;border-radius:12px;padding:8px">'+card(show)+'</div><small>Tienes '+S.coins+' monedas · '+(S.gems||0)+' gemas · Pity '+(S.flowPity||0)+'/30</small>');
  if(msg)inner.insertAdjacentHTML('beforeend','<div style="font-weight:800">'+msg+'</div>');
  if(busy)return;
  add(free?'Girar (GRATIS)':'Girar ('+COST+' monedas)','',()=>roll(false));
  add('Giro Premium ('+PREM+' gemas)','r',()=>roll(true));
  add('Animación: '+(S.skip?'NO':'SÍ'),'g',()=>{S.skip=!S.skip;save();draw()});
  if(S.flowOwn.length){inner.insertAdjacentHTML('beforeend','<small>Tus Flows · toca para equipar</small>');
   [...S.flowOwn].sort((a,b)=>info(b)[1]-info(a)[1]).forEach(n=>{const f=info(n),eq=S.flow===n;
    add('<span style="color:'+RC[f[1]]+';text-shadow:0 0 2px #000,0 0 2px #000">'+RN[f[1]]+'</span> · '+n+(eq?' (equipado)':'')+'<br><small>'+f[2]+'</small>',eq?'on':'g',()=>{S.flow=n;show=f;save();draw()})});
   if(S.flow)add('Quitar Flow','g',()=>{S.flow=null;show=null;save();draw()})}
  add('Cerrar','g',()=>d.remove())};
 draw()}

/* ---------- efectos durante el Flow ---------- */
const u1=upd;
upd=function(dt){const g=G;
 if(!g||!g.kp||g.end||g.pause>0||innerHeight>innerWidth)return u1.apply(this,arguments);
 const f=cur();
 if(g.fl>0&&!g._fx){g._fx=1;if(f){if(f[3].dur)g.fl+=f[3].dur;g.fxs.push({t:1.6,x:W/2,y:140,s:f[0]})}}
 if(!(g.fl>0))g._fx=0;
 u1.call(this,dt);
 if(G!==g||g.end||g.pause>0||g.cin)return;
 const e=eff(g);if(!e)return;const h=human(),b=g.b;if(!h)return;
 if(e.spd&&h.fall<=0){h.x=cl(h.x+(h.vx||0)*e.spd*dt,PR,W-PR);h.y=cl(h.y+(h.vy||0)*e.spd*dt,PR,H-PR);if(b.o===h){b.x=h.x+(h.fx||1)*(PR+4);b.y=cl(h.y+9+(h.fy||0)*(PR+4),BR,H-BR)}}
 if(e.cd&&g.skcd)g.skcd=g.skcd.map(c=>Math.max(0,c-dt*e.cd));
 if(e.stam)g.st=100;
 if(e.slow)for(const q of g.ps)if(q.t!==h.t&&q.fall<=0&&Math.hypot(q.x-h.x,q.y-h.y)<140){q.x=cl(q.x-(q.vx||0)*e.slow*dt,PR,W-PR);q.y=cl(q.y-(q.vy||0)*e.slow*dt,PR,H-PR)}
 if(e.mag&&!b.o&&Math.hypot(b.x-h.x,b.y-h.y)<150){b.x+=(h.x-b.x)*e.mag*dt;b.y+=(h.y-b.y)*e.mag*dt}
};
/* el tiro real sale al soltar Kick (chargeRelease): ahí se aplica la fuerza extra */
const cr0=chargeRelease;chargeRelease=function(){const g=G,b=g&&g.b,had=!!(C.on&&b&&b.o===human());const r=cr0.apply(this,arguments);
 const e=eff(g);if(had&&e&&e.pow&&!b.o){b.vx*=1+e.pow;b.vy*=1+e.pow}return r};
const go0=goal;goal=function(t){const g=G,e=eff(g);if(g&&t===0&&e&&e.gol)g.awm=Math.min(100,g.awm+e.gol);return go0.apply(this,arguments)};
/* nombre del Flow en el botón del HUD */
const d1=draw;draw=function(){d1.apply(this,arguments);if(!G||!S.flow)return;const el=document.querySelector('button.bar');
 if(el&&/^¡?FLOW/.test(el.textContent)&&!el.textContent.includes('·')){el.textContent+=' · '+S.flow;el.style.whiteSpace='nowrap';el.style.overflow='hidden';el.style.textOverflow='ellipsis'}};

/* ---------- estación del mapa ---------- */
STN.splice(0,STN.length,{id:'mir',x:60,n:'Vestidor'},{id:'lucky',x:196,n:'Giro de Suerte'},{id:'roll',x:332,n:'Roll de Estilos'},{id:'flow',x:468,n:'Flows'},{id:'event',x:604,n:'Navidad'},{id:'door',x:740,n:'Campo'});
const i0=inter;inter=function(id){if(id==='flow'){if(!PN)openFlows();return}return i0.apply(this,arguments)};
const s0=stn;stn=function(s,t,nr){if(s.id!=='flow')return s0.apply(this,arguments);const x=s.x,c=cx;
 if(nr){c.strokeStyle='#2fd0ff';c.lineWidth=3;c.beginPath();c.ellipse(x,206,52,14,0,0,7);c.stroke()}
 c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(x,200,40,9,0,0,7);c.fill();
 c.fillStyle='#4a4f66';c.fillRect(x-22,168,44,30);c.fillStyle='#6a7090';c.fillRect(x-28,160,56,12);c.strokeStyle='#05050f';c.lineWidth=3;c.strokeRect(x-22,168,44,30);c.strokeRect(x-28,160,56,12);
 const gr=c.createRadialGradient(x,134,3,x,134,34);gr.addColorStop(0,'#e8fbff');gr.addColorStop(.4,'#2fd0ff');gr.addColorStop(1,'rgba(47,208,255,0)');
 c.globalAlpha=.75+.25*Math.sin(t/180);c.fillStyle=gr;c.beginPath();c.arc(x,134,34,0,7);c.fill();c.globalAlpha=1;
 c.fillStyle='#bff3ff';c.beginPath();c.arc(x,134,14,0,7);c.fill();c.lineWidth=3;c.strokeStyle='#05050f';c.stroke();
 c.strokeStyle='#2fd0ff';c.lineWidth=2.5;for(let i=0;i<2;i++){c.beginPath();c.ellipse(x,134,26+i*8,9+i*3,t/500+i*2,0,5);c.stroke()}
 c.font='bold 13px sans-serif';c.textAlign='center';c.strokeStyle='#000';c.lineWidth=3;c.fillStyle='#fff';c.strokeText(s.n,x,x>=560?64:50);c.fillText(s.n,x,x>=560?64:50);
 if(nr){c.fillStyle='#ffd21f';c.fillText('¡Toca Usar!',x,232)}};
})();
