/* ===== Slots de personaje + Evento de Navidad ===== */
(()=>{
const XN='Shidou Repartidor',END=new Date(2027,0,7).getTime();
const HS=HF.Shidou,tri=(pts,c)=>{X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.fillStyle=c;X.fill();X.strokeStyle='#05050f';X.lineWidth=11;X.lineJoin='round';X.stroke()},
 dot=(x,y,r,c)=>{X.beginPath();X.arc(x,y,r,0,7);X.fillStyle=c;X.fill();X.strokeStyle='#05050f';X.lineWidth=9;X.stroke()};
HF[XN]={skin:HS.skin,suit:['#d3213a','#6e0a18','#ffffff'],front(){HS.front();
 tri([[248,172],[270,92],[340,62],[420,78],[486,150],[470,178],[418,128],[428,168]],'#d3213a');
 tri([[232,162],[300,142],[380,140],[446,156],[444,192],[378,176],[300,178],[236,198]],'#ffffff');dot(480,176,28,'#ffffff')}};

const gem=n=>n+' <img class=ic src="'+IM.gem+'">';
const count=()=>S.own.filter(o=>!o.ev).length,price=()=>15+10*(S.slots-1),back=s=>10*(s.r+1);
S.own=S.own||[];if(S.style&&!S.own.find(o=>o.n==S.style.n))S.own.push(S.style);
if(!S.slots)S.slots=Math.max(1,count()); /* quien ya tenía varios no los pierde */
save();
function box(html){const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;z-index:20;background:rgba(5,8,20,.92);display:flex;align-items:center;justify-content:center';
 d.innerHTML='<div style="background:var(--card);color:var(--fg);border-radius:16px;padding:14px;width:min(440px,94vw);max-height:92vh;overflow:auto;touch-action:pan-y;display:flex;flex-direction:column;gap:8px;text-align:center">'+html+'</div>';document.body.appendChild(d);return d}
const btn=(d,t,cls,fn)=>{const b=document.createElement('button');b.innerHTML=t;b.className=cls;b.onclick=fn;d.firstChild.appendChild(b);return b};
const buy=()=>{if((S.gems||0)<price())return false;S.gems-=price();S.slots++;save();return true};
function choose(){const s=S.pend;if(!s)return;
 const d=box('<b>Te salió '+s.n+' ('+RN[s.r]+')</b><span>Slots llenos: '+count()+'/'+S.slots+' · Tienes '+gem(S.gems||0)+'</span>');
 const done=()=>{delete S.pend;save();d.remove()};
 const b=btn(d,'Comprar slot y quedármelo ('+gem(price())+')','',()=>{if(!buy()){b.textContent='Te faltan diamantes';return}S.own.push(s);done()});
 for(const o of S.own.filter(o=>!o.ev))btn(d,'Reemplazar a '+o.n,'g',()=>{if(!confirm('¿Borrar a '+o.n+' y quedarte con '+s.n+'?'))return;S.own.splice(S.own.indexOf(o),1,s);if(S.style&&S.style.n==o.n)S.style=s;done()});
 btn(d,'Descartar (+'+back(s)+' monedas)','r',()=>{S.coins+=back(s);done()})}
window.addChar=s=>{if(count()<S.slots){S.own.push(s);if(!S.style)S.style=s;return '¡Nuevo estilo!'}S.pend=s;save();choose();return 'Slots llenos'};
function chars(){const d=box('<b>Mis personajes</b><span>Slots '+count()+'/'+S.slots+' · '+gem(S.gems||0)+'</span>');
 for(const o of S.own){const eq=S.style&&S.style.n==o.n;btn(d,o.n+(o.ev?' · Exclusivo':'')+(eq?' ✔':''),eq?'':'g',()=>{S.style=o;save();d.remove();chars()})}
 const b=btn(d,'Comprar slot ('+gem(price())+')','r',()=>{if(!buy()){b.textContent='Te faltan diamantes';return}d.remove();chars()});
 btn(d,'Cerrar','g',()=>d.remove())}
const w0=wardrobe;wardrobe=function(){w0();const b=document.createElement('button');b.textContent='Mis personajes';b.onclick=()=>{closeP();chars()};$('pk').before(b)};

const TIERS=[[25,'150 monedas',()=>S.coins+=150],[60,'5 diamantes',()=>S.gems=(S.gems||0)+5],[120,'3 giros de roll',()=>S.freeRoll+=3],[200,'15 diamantes',()=>S.gems=(S.gems||0)+15],
 [300,XN+' (exclusivo)',()=>{if(!S.own.find(o=>o.n==XN))S.own.push({n:XN,r:4,ab:'shot',ev:1})}]];
S.xp=S.xp||0;S.xt=S.xt||0;S.xb=S.xb||0;
function give(n){S.xp+=n;while(S.xt<TIERS.length&&S.xp>=TIERS[S.xt][0]){TIERS[S.xt][2]();if(G&&G.fxs)G.fxs.push({t:2,x:W/2,y:140,s:'¡Premio: '+TIERS[S.xt][1]+'!'});S.xt++}
 while(S.xt==TIERS.length&&S.xp>=350+S.xb*50){S.xb++;S.gems=(S.gems||0)+2}save()}
function event(){const has=S.own.find(o=>o.n==XN),open=Date.now()<END;
 const d=box('<b>🎄 Reparto de Navidad</b><canvas width=200 height=200 style="align-self:center;width:100px;flex:none"></canvas><b>🎁 '+S.xp+' regalos</b><small>Recoger regalo +1 · Gol de tu equipo +5 · Ganar +15</small>'
  +TIERS.map((t,i)=>'<div style="display:flex;justify-content:space-between;gap:8px;border-bottom:1px solid #8884;opacity:'+(i<S.xt?.5:1)+'"><span>'+t[0]+' 🎁</span><span>'+t[1]+(i<S.xt?' ✔':'')+'</span></div>').join('')
  +'<small>Después de 350: +2 diamantes cada 50 regalos. '+(open?'Hasta el 6 de enero.':'El evento terminó.')+'</small>');
 const c=d.querySelector('canvas').getContext('2d'),old=X;X=c;drawChar(100,190,.18,{dir:1,suit:HF[XN].suit,hair:'#fff',ch:XN});X=old;
 if(open)btn(d,'Jugar en la cancha nevada','r',()=>{d.remove();if(!S.style){wardrobeMsg();return}tour=null;start(.9,'Navidad');G.xm=true;G.gifts=[];G.gt=2});
 if(has)btn(d,'Equipar '+XN,'',()=>{S.style=has;save();d.remove()});
 btn(d,'Cerrar','g',()=>d.remove())}
const wardrobeMsg=()=>{const d=box('<span>Primero haz tu Roll de estilo.</span>');btn(d,'Entendido','',()=>d.remove())};
const g0=goal;goal=function(t){if(G&&G.xm&&t==0)give(5);return g0.apply(this,arguments)};
const f0=finish;finish=function(){const g=G,was=g&&g.end;const r=f0.apply(this,arguments);if(g&&g.xm&&!was&&g.end){if(g.sc[0]>g.sc[1])give(15);$('op').innerHTML+=' · 🎁 '+S.xp+' regalos'}return r};
const u0=upd;upd=function(dt){u0(dt);const g=G;if(!g||!g.xm||g.end||g.pause>0||g.cin||innerHeight>innerWidth)return;
 g.gt-=dt;if(g.gt<=0&&g.gifts.length<4){g.gt=4;g.gifts.push({x:60+Math.random()*(W-120),y:60+Math.random()*(H-130)})}
 const h=human();g.gifts=g.gifts.filter(q=>{if(Math.hypot(q.x-h.x,q.y-h.y)>28)return true;give(1);g.fxs.push({t:.8,x:q.x,y:q.y-30,s:'+1 🎁'});return false})};
const tree=(x,y)=>{cx.fillStyle='#6b4226';cx.fillRect(x-3,y,6,10);cx.fillStyle='#14633a';for(let i=0;i<3;i++){cx.beginPath();cx.moveTo(x,y-44+i*11);cx.lineTo(x-12-i*4,y-20+i*11);cx.lineTo(x+12+i*4,y-20+i*11);cx.fill()}cx.fillStyle='#ffd21f';cx.beginPath();cx.arc(x,y-45,4,0,7);cx.fill()};
const d0=draw;draw=function(){d0.apply(this,arguments);const g=G;if(!g||!g.xm||g.cin)return;const t=performance.now();cx.save();
 for(const p of [[30,64],[770,64],[30,425],[770,425]])tree(p[0],p[1]);
 cx.fillStyle='rgba(0,0,0,.65)';cx.fillRect(W/2+92,4,70,26);cx.fillStyle='#fff';cx.font='bold 14px sans-serif';cx.textAlign='left';cx.fillText(g.ot?'GOL ORO':Math.max(0,Math.ceil(g.time))+'s',W/2+98,22);
 for(const q of g.gifts){const y=q.y+Math.sin(t/250+q.x)*3;cx.fillStyle='#d3213a';cx.fillRect(q.x-9,y-8,18,16);cx.fillStyle='#ffd21f';cx.fillRect(q.x-2,y-8,4,16);cx.fillRect(q.x-9,y-2,18,4);cx.fillRect(q.x-6,y-13,12,5)}
 cx.fillStyle='#fff';cx.strokeStyle='#7aa7cc';cx.lineWidth=1;for(let i=0;i<45;i++){const x=(i*97+Math.sin(t/900+i)*20+W)%W,y=(i*53+t*(.03+i%4*.01))%H;cx.beginPath();cx.arc(x,y,1.5+i%3,0,7);cx.fill();cx.stroke()}
 cx.restore()};
const eb=document.createElement('button');eb.className='lu';eb.textContent='🎄 Navidad';eb.style.cssText='position:absolute;left:max(12px,env(safe-area-inset-left));top:10px;background:#c8102e;border:2px solid #fff;padding:8px 12px';
eb.onclick=()=>{if(!PN)event()};$('game').appendChild(eb);
choose();
})();
