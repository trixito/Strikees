/* Fuerza el modo horizontal. En Android lo bloquea el manifest (scripts/notch.js);
   aquí queda el respaldo para navegador/PWA. */
(()=>{
const lock=()=>{try{const o=screen.orientation;if(o&&o.lock)o.lock('landscape').catch(()=>{})}catch(e){}};
lock();                                   // app instalada: suele bastar
try{addEventListener('pointerdown',()=>{  // navegador móvil: pide pantalla completa y luego bloquea
 try{if(matchMedia('(pointer:coarse)').matches){
  const d=document.documentElement;
  if(!document.fullscreenElement&&d.requestFullscreen)d.requestFullscreen().then(lock).catch(lock);else lock()}}catch(e){}},{once:true})}catch(e){}
try{addEventListener('orientationchange',()=>{if(typeof chk==='function')chk()})}catch(e){}
})();
