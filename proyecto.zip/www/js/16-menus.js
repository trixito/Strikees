/* Striker Rivals · menús: X de cierre en todos, tocar fuera para cerrar, Esc, y deslizado fluido (con el CSS de omori.css) */
(()=>{
const XSEL='#pn,.sr-md,.sr-box,#cdm',RX=/^(continuar|cerrar|atr[aá]s|entendido|saltar|volver|listo)/i;
const all=()=>[...document.querySelectorAll(XSEL)];
function closeRoot(root){
 if(root.id==='pn'){closeP();return}
 if(root.id==='cdm'){root.remove();return}
 const b=[...root.querySelectorAll('button')].find(x=>x.className.indexOf('xc')<0&&RX.test((x.textContent||'').trim()));
 if(b){b.click();return}
 /* decisión obligatoria (p. ej. elegir qué hacer con un personaje nuevo): no se puede salir con la X */
 root.classList.add('xshake');setTimeout(()=>root.classList.remove('xshake'),320)}
function addX(root){
 if(root._x)return;root._x=1;
 const b=document.createElement('button');b.className='xc';b.type='button';b.textContent='\u2715';b.setAttribute('aria-label','Cerrar');
 b.onclick=e=>{e.stopPropagation();closeRoot(root)};root.appendChild(b);
 /* tocar el fondo (fuera de la caja) también cierra; un arrastre para deslizar no cuenta */
 let dn=null;
 root.addEventListener('pointerdown',e=>{dn=e.target===root?{x:e.clientX,y:e.clientY}:null});
 root.addEventListener('pointerup',e=>{if(dn&&e.target===root&&Math.hypot(e.clientX-dn.x,e.clientY-dn.y)<8)closeRoot(root);dn=null})}
try{
 if(typeof MutationObserver!=='undefined'){
  new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===1&&n.matches&&n.matches(XSEL))addX(n)}).observe(document.body,{childList:true});
  all().forEach(addX)}
 /* Esc cierra el menú de arriba (y evita que abra la pausa encima) */
 addEventListener('keydown',e=>{if(e.key!=='Escape')return;const a=all();if(!a.length)return;e.stopImmediatePropagation();closeRoot(a[a.length-1])},true);
 /* clase temporal mientras se desliza (ver .scrolling en omori.css) */
 document.addEventListener('scroll',e=>{const t=e.target;if(!t||!t.matches||!t.matches(XSEL))return;
  t.classList.add('scrolling');clearTimeout(t._sc);t._sc=setTimeout(()=>t.classList.remove('scrolling'),180)},true)
}catch(e){console.warn('menus:',e)}
})();
