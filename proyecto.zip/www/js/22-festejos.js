/* ===== FESTEJOS · efectos de gol y celebración =====
   Estación "Festejos" en el lobby: elige el efecto que sale cuando TÚ marcas. Incluye "Aura 67 · Six Seven" y
   "Ego Manipulador Supremo" (estilo Ayanokōji). Los efectos se dibujan por código (sin imágenes) en drawCel(). */
const CEL=[
 {id:'clasico',n:'Clásico',d:'Confeti y a celebrar'},
 {id:'fuego',n:'Llamarada',d:'Fuego que sube desde tus pies'},
 {id:'rayo',n:'Rayo',d:'Tormenta eléctrica sobre ti'},
 {id:'s67',n:'Aura 67 · Six Seven',d:'6 y 7 subiendo y bajando, aura lima'},
 {id:'ayano',n:'Ego Manipulador Supremo',d:'Ojos rojos, hilos y mirada fría'}];
const CELD=2.4,crn=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
function drawCel(c,id,k,x,y,rv){
 const a=Math.min(1,k*5)*Math.min(1,(CELD-k)*3);if(a<=0)return;c.save();c.textAlign='center';c.lineJoin='round';
 if(id==='clasico'){const col=['#ffd21f','#2fd0ff','#e8233b','#fff','#5cff8a'];
  for(let i=0;i<70;i++){const px=crn(i)*W+Math.sin(k*3+i)*14,py=-20+k*(150+crn(i+1)*190)-crn(i+2)*160;c.save();c.translate(px,py);c.rotate(k*6+i);c.globalAlpha=a;c.fillStyle=col[i%5];c.fillRect(-4,-2,8,4);c.restore()}}
 else if(id==='fuego'){c.globalCompositeOperation='lighter';
  const gr=c.createRadialGradient(x,y+14,2,x,y+14,60);gr.addColorStop(0,'rgba(255,190,60,'+.6*a+')');gr.addColorStop(1,'rgba(255,60,20,0)');c.fillStyle=gr;c.beginPath();c.ellipse(x,y+14,70,22,0,0,7);c.fill();
  for(let i=0;i<46;i++){const ph=(k*1.5+crn(i))%1,px=x+(crn(i+3)-.5)*64*(1-ph*.4),py=y+12-ph*120,r=15*(1-ph)+2;
   const g2=c.createRadialGradient(px,py,0,px,py,r);g2.addColorStop(0,'rgba(255,230,120,'+a*(1-ph)+')');g2.addColorStop(.5,'rgba(255,100,20,'+a*(1-ph)*.7+')');g2.addColorStop(1,'rgba(200,20,0,0)');c.fillStyle=g2;c.beginPath();c.arc(px,py,r,0,7);c.fill()}}
 else if(id==='rayo'){if(k<.14){c.fillStyle='rgba(255,255,255,'+(.7*(1-k/.14))+')';c.fillRect(0,0,W,H)}
  c.globalCompositeOperation='lighter';const seed=Math.floor(k*9);
  for(let b=0;b<3;b++){let px=x+(b-1)*70+(crn(seed*7+b)-.5)*40,py=0;const tx=x+(b-1)*26;c.strokeStyle='rgba(150,220,255,'+a+')';c.lineWidth=3-b*.5;c.shadowColor='#2fd0ff';c.shadowBlur=14;c.beginPath();c.moveTo(px,py);
   for(let s=1;s<=8;s++){py=s*(y/8);px=px+(tx-px)*.3+(crn(seed*31+b*9+s)-.5)*46*(1-s/9);c.lineTo(px,py)}c.stroke()}
  c.shadowBlur=0;for(let i=0;i<2;i++){c.strokeStyle='rgba(47,208,255,'+a*.8+')';c.lineWidth=2;c.beginPath();c.ellipse(x,y+10,30+i*14+Math.sin(k*20)*3,10+i*4,0,0,7);c.stroke()}}
 else if(id==='s67'){
  const pul=1+.08*Math.sin(k*14);c.globalCompositeOperation='lighter';
  const gr=c.createRadialGradient(x,y-6,4,x,y-6,95*pul);gr.addColorStop(0,'rgba(220,255,90,'+.75*a+')');gr.addColorStop(.5,'rgba(120,230,40,'+.35*a+')');gr.addColorStop(1,'rgba(60,200,0,0)');c.fillStyle=gr;c.beginPath();c.arc(x,y-6,95*pul,0,7);c.fill();
  for(let i=0;i<3;i++){const ph=(k*1.3+i/3)%1;c.strokeStyle='rgba(200,255,80,'+a*(1-ph)+')';c.lineWidth=3;c.beginPath();c.ellipse(x,y+14,20+ph*90,7+ph*26,0,0,7);c.stroke()}
  c.globalCompositeOperation='source-over';c.font='italic 900 26px sans-serif';c.lineWidth=4;c.strokeStyle='#111';
  for(let i=0;i<22;i++){const ph=(k*.9+crn(i))%1,px=x+Math.sin(ph*7+i)*(30+ph*60),py=y+10-ph*170;c.globalAlpha=a*(1-ph*.7);c.fillStyle=i%2?'#c6ff3d':'#fff';const t=i%2?'7':'6';c.strokeText(t,px,py);c.fillText(t,px,py)}
  c.globalAlpha=a;const o=Math.sin(k*9)*30,by=H/2+52;c.font='italic 900 120px sans-serif';c.lineWidth=9;c.strokeStyle='#111';
  c.fillStyle='#c6ff3d';c.strokeText('6',W/2-62,by-o);c.fillText('6',W/2-62,by-o);c.fillStyle='#fff';c.strokeText('7',W/2+62,by+o);c.fillText('7',W/2+62,by+o);
  c.fillStyle='#f1c27d';c.strokeStyle='#111';c.lineWidth=3;for(const s of[-1,1]){c.beginPath();c.ellipse(W/2+s*62,by+30+(s<0?-o:o)*.8,17,13,0,0,7);c.fill();c.stroke()}
  c.font='italic 900 20px sans-serif';c.lineWidth=4;c.fillStyle='#c6ff3d';c.strokeText('S I X   S E V E N',W/2,by+82);c.fillText('S I X   S E V E N',W/2,by+82)}
 else if(id==='ayano'){
  c.fillStyle='rgba(6,0,18,'+.5*a+')';c.fillRect(0,0,W,H);
  const vg=c.createRadialGradient(W/2,H/2,H*.2,W/2,H/2,W*.65);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(30,0,20,'+.75*a+')');c.fillStyle=vg;c.fillRect(0,0,W,H);
  /* hilos de marioneta hacia los rivales */
  c.strokeStyle='rgba(255,70,90,'+.55*a+')';c.lineWidth=1.2;for(const p of rv){const sw=Math.sin(k*5+p.i)*6;c.beginPath();c.moveTo(p.x+sw,-6);c.lineTo(p.x,p.y-22);c.stroke();c.beginPath();c.moveTo(p.x-14+sw,-6);c.lineTo(p.x-8,p.y-6);c.moveTo(p.x+14+sw,-6);c.lineTo(p.x+8,p.y-6);c.stroke();
   c.fillStyle='rgba(255,70,90,'+.8*a+')';c.fillRect(p.x-9,p.y-26,18,3)}
  const e=1-Math.pow(1-Math.min(1,k*5),3),bh=44*e;c.fillStyle='rgba(0,0,0,'+.85*a+')';c.fillRect(0,H/2-bh,W,bh*2);
  c.fillStyle='rgba(230,30,60,'+a+')';c.fillRect(0,H/2-bh-2,W*e,2);c.fillRect(W*(1-e),H/2+bh,W*e,2);
  if(k>.25){const ea=Math.min(1,(k-.25)*5)*a,bl=k%1.1>1.02?.15:1;c.globalCompositeOperation='lighter';
   for(const s of[-1,1]){const ex=W/2+s*62,ey=H/2;const g3=c.createRadialGradient(ex,ey,2,ex,ey,46);g3.addColorStop(0,'rgba(255,40,60,'+ea*.8+')');g3.addColorStop(1,'rgba(255,0,40,0)');c.fillStyle=g3;c.beginPath();c.arc(ex,ey,46,0,7);c.fill();
    c.globalCompositeOperation='source-over';c.fillStyle='rgba(255,50,70,'+ea+')';c.beginPath();c.moveTo(ex-s*30,ey+4);c.quadraticCurveTo(ex,ey-16*bl,ex+s*30,ey-6);c.quadraticCurveTo(ex,ey+12*bl,ex-s*30,ey+4);c.fill();
    c.fillStyle='rgba(20,0,10,'+ea+')';c.fillRect(ex-2,ey-9*bl,4,16*bl);c.globalCompositeOperation='lighter'}
   c.globalCompositeOperation='source-over'}
  if(k>.5){const full='EGO MANIPULADOR SUPREMO',n=Math.min(full.length,Math.floor((k-.5)*30));c.font='italic 900 33px sans-serif';c.lineWidth=7;c.strokeStyle='#5a0010';c.fillStyle='#fff';c.globalAlpha=a;
   const sub=full.slice(0,n);c.strokeText(sub,W/2,H/2+bh+42);c.fillText(sub,W/2,H/2+bh+42);
   if(k>1.1){c.globalAlpha=a*Math.min(1,(k-1.1)*3);c.font='italic 700 15px sans-serif';c.lineWidth=3;c.strokeStyle='#000';c.fillStyle='#d6d6e6';c.strokeText('「 Todo sigue según lo calculado. 」',W/2,H/2+bh+68);c.fillText('「 Todo sigue según lo calculado. 」',W/2,H/2+bh+68)}}}
 c.restore()}
/* --- se dispara al marcar tú --- */
const gl0=goal;goal=function(t){gl0.apply(this,arguments);const g=G;if(t!==0||!g||g.end)return;
 const id=S.cel||'clasico',p=human();g.cel={id,t0:performance.now()};g.pause=Math.max(g.pause,CELD);
 if(id==='s67'||id==='rayo'||id==='ayano')g.shk={t0:performance.now(),d:id==='ayano'?180:320,m:id==='s67'?6:4};
 try{SR.sfx.cutin()}catch(e){}};
const dc0=draw;draw=function(){dc0.apply(this,arguments);const g=G;if(!g||!g.cel)return;const k=(performance.now()-g.cel.t0)/1000;
 if(k>CELD||g.end&&g.sc[0]<=g.sc[1]){g.cel=null;return}const p=human();if(!p)return;drawCel(cx,g.cel.id,k,p.x,p.y,g.ps.filter(q=>q.t==1))};
/* --- vista previa en el lobby --- */
let PVC=null;const lb1=lobDraw;lobDraw=function(t){lb1(t);if(!PVC||!LB)return;const k=(performance.now()-PVC.t0)/1000;if(k>CELD){PVC=null;return}
 drawCel(cx,PVC.id,k,LB.x,LB.y,PVC.id==='ayano'?[{x:LB.x+140,y:LB.y,i:0},{x:LB.x-140,y:LB.y,i:1}]:[])};
/* --- panel y estación --- */
function celP(){const cur=S.cel||'clasico';
 panel('<div class="col"><b>Festejos</b><div class=rkm>Efecto cuando marcas un gol</div><div id=cl class=col></div><button id=cp class=r>Probar</button><button id=cx2 class=g>Cerrar</button></div>');
 const L=$('cl');for(const e of CEL){const b=document.createElement('button');b.className=e.id===cur?'on':'g';b.innerHTML='<b>'+e.n+'</b><br><span class=rkm>'+e.d+'</span>';
  b.onclick=()=>{S.cel=e.id;save();[...L.children].forEach((x,i)=>x.className=CEL[i].id===e.id?'on':'g')};L.appendChild(b)}
 $('cx2').onclick=closeP;$('cp').onclick=()=>{closeP();PVC={id:S.cel||'clasico',t0:performance.now()}}}
STN.splice(0,STN.length,{id:'mir',x:50,n:'Vestidor'},{id:'lucky',x:167,n:'Giro de Suerte'},{id:'roll',x:284,n:'Roll de Estilos'},{id:'flow',x:401,n:'Flows'},{id:'cel',x:518,n:'Festejos'},{id:'event',x:635,n:'Navidad'},{id:'door',x:752,n:'Campo'});
const it1=inter;inter=function(id){if(id==='cel'){if(!PN)celP();return}return it1.apply(this,arguments)};
const st1=stn;stn=function(s,t,nr){if(s.id!=='cel')return st1.apply(this,arguments);const x=s.x,c=cx;
 if(nr){c.strokeStyle='#ffd21f';c.lineWidth=3;c.beginPath();c.ellipse(x,206,52,14,0,0,7);c.stroke()}
 c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(x,200,40,9,0,0,7);c.fill();
 c.fillStyle='#6a7090';c.fillRect(x-26,176,52,22);c.fillStyle='#4a4f66';c.fillRect(x-18,160,36,16);c.strokeStyle='#05050f';c.lineWidth=3;c.strokeRect(x-26,176,52,22);c.strokeRect(x-18,160,36,16);
 const gl=c.createRadialGradient(x,128,3,x,128,40);gl.addColorStop(0,'rgba(255,230,120,.9)');gl.addColorStop(1,'rgba(255,210,31,0)');c.globalAlpha=.7+.3*Math.sin(t/200);c.fillStyle=gl;c.beginPath();c.arc(x,128,40,0,7);c.fill();c.globalAlpha=1;
 c.fillStyle='#ffd21f';c.beginPath();c.moveTo(x-16,108);c.lineTo(x+16,108);c.quadraticCurveTo(x+14,140,x,144);c.quadraticCurveTo(x-14,140,x-16,108);c.fill();c.stroke();c.fillRect(x-4,144,8,14);c.strokeRect(x-4,144,8,14);c.fillRect(x-12,158,24,4);
 c.font='bold 13px sans-serif';c.textAlign='center';c.strokeStyle='#000';c.lineWidth=3;c.fillStyle='#fff';c.strokeText(s.n,x,50);c.fillText(s.n,x,50);
 if(nr){c.fillStyle='#ffd21f';c.fillText('¡Toca Usar!',x,232)}};
