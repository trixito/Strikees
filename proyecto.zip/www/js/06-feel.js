/* feel.js · movimiento más fluido y animaciones con la orientación correcta */
(()=>{
const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
/* 2) joystick: zona muerta + respuesta progresiva */
const jm0=jm;jm=function(e){jm0(e);const m=Math.hypot(joy.x,joy.y);if(m<.14){joy.x=joy.y=0}else{const k=Math.min(1,(m-.14)/.7)/m;joy.x*=k;joy.y*=k}};
/* 3) joystick flotante: toca en cualquier punto de la mitad izquierda */
const gm=document.getElementById('game'),jz=document.getElementById('jz'),rst=()=>{jz.style.left='';jz.style.top='';jz.style.bottom=''};
gm.addEventListener('pointerdown',e=>{if(e.target.id!=='cv'&&e.target!==gm)return;if(e.clientX>innerWidth*.5||(!G&&!(typeof LB!=='undefined'&&LB)))return;
 jz.style.left=(e.clientX-65)+'px';jz.style.top=(e.clientY-65)+'px';jz.style.bottom='auto';
 jz.dispatchEvent(new PointerEvent('pointerdown',{pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY}))});
jz.addEventListener('pointerup',rst);jz.addEventListener('pointercancel',rst);
/* 4) lógica por frame */
const u0=upd;
upd=function(dt){const g=G;if(!g||!g.ps||g.end||g.pause>0||innerHeight>innerWidth)return u0(dt);
 u0(dt);if(G!==g||g.cin)return;const ps=g.ps,b=g.b;
 for(const p of ps){p.ph=(p.ph||0)+Math.hypot(p.vx,p.vy)*dt*.052;
  if(p.dr>0){const m=Math.hypot(p.ddx||0,p.ddy||0);if(m>.1){p.fx=p.ddx/m;p.fy=p.ddy/m}}}   // dash/regate: mira hacia donde va
 for(let i=0;i<ps.length;i++)for(let j=i+1;j<ps.length;j++){const a=ps[i],c=ps[j];if(a.fall>0||c.fall>0)continue;   // separación suave entre jugadores
  const dx=c.x-a.x,dy=c.y-a.y,d=Math.hypot(dx,dy),m=PR*1.7;
  if(d<m&&d>.01){const o=(m-d)/2*Math.min(1,dt*14),nx=dx/d,ny=dy/d;a.x=cl(a.x-nx*o,PR,W-PR);a.y=cl(a.y-ny*o,PR,H-PR);c.x=cl(c.x+nx*o,PR,W-PR);c.y=cl(c.y+ny*o,PR,H-PR)}}
 const o=b.o;if(o){o.sfx=o.sfx===undefined?o.fx:o.sfx+(o.fx-o.sfx)*Math.min(1,dt*14);o.sfy=o.sfy===undefined?o.fy:o.sfy+(o.fy-o.sfy)*Math.min(1,dt*14);   // balón pegado al pie sin saltos al girar
  b.x=o.x+o.sfx*(PR+4);b.y=cl(o.y+9+o.sfy*(PR+4),BR,H-BR)}};
})();
