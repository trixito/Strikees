/* ===== Gemas + Pity + Giro Premium ===== */
(()=>{
S.gems=S.gems||0;S.pity=S.pity||0;

const td=new Date().toDateString();if(S.dl!==td){S.dl=td;S.gems+=1}
save();
const fi2=finish;finish=function(){const g=G,was=g&&g.end;const r=fi2.apply(this,arguments);
 if(g&&g.end&&!was&&g.sc[0]>g.sc[1]&&/Final/.test(g.label)){const n=[1,2,3,5][S.diff==null?1:S.diff];S.gems=(S.gems||0)+n;save();const o=$('op');if(o)o.innerHTML+=' · +'+n+' <img class=ic src="'+IM.gem+'">'}return r};
const mo=menu;menu=function(){mo();const c=$('coins');if(c)c.innerHTML=S.coins+' <img class=ic src="'+IM.coin+'"> · <img class=ic src="'+IM.gem+'"> '+(S.gems||0)};
try{let s=rollP.toString(),n=0;
 const rp=(a,b)=>{if(s.includes(a)){s=s.replace(a,b);n++}else console.warn('patch no encontrado:',a.slice(0,40))};
 rp("const go=()=>{if(R.md)return;R.msg='';","const go=()=>{if(R.md)return;R.msg='';R.pm=0;");
 rp("const r=pick(lu?LUCK:NORM),p=ST","let r=pick(lu?LUCK:NORM);S.pity=(S.pity||0)+1;if(S.pity>=30&&r<2)r=2+(Math.random()<.3?1:0);if(r>=2)S.pity=0;const p=ST");
 rp("S.coins+=10*(s.r+1);R.msg='Repetido: +'+10*(s.r+1)+' monedas'","if(R.pm&&s.r>=3){S.gems+=2;R.msg='Repetido: +2 gemas'}else{S.coins+=10*(s.r+1);R.msg='Repetido: +'+10*(s.r+1)+' monedas'}");
 rp("const tx=(s,x,y,sz,col)=>","const gemGo=()=>{if(R.md)return;R.msg='';if((S.gems||0)<10){R.msg='Te faltan gemas (10)';return}S.gems-=10;R.pm=1;const P=[0,30,40,20,7,2.5,.5];let r=pick(P),p=ST.filter(e=>e[1]==r);while(!p.length&&r>1){r--;p=ST.filter(e=>e[1]==r)}const e=p[Math.floor(Math.random()*p.length)];S.pity=0;R.res={n:e[0],r:e[1],ab:e[2]};save();if(S.skip)fin();else{R.md=1;R.t0=performance.now()}};const tx=(s,x,y,sz,col)=>");
 rp("bt(14,404,110,34,'VOLVER'","bt(130,404,154,34,'PREMIUM 10','#5a1fa8','#d9a0ff',gemGo,13);gi(c,'gem',252,409,22);bt(14,404,110,34,'VOLVER'");
 rp("tx('Suerte: '+S.ls,215,424,15,'#ffd21f')","gi(c,'gem',134,360,20);tx((S.gems||0)+' · Pity '+(S.pity||0)+'/30',217,374,13,'#d9a0ff');tx('Suerte: '+S.ls,207,392,13,'#ffd21f')");
 rp("tx('$ '+S.coins.toLocaleString(),705,407,15,'#8dff8d')","gi(c,'coin',630,390,22);tx(S.coins.toLocaleString(),715,407,15,'#8dff8d')");rp("od[i]+'%'","(od[i]!=null?od[i]+'%':'solo premium')");
 rp("if(S.freeRoll<1){R.msg='Sin giros. Compra más.';return}","if(S.freeRoll<1){if(S.coins>=30){S.coins-=30;S.freeRoll++;R.msg='Giro comprado con 30 monedas'}else{R.msg='Sin giros ni 30 monedas. Gana partidos o usa Premium.';return}}");
 rp("tx(R.msg,400,106,13,'#ffd21f')","tx(R.msg,400,108,18,'#ffd21f')");
 if(n===10)rollP=(0,eval)('('+s+')');else console.warn('rollP no parcheado',n)
}catch(e){console.warn('gemas',e)}
})();
