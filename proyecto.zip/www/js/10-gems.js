/* ===== Gemas + Pity + Giro Premium ===== */
(()=>{
S.gems=S.gems||0;S.pity=S.pity||0;

const td=new Date().toDateString();if(S.dl!==td){S.dl=td;S.gems+=1}
save();
const fi2=finish;finish=function(){const g=G,was=g&&g.end;const r=fi2.apply(this,arguments);
 if(g&&g.end&&!was&&g.sc[0]>g.sc[1]&&/Final/.test(g.label)){const n=[1,2,3,5][S.diff==null?1:S.diff];S.gems=(S.gems||0)+n;save();const o=$('op');if(o)o.innerHTML+=' · +'+n+' '+ico('gem')+''}return r};
const mo=menu;menu=function(){mo();const c=$('coins');if(c)c.innerHTML=S.coins+' '+ico('coin')+' · '+ico('gem')+' '+(S.gems||0)};
})();
