/* ===== TRIX · estilo limitado ===== 
   Pelo blanco + venda negra (estilo 9S). Solo sale en el Roll mientras dure el evento (TRIX_END).
   Habilidades: C/V = Dribble del Manipulador · UltraKill. Despertar (G): Portal · Aura · Disparo del Dragón. */
(()=>{
const TRIX='Trix',TRIX_END=new Date(2026,11,31,23,59,59).getTime(),TRIX_RATE=.02;
const {tone,noise,SF,COL}=SR,cl=(v,a,b)=>Math.max(a,Math.min(b,v)),near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const isOpen=()=>Date.now()<TRIX_END;

/* rareza exclusiva */
RN[7]='Limitado';RC[7]='#ffd21f';DIF[7]='Imposible';
ST.push([TRIX,7,'shot']);

/* ---------- apariencia: pelo blanco y venda negra ---------- */
{const OL='#05050f',poly=(pts,fill,lw)=>{X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.fillStyle=fill;X.fill();if(lw!==0){X.lineJoin='round';X.strokeStyle=OL;X.lineWidth=lw||13;X.stroke()}};
 const strands=(list,c,w,a)=>{X.save();X.strokeStyle=c;X.globalAlpha=a==null?.5:a;X.lineWidth=w||7;X.lineCap='round';X.beginPath();for(const s of list){X.moveTo(s[0],s[1]);X.lineTo(s[2],s[3])}X.stroke();X.restore()};
 HF[TRIX]={skin:['#f9e3d3','#d9b8a6'],suit:['#262634','#0e0e16','#d9dbe6'],
  back(){poly([[238,300],[226,240],[232,190],[262,142],[312,114],[372,108],[420,126],[448,172],[452,236],[444,298],[428,276],[252,276]],'#e6e8f0');
   poly([[250,236],[268,232],[276,330],[258,352],[244,332]],'#101018',11);poly([[262,240],[284,246],[302,338],[286,352],[270,330]],'#101018',11)},
  front(){poly([[240,238],[232,180],[256,142],[300,116],[352,106],[404,116],[440,148],[450,206],[446,262],[434,232],[428,200],[404,214],[382,190],[360,218],[336,192],[312,216],[290,194],[270,222],[262,262],[246,258]],'#eceff5');
   strands([[292,150,278,190],[350,128,352,186],[404,140,414,196],[262,170,254,214]],'#b6bbd0',7,.7);strands([[330,112,322,150]],'#fff',6,.8)}};
 /* la venda va al final (después de los ojos), así que se dibuja desde MI.extra */
 const blind=c=>{c.save();c.lineJoin='round';c.beginPath();c.moveTo(238,210);c.quadraticCurveTo(340,196,442,204);c.lineTo(444,258);c.quadraticCurveTo(340,270,240,262);c.closePath();
  c.fillStyle='#101018';c.fill();c.strokeStyle=OL;c.lineWidth=13;c.stroke();
  c.strokeStyle='#34344a';c.lineWidth=5;c.lineCap='round';c.beginPath();c.moveTo(262,220);c.quadraticCurveTo(340,208,420,216);c.stroke();c.restore();
  X=c;for(const t of [[[256,190],[266,238],[288,196]],[[300,186],[312,230],[332,190]],[[352,188],[364,232],[386,192]],[[398,190],[408,224],[426,194]]])poly(t,'#eceff5',9)};
 const ex0=MI.extra;MI.extra=function(c){if(ex0)ex0.apply(this,arguments);if(window.__trixOn){const o=X;blind(c||X);X=o}};
 const dc0=drawChar;drawChar=function(x,y,sc,o){window.__trixOn=!!(o&&o.ch===TRIX);try{return dc0.apply(this,arguments)}finally{window.__trixOn=false}};
}

/* ---------- datos de habilidades ---------- */
SKD.trixzig={n:'Dribble del Manipulador',cd:22,need:1};
SKD.ultrakill={n:'UltraKill',cd:30};
SKD.trixportal={n:'Portal Multiversal',cd:7};
SKD.trixaura={n:'Aura del Manipulador',cd:22};
SKD.trixdragon={n:'Disparo del Dragón',cd:99,need:1};
{const a=['trixzig','ultrakill','trixdragon'];
 Object.defineProperty(a,0,{get:()=>G&&G.aw>0?'trixportal':'trixzig'});
 Object.defineProperty(a,1,{get:()=>G&&G.aw>0?'trixaura':'ultrakill'});
 NSK[TRIX]=a}
Object.assign(COL,{trixzig:'#b86bff',ultrakill:'#ffffff',trixportal:'#7a5cff',trixaura:'#b86bff',trixdragon:'#ff3b4e'});
Object.assign(SF,{trixzig(){noise(.3,.25);tone(180,.3,'sawtooth',.14,700)},ultrakill(){tone(90,.25,'sawtooth',.35,30);noise(.18,.4);tone(1400,.2,'square',.08,300)},
 trixportal(){tone(300,.4,'sine',.2,900);tone(900,.4,'sine',.14,300,.12)},trixaura(){tone(70,1,'sawtooth',.22,160);noise(.7,.12)},trixdragon(){tone(55,1.1,'sawtooth',.3,420);noise(.6,.3,.2);tone(1700,.9,'sine',.07,120)}});

/* ---------- utilidades ---------- */
const fxt=(h,s)=>{if(G&&G.fxs)G.fxs.push({t:1.3,x:h.x,y:h.y-110,s})};
const sfx=(g,o)=>{g._sfx=g._sfx||[];g._sfx.push(o)};
const rivals=h=>G.ps.filter(q=>q.t!==h.t);
const PUR='#b86bff';

/* ---------- Dribble del Manipulador ---------- */
function castZig(g,h){if(g.b.o!==h)return 0;g.tz=1.5;g.tzp=0;g.tzh=[];sfx(g,{kind:'arc',x:h.x,y:h.y,col:PUR,t:.45});fxt(h,'Dribble del Manipulador');return 1}

/* ---------- UltraKill: volea salvadora (reactiva) ---------- */
const threat=g=>{const b=g.b;if(b.o||b.vx>-140||b.x>340)return false;const y=b.y+b.vy*(b.x/-b.vx);return y>GY0-14&&y<GY1+14};
function fireUK(g,h){const b=g.b,a=(Math.random()-.5)*1.3,dx=Math.cos(a),dy=Math.sin(a);
 h.x=cl(b.x+10,PR,W-PR);h.y=cl(b.y-6,PR,H-PR);h.fx=dx;h.fy=dy;h.pk=.55;h.fall=0;
 b.o=null;b.x=h.x+dx*(PR+BR+2);b.y=cl(h.y+dy*(PR+BR+2),BR,H-BR);b.vx=dx*430;b.vy=dy*430;
 g.uk=0;sfx(g,{kind:'cut',x:h.x,y:h.y-8,dx,dy,col:'#fff',t:.4});sfx(g,{kind:'shards',x:h.x,y:h.y-8,col:PUR,t:.45});fxt(h,'¡ULTRAKILL!');SR.fx('ultrakill',true)}
function castUK(g,h){if(threat(g)){fireUK(g,h);return 1}g.uk=4;fxt(h,'UltraKill: en guardia');return 1}

/* ---------- Despertar: Portal Multiversal ---------- */
function castPortal(g,h){const a=aimDir(h);let ax=cl(h.x+a.x*70,40,W-40),ay=cl(h.y+a.y*70,40,H-40),bx=cl(h.x+a.x*320,40,W-40),by=cl(h.y+a.y*320,40,H-40);
 if(Math.hypot(bx-ax,by-ay)<130){bx=cl(h.x-a.x*320,40,W-40);by=cl(h.y-a.y*320,40,H-40)}
 g.portals={a:{x:ax,y:ay},b:{x:bx,y:by},uses:3,t:12,cd:0};sfx(g,{kind:'arc',x:ax,y:ay,col:'#7a5cff',t:.45});sfx(g,{kind:'arc',x:bx,y:by,col:'#7a5cff',t:.45});fxt(h,'Portal Multiversal');return 1}

/* ---------- Despertar: Aura del Manipulador ---------- */
function castAura(g,h){g.aura=5;sfx(g,{kind:'shards',x:h.x,y:h.y-10,col:PUR,t:.5});fxt(h,'Aura del Manipulador');return 1}

/* ---------- Despertar: Disparo del Dragón (1v1 de clicks) ---------- */
const DG_RATE=[18,28,38,50];let dgEl=null,dgTO=0;
const dgClose=()=>{if(dgEl){dgEl.remove();dgEl=null}};
function dgTap(){const g=G,d=g&&g.dg;if(!d||d.res)return;d.bar=Math.min(100,d.bar+6.5);d.taps++;d.pulse=.12;tone(500+d.bar*6,.05,'square',.07);if(d.bar>=100){d.res=1;d.rt=1}}
function castDragon(g,h){if(g.b.o!==h)return 0;const di=g._diffIdx!=null?g._diffIdx:(S.diff==null?1:S.diff);
 g.fxs=[];g.dg={t:0,lim:6,bar:45,rate:DG_RATE[cl(di,0,3)],taps:0,res:0,rt:0,tw:Math.random()*6,pulse:0,di:cl(di,0,3)};
 dgClose();dgEl=document.createElement('div');dgEl.id='dgb';dgEl.style.cssText='position:fixed;inset:0;z-index:12;background:rgba(8,4,24,.55);touch-action:none;cursor:pointer';
 dgEl.onpointerdown=e=>{e.preventDefault();dgTap()};document.body.appendChild(dgEl);
 clearTimeout(dgTO);dgTO=setTimeout(dgClose,9000);return 1}
function dgTick(g,dt){const d=g.dg,h=human(),b=g.b;
 if(d.res){d.rt-=dt;if(d.rt<=0){g.dg=null;dgClose();
   if(d.res==1){b.o=null;b.vx=b.vy=0;b.x=W-5;b.y=H/2;h.pk=.5;goal(0)}
   else{b.o=null;b.x=W-70;b.y=cl(h.y,GY0,GY1);b.vx=-260;b.vy=(Math.random()<.5?-1:1)*120;h.pk=.6;fxt(h,'¡Atajado!')}}return}
 d.t+=dt;d.pulse=Math.max(0,d.pulse-dt);d.bar-=d.rate*(1+.35*Math.sin(d.t*7+d.tw))*dt;
 if(d.bar>=100){d.bar=100;d.res=1;d.rt=1}else if(d.bar<=0){d.bar=0;d.res=2;d.rt=1}else if(d.t>=d.lim){d.res=d.bar>50?1:2;d.rt=1}}

/* ---------- control de habilidades ---------- */
const us1=useSk;
useSk=function(i){const g=G;if(!g||!S.style||S.style.n!==TRIX)return us1.apply(this,arguments);
 if(g.dg){dgTap();return}
 if(g.end||g.pause>0||g.cin||!g.skcd)return;
 const h=human();if(!h||h.fall>0||g.skcd[i]>0)return;
 const aw=g.aw>0,id=aw?['trixportal','trixaura','trixdragon'][i]:['trixzig','ultrakill'][i];if(!id)return;
 const f={trixzig:castZig,ultrakill:castUK,trixportal:castPortal,trixaura:castAura,trixdragon:castDragon}[id];
 if(!f(g,h))return;g.skcd[i]=id=='trixdragon'?99:SKD[id].cd;SR.fx(id,id=='trixdragon')};
addEventListener('keydown',e=>{if(G&&G.dg&&!e.repeat&&!/^[cvbg]$/i.test(e.key)){e.preventDefault();dgTap()}});

/* ---------- lógica por frame ---------- */
const u1=upd;
upd=function(dt){const g=G;
 if(!g||!g.kp||g.end||innerHeight>innerWidth||!S.style||S.style.n!==TRIX)return u1.apply(this,arguments);
 if(g.dg){dgTick(g,dt);return}
 if(g.pause>0)return u1.apply(this,arguments);
 if(g.aw>0&&!g._tx){g._tx=1;g.skcd[0]=g.skcd[1]=g.skcd[2]=0;g.uk=0;g.tz=0}
 if(!(g.aw>0)&&g._tx){g._tx=0;g.portals=null;g.aura=0;g.skcd[0]=g.skcd[1]=0;g.skcd[2]=99}
 u1.call(this,dt);
 if(G!==g||g.end||g.pause>0||g.cin)return;
 const h=human(),b=g.b;if(!h)return;
 for(const q of g.ps){if(q._tf>0)q._tf-=dt;if(q._fz>0)q._fz-=dt}
 /* dribble zig-zag: los rivales que se cruzan se paralizan de miedo */
 if(g.tz>0){g.tz-=dt;g.tzp+=dt*13;
  if(h.fall<=0){const fx=h.fx||1,fy=h.fy||0,s=Math.sin(g.tzp);
   h.x=cl(h.x+(fx*110-fy*s*250)*dt,PR,W-PR);h.y=cl(h.y+(fy*110+fx*s*250)*dt,PR,H-PR);
   if(b.o===h){b.x=h.x+fx*(PR+4);b.y=cl(h.y+9+fy*(PR+4),BR,H-BR)}}
  g.tzh.push({x:h.x,y:h.y,t:.3});
  for(const q of rivals(h))if(!(q._tf>0)&&q.fall<=0&&near(q,h)<46){q.stun=1.8;q.pk=1.4;q.vx*=.1;q.vy*=.1;q.sl=0;q._tf=2;g.fxs.push({t:.9,x:q.x,y:q.y-60,s:'¡Miedo!'})}}
 if(g.tzh)g.tzh=g.tzh.filter(p=>(p.t-=dt)>0);
 /* aura: huyen y entregan el balón */
 if(g.aura>0){g.aura-=dt;const R=190;
  for(const q of rivals(h)){const d=near(q,h);if(d>=R)continue;
   if(b.o===q){b.o=h;b.vx=b.vy=0;q.pk=1;q.stun=1.2;g.fxs.push({t:1,x:q.x,y:q.y-60,s:'¡Te entrega el balón!'})}
   else if(q.fall<=0&&d>PR){q.x=cl(q.x+(q.x-h.x)/d*90*dt,PR,W-PR);q.y=cl(q.y+(q.y-h.y)/d*90*dt,PR,H-PR);q.vx*=.6;q.vy*=.6;if(!(q._fz>0)){q._fz=1.5;g.fxs.push({t:.8,x:q.x,y:q.y-60,s:'¡Miedo!'})}}}}
 /* UltraKill en guardia */
 if(g.uk>0){g.uk-=dt;if(threat(g))fireUK(g,h);else if(g.uk<=0)g.skcd[1]=Math.min(g.skcd[1],8)}
 /* portales */
 const P=g.portals;if(P){P.t-=dt;P.cd-=dt;
  if(P.t<=0||P.uses<=0&&P.cd<-1.2)g.portals=null;
  else if(P.cd<=0&&P.uses>0&&h.fall<=0)for(const[s,d]of [[P.a,P.b],[P.b,P.a]])if(near(h,s)<26){
   const fx=h.fx||1,fy=h.fy||0;h.x=cl(d.x+fx*34,PR,W-PR);h.y=cl(d.y+fy*34,PR,H-PR);
   if(b.o===h){b.x=h.x+fx*(PR+4);b.y=cl(h.y+9+fy*(PR+4),BR,H-BR)}
   P.uses--;P.cd=.8;sfx(g,{kind:'arc',x:h.x,y:h.y,col:'#7a5cff',t:.4});fxt(h,'Portales: '+P.uses);break}}
};

/* ---------- dibujo ---------- */
const d1=draw;
draw=function(){d1.apply(this,arguments);const g=G;if(!g||!g.kp||!S.style||S.style.n!==TRIX)return;
 const e=document.getElementById('sl2');if(e)e.style.display=g.aw>0?'':'none';
 const c=cx,now=performance.now(),h=human();if(!h)return;c.save();
 for(const p of g.tzh||[]){c.globalAlpha=p.t*1.6;c.fillStyle=PUR;c.beginPath();c.ellipse(p.x,p.y+16,13,5,0,0,7);c.fill()}
 if(g.aura>0){const R=190,gr=c.createRadialGradient(h.x,h.y,20,h.x,h.y,R);gr.addColorStop(0,'rgba(60,10,110,0)');gr.addColorStop(1,'rgba(90,20,160,.38)');
  c.globalAlpha=.7+.3*Math.sin(now/120);c.fillStyle=gr;c.beginPath();c.arc(h.x,h.y,R,0,7);c.fill();
  c.globalAlpha=.9;c.strokeStyle=PUR;c.lineWidth=3;c.setLineDash([12,9]);c.lineDashOffset=-now/25;c.beginPath();c.arc(h.x,h.y,R-6,0,7);c.stroke();c.setLineDash([]);
  for(const q of rivals(h))if(near(q,h)<R){c.globalAlpha=1;c.fillStyle='#fff';c.strokeStyle='#05050f';c.lineWidth=4;c.font='900 22px sans-serif';c.textAlign='center';c.strokeText('!',q.x,q.y-52);c.fillText('!',q.x,q.y-52)}}
 if(g.portals)for(const[k,p]of [['a',g.portals.a],['b',g.portals.b]]){const live=g.portals.uses>0;c.globalAlpha=live?1:.35;
  const gr=c.createRadialGradient(p.x,p.y,4,p.x,p.y,34);gr.addColorStop(0,'#05050f');gr.addColorStop(.6,'#3a1c8f');gr.addColorStop(1,'rgba(122,92,255,0)');
  c.fillStyle=gr;c.beginPath();c.ellipse(p.x,p.y,24,38,0,0,7);c.fill();
  c.strokeStyle='#b8a6ff';c.lineWidth=3;for(let i=0;i<3;i++){c.beginPath();c.ellipse(p.x,p.y,10+i*6,18+i*8,0,now/260+i*2,now/260+i*2+4);c.stroke()}
  if(k=='a'){c.fillStyle='#fff';c.strokeStyle='#05050f';c.lineWidth=3;c.font='900 14px sans-serif';c.textAlign='center';c.strokeText('×'+g.portals.uses,p.x,p.y-46);c.fillText('×'+g.portals.uses,p.x,p.y-46)}}
 if(g.dg){const d=g.dg;c.globalAlpha=1;c.fillStyle='rgba(8,4,24,.9)';c.fillRect(0,0,W,H);
  c.fillStyle='rgba(255,59,78,.12)';for(let i=0;i<14;i++){const a=i*.45+now/2200;c.beginPath();c.moveTo(W/2,H/2);c.lineTo(W/2+Math.cos(a)*700,H/2+Math.sin(a)*700);c.lineTo(W/2+Math.cos(a+.12)*700,H/2+Math.sin(a+.12)*700);c.fill()}
  c.textAlign='center';c.lineJoin='round';c.font='italic 900 40px sans-serif';c.lineWidth=8;c.strokeStyle='#05050f';c.strokeText('¡DISPARO DEL DRAGÓN!',W/2,64);c.fillStyle='#ff3b4e';c.fillText('¡DISPARO DEL DRAGÓN!',W/2,64);
  c.font='800 16px sans-serif';c.lineWidth=4;c.strokeText('Dificultad: '+DIF[d.di],W/2,92);c.fillStyle='#fff';c.fillText('Dificultad: '+DIF[d.di],W/2,92);
  drawChar(150,420,.3,{dir:1,suit:SUITS[S.look.s],hair:S.look.h,ch:TRIX,w:Math.sin(now/180)*.15});drawChar(650,420,.3,{dir:-1,suit:SUITS[(S.look.s+2)%4],hair:HAIRS[2],w:Math.sin(now/200)*.15});
  const bx=120,bw=560,by=190,bh=44,fw=bw*d.bar/100;
  c.fillStyle='#2f7bff';c.fillRect(bx,by,bw,bh);const gr=c.createLinearGradient(bx,0,bx+bw,0);gr.addColorStop(0,'#7a2cff');gr.addColorStop(1,'#ff3b4e');c.fillStyle=gr;c.fillRect(bx,by,fw,bh);
  c.fillStyle='rgba(255,255,255,.35)';c.fillRect(bx,by,bw,bh*.35);c.lineWidth=7+d.pulse*20;c.strokeStyle='#05050f';c.strokeRect(bx,by,bw,bh);
  c.fillStyle='#fff';c.fillRect(bx+bw/2-2,by-8,4,bh+16);
  c.fillStyle='#ffb21f';c.beginPath();c.moveTo(bx+fw,by-6);c.lineTo(bx+fw+16+Math.sin(now/60)*5,by+bh/2);c.lineTo(bx+fw,by+bh+6);c.fill();
  c.font='900 18px sans-serif';c.lineWidth=5;c.textAlign='left';c.strokeText('TRIX',bx,by-16);c.fillStyle='#e8d6ff';c.fillText('TRIX',bx,by-16);c.textAlign='right';c.strokeText('PORTERO',bx+bw,by-16);c.fillStyle='#bcd6ff';c.fillText('PORTERO',bx+bw,by-16);
  c.textAlign='center';c.font='900 22px sans-serif';c.strokeText(Math.max(0,d.lim-d.t).toFixed(1)+'s',W/2,by+bh+36);c.fillStyle='#ffd21f';c.fillText(Math.max(0,d.lim-d.t).toFixed(1)+'s',W/2,by+bh+36);
  if(!d.res&&Math.floor(now/180)%2){c.font='italic 900 44px sans-serif';c.lineWidth=9;c.strokeText('¡TOCA RÁPIDO!',W/2,by+bh+110);c.fillStyle='#fff';c.fillText('¡TOCA RÁPIDO!',W/2,by+bh+110)}
  if(d.res){c.fillStyle='rgba(0,0,0,.55)';c.fillRect(0,H/2-52,W,104);c.font='italic 900 56px sans-serif';c.lineWidth=10;const t=d.res==1?'¡GOL SEGURO!':'¡ATAJADO!';c.strokeText(t,W/2,H/2+20);c.fillStyle=d.res==1?'#ffd21f':'#8fc2ff';c.fillText(t,W/2,H/2+20)}}
 c.restore()};

/* ---------- Roll: probabilidad limitada + cartel ---------- */
window.trixPick=i=>(isOpen()&&Math.random()<TRIX_RATE)?7:i;
window.trixBanner=c=>{if(!isOpen()||typeof crect!=='function')return;const days=Math.max(0,Math.ceil((TRIX_END-Date.now())/864e5));
 crect(c,10,338,112,52,'#fcf9f1','#ffd21f');skTx(c,'★ TRIX ★',66,357,13,'#fff');skTx(c,'LIMITADO · '+days+' d',66,375,11,'#ffd21f');skTx(c,TRIX_RATE*100+'% por giro',66,387,9,'#fff')};
try{let s=rollP.toString(),n=0;const rp=(a,b)=>{if(s.includes(a)){s=s.replace(a,b);n++}else console.warn('trix: no encuentro',a.slice(0,40))};
 rp("for(;i<a.length-1;i++){if(r<a[i])break;r-=a[i]}return i};","for(;i<a.length-1;i++){if(r<a[i])break;r-=a[i]}return window.trixPick(i)};");
 rp("gi(c,'gem',134,360,20);","window.trixBanner(c);gi(c,'gem',134,360,20);");
 if(n)rollP=(0,eval)('('+s+')')}catch(e){console.warn('trix roll',e)}
window.TRIX_END=TRIX_END;
})();
