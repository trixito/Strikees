/* ===== RANKED · reemplaza al Torneo =====
   Siempre 3v3 (cada IA con su rol DEF/MED/DEL). Sin empates (gol de oro). 6 ligas × 3 divisiones de 100 PR.
   El rival sube con tu liga: más nivel, más habilidades y despertar. Victoria sube PR (racha = bonus), derrota baja PR
   (escudo de 1 partido tras ascender; no se baja de liga con el escudo). Abandonar el partido cuenta como derrota. */
const RKT=[{n:'Reserva',c:'#9a7b5a'},{n:'Suplente',c:'#aab4c0'},{n:'Titular',c:'#ffd21f'},{n:'Estrella',c:'#2fd0ff'},{n:'Egoísta',c:'#b24dff'},{n:'Número 1',c:'#e8233b'}];
const RKD=[0,1,1,2,2,3];                 /* índice de dificultad (DM) por liga */
const RKR=['III','II','I'];
function rkS(){if(!S.rk)S.rk={pr:0,w:0,l:0,st:0,best:0,sh:0,h:[]};return S.rk}
function rkInfo(pr){pr=Math.max(0,pr|0);const t=Math.min(5,Math.floor(pr/300));if(t==5)return{t,d:0,tier:RKT[5],pts:pr-1500,next:null,label:'Número 1 · '+(pr-1500)+' PR',max:true};
 const w=pr-t*300,d=Math.floor(w/100);return{t,d,tier:RKT[t],pts:w%100,next:100,label:RKT[t].n+' '+RKR[d],max:false}}
function rkName(){return rkInfo(rkS().pr).label}
/* PR de un resultado: ganar da más en ligas bajas, la racha suma; perder resta más en ligas altas */
function rkDelta(win,st,t){return win?Math.max(12,24+Math.min(st,5)*2-t*2):-(14+t*2)}
function rkMatch(){const r=rkInfo(rkS().pr);return{d:RKD[r.t],big:!r.max&&r.pts+rkDelta(true,rkS().st+1,r.t)>=100,t:r.t,pr0:rkS().pr}}
function startRanked(){const m=rkMatch();size=3;RKM=m;start(.9+m.t*.03,'Ranked · '+rkName())}
function rkApply(win){const R=rkS(),a=rkInfo(R.pr);let dl=rkDelta(win,win?R.st+1:0,a.t),txt='';
 if(win){R.w++;R.st++;R.best=Math.max(R.best,R.st)}else{R.l++;R.st=0;if(R.sh>0){const fl=a.t*300+a.d*100;if(R.pr+dl<fl)dl=Math.min(0,fl-R.pr)}}
 R.sh=Math.max(0,(R.sh||0)-1);const old=R.pr;R.pr=Math.max(0,R.pr+dl);const b=rkInfo(R.pr);let rw=0,gm=0;
 if(win&&(b.t>a.t||b.d>a.d)){R.sh=1;rw=Math.round(80*(b.t+1)*CM());S.coins+=rw;if(b.t>a.t){gm=b.t;S.gems=(S.gems||0)+gm}txt=b.t>a.t?'¡ASCENSO DE LIGA! ':'¡Ascenso! '}
 else if(!win&&b.t<a.t)txt='Descenso de liga. ';
 R.h.unshift(win?1:0);R.h.length=Math.min(R.h.length,10);save();return{dl:R.pr-old,b,txt,rw,gm,st:R.st}}
function rankedEnd(g,win,res,c0){const o=rkApply(win);
 const t=(o.txt)+res+' · '+(o.dl>=0?'+':'')+o.dl+' PR · '+o.b.label+(win&&o.st>1?' · racha x'+o.st:'')+' · +'+c0+' monedas'+(o.rw?' · +'+o.rw+' de ascenso':'')+(o.gm?' · +'+o.gm+' gemas':'');
 ov(win?'¡Victoria Ranked!':'Derrota Ranked',t,'Volver al menú',menu);
 const b2=$('ob2');if(b2){b2.textContent='Otra Ranked';b2.style.display='';b2.onclick=()=>{$('ov').style.display='none';startRanked()}}}
function rankedForfeit(g){if(!g||g.end||!g.rk)return;g.end=true;rkApply(false)}
function rkBadge(t,sz){const c=RKT[t].c;return '<svg width='+sz+' height='+sz+' viewBox="0 0 60 60"><path d="M30 4 52 14v18c0 12-9 20-22 24C17 52 8 44 8 32V14z" fill="#fff" stroke="#111" stroke-width="3"/><path d="M30 10 46 18v14c0 9-7 15-16 18-9-3-16-9-16-18V18z" fill="'+c+'" stroke="#111" stroke-width="2"/><path d="M20 30l7 7 13-14" fill="none" stroke="#111" stroke-width="3.5" stroke-linecap="round" opacity=".55"/><path d="M14 20l10-5M16 26l9-5" stroke="#fff" stroke-width="1.6" opacity=".7"/></svg>'}
function rankedP(){if(!S.style){panel('<div class=col><b>Ranked</b><div>Primero haz tu Roll de estilo.</div><button id=rx class=g>Cerrar</button></div>');$('rx').onclick=closeP;return}
 const R=rkS(),r=rkInfo(R.pr),m=rkMatch(),pc=r.max?100:r.pts,dn=['Fácil','Normal','Difícil','Pro'][m.d];
 const hist=R.h.map(x=>'<i class="rkh '+(x?'w':'l')+'">'+(x?'V':'D')+'</i>').join('')||'<span class=rkm>Sin partidos aún</span>';
 panel('<div class="col rkp"><b>Ranked</b><div class=rkb>'+rkBadge(r.t,76)+'<div><div class=rkn>'+r.label+'</div><div class=rkm>Rival: '+dn+' · 3v3 · DEF / MED / DEL</div></div></div>'+
  '<div class=rkbar><div style="width:'+pc+'%;background:'+r.tier.c+'"></div></div><div class=rkm>'+(r.max?R.pr-1500+' PR':r.pts+' / 100 PR')+(m.big?' · ¡Partido de ascenso!':'')+(R.sh>0?' · Escudo activo':'')+'</div>'+
  '<div class=rkm>V '+R.w+' · D '+R.l+' · Racha '+R.st+' (mejor '+R.best+')</div><div class=rkhs>'+hist+'</div>'+
  '<button id=rp class=r>Jugar Ranked</button><button id=rx class=g>Cerrar</button></div>');
 $('rx').onclick=closeP;$('rp').onclick=()=>{closeP();startRanked()}}
