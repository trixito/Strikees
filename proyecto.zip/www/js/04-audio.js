/* Striker Rivals · capa de sonido, vibración y rendimiento. No modifica index.html. */
(()=>{
const AC=window.AudioContext||window.webkitAudioContext;
let ac=null,muted=false,mg=null,vol=1,vibOn=true;
try{muted=localStorage.getItem('sr_mute')==='1';const v=parseFloat(localStorage.getItem('sr_vol'));if(v>=0&&v<=1)vol=v;vibOn=localStorage.getItem('sr_vib')!=='0'}catch(e){}
const wake=()=>{try{if(!ac&&AC){ac=new AC();mg=ac.createGain();mg.gain.value=vol;mg.connect(ac.destination)}if(ac&&ac.state==='suspended')ac.resume()}catch(e){}};
addEventListener('pointerdown',wake,true);addEventListener('keydown',wake,true);
document.addEventListener('visibilitychange',()=>{try{if(ac){if(document.hidden)ac.suspend();else ac.resume()}}catch(e){}});
const vib=p=>{try{if(!muted&&vibOn&&navigator.vibrate)navigator.vibrate(p)}catch(e){}};
function tone(f,d,type,v,f2,dl){if(!ac||muted)return;const t=ac.currentTime+(dl||0),o=ac.createOscillator(),g=ac.createGain();
 o.type=type||'square';o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
 g.gain.setValueAtTime(v||.15,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(mg||ac.destination);o.start(t);o.stop(t+d+.02)}
function noise(d,v,dl){if(!ac||muted)return;const n=(ac.sampleRate*d)|0,b=ac.createBuffer(1,n,ac.sampleRate),a=b.getChannelData(0);
 for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=ac.createBufferSource(),g=ac.createGain();g.gain.value=v;s.buffer=b;s.connect(g);g.connect(mg||ac.destination);s.start(ac.currentTime+(dl||0))}
const sfx={
 kick(){tone(200,.09,'sine',.4,50);noise(.04,.18)},
 power(){tone(150,.18,'sawtooth',.25,40);noise(.08,.3)},
 goal(){[523,659,784,1047].forEach((f,i)=>tone(f,.22,'square',.14,0,i*.09));noise(1.4,.12)},
 conc(){tone(300,.4,'triangle',.2,120);noise(.8,.08)},
 whistle(){tone(2300,.18,'sine',.12);tone(2300,.3,'sine',.12,0,.22)},
 tackle(){noise(.12,.3);tone(90,.14,'sine',.35,40)},
 save(){tone(260,.12,'triangle',.25,500)},
 boost(){tone(300,.5,'sawtooth',.12,1400)},
 skill(){tone(500,.2,'square',.1,1100)},
 win(){[523,659,784,1047,784,1047].forEach((f,i)=>tone(f,.18,'square',.13,0,i*.12))},
 lose(){[392,330,262].forEach((f,i)=>tone(f,.3,'triangle',.18,0,i*.2))}
};
/* eventos del juego */
const kb=kickBall;kickBall=function(){sfx.kick();return kb.apply(this,arguments)};
const cr=chargeRelease;chargeRelease=function(){const b=G&&G.b,pv=b?Math.hypot(b.vx,b.vy):0;const r=cr.apply(this,arguments);
 if(b&&Math.hypot(b.vx,b.vy)>pv+250){sfx.power();vib(25)}return r};
const gl=goal;goal=function(t){const r=gl.apply(this,arguments);if(t==0){sfx.goal();vib([80,50,160])}else{sfx.conc();vib(220)}return r};
const st=start;start=function(){const r=st.apply(this,arguments);sfx.whistle();return r};
const fi=finish;finish=function(){const g=G,was=g&&g.end;const r=fi.apply(this,arguments);
 if(g&&g.end&&!was){sfx.whistle();setTimeout(()=>g.sc[0]>g.sc[1]?sfx.win():g.sc[0]<g.sc[1]?sfx.lose():0,500)}return r};
(function loop(){try{if(G&&G.fxs)for(const f of G.fxs)if(!f.sd){f.sd=1;const s=f.s||'';
 if(/Barrida|Robo|Bloq|Tobillos/.test(s)){sfx.tackle();vib(30)}else if(/Atajada/.test(s))sfx.save();
 else if(/FLOW|DESPERTAR/.test(s)){sfx.boost();vib([40,30,80])}}}catch(e){}requestAnimationFrame(loop)})();
/* botón mute */
const mb=document.createElement('button');mb.style.cssText='position:absolute;top:8px;right:72px;padding:6px 10px;font-size:15px;background:rgba(0,0,0,.45);z-index:5';
const lab=()=>{mb.innerHTML=ico(muted?'mute':'spk')};lab();
mb.onclick=()=>{muted=!muted;try{localStorage.setItem('sr_mute',muted?'1':'0')}catch(e){}lab();wake();if(!muted)sfx.kick()};
document.getElementById('game').appendChild(mb);
/* caché de sprites: cada personaje se dibuja una vez y luego se reutiliza */
const dc=drawChar,cache=new Map();
drawChar=function(x,y,sc,o){
 if(o.rot&&Math.abs(o.rot)===1.5)o=Object.assign({},o,{rot:-o.rot}); // caídas hacia atrás
 if(o.rot)return dc(x,y,sc,o);
 const w=Math.round((o.w||0)*6)/6,key=o.suit.join()+'|'+o.hair+'|'+(o.ch||'')+'|'+(o.dir||1)+'|'+w+'|'+sc;
 let e=cache.get(key);
 if(!e){if(cache.size>1500)cache.clear();
  const ax=Math.ceil(340*sc)+4,ay=Math.ceil(840*sc)+4,c=document.createElement('canvas');c.width=ax*2;c.height=ay+Math.ceil(30*sc)+4;
  const px=X;X=c.getContext('2d');try{dc(ax,ay,sc,Object.assign({},o,{w}))}finally{X=px}
  e={c,ax,ay};cache.set(key,e)}
 X.drawImage(e.c,Math.round(x-e.ax),Math.round(y-e.ay))};

/* ===== habilidades: sonidos y efectos ===== */
const SF={
 dash(){tone(400,.3,'sawtooth',.12,1800);noise(.3,.22)},
 shot(){tone(100,.4,'sawtooth',.3,30);noise(.2,.4);tone(1200,.3,'square',.07,300)},
 turn(){[600,800,1000].forEach((f,i)=>tone(f,.1,'triangle',.18,0,i*.07))},
 pass(){tone(700,.12,'triangle',.22,1000)},
 magnet(){tone(200,.7,'sine',.22,900)},
 wall(){tone(120,.3,'square',.2);tone(240,.25,'square',.14,0,.05)},
 blitz(){noise(.4,.2);tone(250,.4,'sawtooth',.12,700)},
 meta(){tone(880,.5,'sine',.15,220);tone(1320,.5,'sine',.1,330)},
 chaos(){tone(90,.5,'sawtooth',.3,400);noise(.3,.3);tone(700,.1,'square',.1,200,.1)}
};
const COL={dash:'#9fe8ff',shot:'#ffb21f',turn:'#c36bff',pass:'#2fd0ff',magnet:'#5cffb0',wall:'#ffffff',blitz:'#ff8a4a',meta:'#4aa3ff',chaos:'#b24dff'};
const FXL=[],tr=[];let trail=null;
const us=useSk;useSk=function(i){const g=G,ok=g&&g.skcd,id=ok?sk(S.style)[i]:null,b4=ok?g.skcd[i]:0;const r=us.apply(this,arguments);
 if(id&&g===G&&g.skcd[i]>0&&!(b4>0)){(SF[id]||sfx.skill)();vib(40);const n=performance.now();FXL.push({id,t0:n});if(id=='shot'||id=='chaos'||id=='pass')trail={id,until:n+1000}}return r};
window.SR={tone,noise,vib,sfx,SF,COL,fx(id,tl){(SF[id]||sfx.skill)();vib(40);const n=performance.now();FXL.push({id,t0:n});if(tl)trail={id,until:n+1000}}};
/* ajustes de volumen / vibración (los usa 12-pausa.js) */
const sv=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
Object.assign(window.SR,{
 getVol:()=>vol,setVol(v){vol=Math.max(0,Math.min(1,v));sv('sr_vol',vol);if(mg)mg.gain.value=vol},
 getVib:()=>vibOn,setVib(v){vibOn=!!v;sv('sr_vib',vibOn?'1':'0')},
 isMuted:()=>muted,setMuted(v){muted=!!v;sv('sr_mute',muted?'1':'0');lab();wake()}});
const dr=draw;draw=function(){dr.apply(this,arguments);const g=G;if(!g||!g.b||g.end||!g.kp)return;
 const h=human(),now=performance.now(),c=cx,hx=h.x,hy=h.y-20;c.save();
 if(trail&&now<trail.until){tr.push({x:g.b.x,y:g.b.y});if(tr.length>14)tr.shift();
  tr.forEach((q,i)=>{c.globalAlpha=i/tr.length*.6;c.fillStyle=COL[trail.id];c.beginPath();c.arc(q.x,q.y,BR*(.6+i/tr.length),0,7);c.fill()})}else tr.length=0;
 if(g.act>0){const k=g.actK;
  if(k=='magnet'){for(let j=0;j<3;j++){const r=170*(1-((now/1000*1.2+j/3)%1));c.globalAlpha=.5*(r/170);c.strokeStyle=COL.magnet;c.lineWidth=3;c.beginPath();c.arc(hx,hy,r,0,7);c.stroke()}}
  else if(k=='dash'){c.strokeStyle=COL.dash;c.lineWidth=3;const d=h.fx||1;for(let j=0;j<7;j++){const y=hy-30+j*10,len=30+((j*37+now/8)%40);c.globalAlpha=.6;c.beginPath();c.moveTo(hx-d*18,y);c.lineTo(hx-d*(18+len),y);c.stroke()}}
  else if(k=='turbo'){const gr=c.createRadialGradient(hx,hy,5,hx,hy,55);gr.addColorStop(0,'rgba(255,150,60,.55)');gr.addColorStop(1,'rgba(255,80,0,0)');c.globalAlpha=.6+.4*Math.sin(now/60);c.fillStyle=gr;c.fillRect(hx-60,hy-60,120,120)}}
 for(let i=FXL.length-1;i>=0;i--){const f=FXL[i],p=(now-f.t0)/700;if(p>=1){FXL.splice(i,1);continue}
  c.globalAlpha=1-p;c.strokeStyle=COL[f.id]||'#fff';c.lineWidth=5*(1-p)+1;
  if(f.id=='turn'){for(let j=0;j<3;j++){const a=p*9+j*2.09;c.beginPath();c.arc(hx+Math.cos(a)*26,hy+Math.sin(a)*26,6,0,7);c.stroke()}}
  else{c.beginPath();c.arc(hx,hy,20+p*70,0,7);c.stroke()}
  if(f.id=='meta'||f.id=='shot'){c.fillStyle=COL[f.id];c.globalAlpha=(1-p)*.25;c.fillRect(0,0,W,H)}}
 c.restore()};
/* ===== pantalla de carga ===== */
const ld=document.createElement('div');ld.id='ld';
ld.style.cssText='position:fixed;inset:0;z-index:99;background:radial-gradient(circle at 50% 40%,#1a2a6a,#070a1c);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;color:#fff;font-family:"Trebuchet MS",sans-serif;transition:opacity .5s;touch-action:none';
ld.innerHTML='<div style="font:italic 900 40px sans-serif;letter-spacing:-1px">STRIKER <span style="color:#e8233b">RIVALS</span></div><div style="width:min(70vw,360px);height:12px;border-radius:8px;background:#10304f;overflow:hidden"><div id="ldb" style="height:100%;width:0;background:linear-gradient(90deg,#2fd0ff,#e8233b)"></div></div><div id="ldt" style="font-size:14px;color:#9fb0e8;text-align:center;padding:0 24px"></div>';
document.body.appendChild(ld);
const TIPS=['Mantén Kick para cargar el tiro y arrastra para apuntar','Regatea justo cuando te vayan a barrer: ¡tobillos rotos!','Cada gol llena tu Flow y tu Despertar','Cada estilo trae 3 habilidades distintas','Con balón no puedes hacer barrida'];
document.getElementById('ldt').textContent='Consejo: '+TIPS[Math.floor(Math.random()*TIPS.length)];
const jobs=[],hairs=[...new Set([S.look&&S.look.h].concat(HAI))].filter(Boolean);
for(let s=0;s<SUITS.length;s++)for(const hr of hairs)for(const d of [1,-1])for(let w=-6;w<=6;w++)jobs.push([s,hr,d,w/6]);
const T0=performance.now(),NJ=jobs.length;let ji=0;
(function warm(){const el=performance.now()-T0;
 for(let k=0;k<30&&ji<NJ;k++,ji++){const j=jobs[ji];try{drawChar(-500,-500,.1,{suit:SUITS[j[0]],hair:j[1],dir:j[2],w:j[3]})}catch(e){}}
 document.getElementById('ldb').style.width=Math.min(100,Math.min(ji/NJ,el/1500)*100)+'%';
 if(ji>=NJ&&el>1500){ld.style.opacity=0;setTimeout(()=>ld.remove(),500)}else requestAnimationFrame(warm)})();
})();
