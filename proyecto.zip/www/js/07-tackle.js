/* tackle.js · robo y barrida más fluidos
   - Botón Barrida: si hay un rival con balón pegado = ROBO rápido; si no = barrida con autoapuntado
   - La barrida apunta al rival con balón (o balón suelto) dentro de un cono, usando la dirección del joystick
   - Alcance mayor, fallo menos castigado, y el balón queda al alcance del que barre */
(()=>{
const near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),T=SR.tone,N=SR.noise;
const say=(p,s)=>G.fxs.push({t:1.1,x:p.x,y:p.y-60,s});
const prot=o=>o.dr>0||performance.now()<(o.shU||0)||(o.h&&G.aw>0);
const wins=p=>p.h||Math.random()<.3+.3*G.lvl;
slide=function(p){
 const g=G;if(!g||!p||g.end||g.pause>0||g.cin||p.slc>0||p.fall>0||p.dr>0||p.sl>0||g.b.o===p)return;
 const b=g.b,o=b.o;
 /* 1) ROBO de cerca */
 if(o&&o.t!=p.t&&near(o,p)<PR*2+4){
  p.slc=1;face(p,o.x-p.x,o.y-p.y);
  if(prot(o)){p.fall=.9;say(o,o.dr>0?'¡Tobillos rotos!':'¡Bloqueado!');if(o.h)gain(35,10);T(300,.15,'square',.2,100)}
  else if(!wins(p)){p.stun=.35;say(p,'¡Fallo!')}
  else{b.o=p;o.stun=.7;o.pk=.7;say(p,'¡Robo!');if(p.h)gain(15,6);T(700,.08,'square',.2,300);N(.06,.25)}
  return}
 /* 2) BARRIDA con autoapuntado */
 let dx=p.fx,dy=p.fy;
 if(p.h){const m=Math.hypot(joy.x,joy.y);if(m>.25){dx=joy.x/m;dy=joy.y/m}}
 let tg=null,bd=200;
 const cand=o&&o.t!=p.t?o:(!o?b:null);
 if(cand){const ex=cand.x-p.x,ey=cand.y-p.y,d=Math.hypot(ex,ey)||1;if(d<bd&&(ex*dx+ey*dy)/d>.3){tg=[ex/d,ey/d]}}
 if(tg){dx=dx*.3+tg[0]*.7;dy=dy*.3+tg[1]*.7;const m=Math.hypot(dx,dy)||1;dx/=m;dy/=m}
 p.fx=dx;p.fy=dy;p.slc=1.5;p.sl=SLD;p.hit=false;T(250,.2,'sawtooth',.12,120);
};
tackle=function(p){
 const g=G,b=g.b,o=b.o;
 if(p.sl>0&&p.sl<=.06&&!p.hit&&p.fall<=0){p.fall=.4}   /* fallo: caída corta (antes .7) */
 if(p.fall>0||p.hit||p.sl<=0)return;
 /* balón suelto: la barrida lo gana */
 if(!o&&p.pk<=0&&near(b,p)<PR+BR+16){b.o=p;b.vx=b.vy=0;p.hit=true;p.sl=.12;say(p,'¡Balón!');return}
 if(!o||o.t==p.t||near(o,p)>PR*2+14)return;
 if(prot(o)){p.fall=1.5;p.sl=0;say(o,o.dr>0?'¡Tobillos rotos!':'¡Bloqueado!');if(o.h)gain(35,10);T(300,.15,'square',.2,100);return}
 p.hit=true;o.fall=1.1;o.pk=.9;o.stun=.4;p.pk=0;p.sl=.12;
 b.o=null;b.x=p.x+p.fx*(PR+BR+4);b.y=p.y+p.fy*(PR+BR+4);b.vx=p.fx*90;b.vy=p.fy*90;   /* balón queda delante del que barre */
 say(o,'¡Barrida!');if(p.h)gain(25,5);T(160,.14,'sawtooth',.3,60);N(.08,.3)};
})();
