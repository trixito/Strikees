/* Striker Rivals · pausa, ajustes (volumen/vibración) y "Cómo jugar".
   Capa nueva: solo envuelve upd() y start(); no modifica el resto del juego. */
(()=>{
let PZ=false,pm=null;
const gs=id=>document.getElementById(id),
 sg=k=>{try{return localStorage.getItem(k)}catch(e){return null}},
 ss=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}},
 inMatch=()=>!!(G&&!G.end);

document.head.appendChild(Object.assign(document.createElement('style'),{textContent:
 '.sr-md,.sr-md *{touch-action:pan-y}.sr-md button{padding:10px}.sr-md input[type=range]{padding:0;border:0;height:28px;accent-color:var(--ac)}'+
 '.sr-md .rw{display:flex;gap:8px}.sr-md .rw>*{flex:1}.sr-dots{display:flex;gap:6px;justify-content:center}'+
 '.sr-dots i{width:8px;height:8px;border-radius:50%;background:var(--mut);opacity:.4}.sr-dots i.on{opacity:1;background:var(--ac)}'}));

function modal(){const d=document.createElement('div');d.className='sr-md';
 d.style.cssText='position:fixed;inset:0;z-index:30;background:rgba(5,8,20,.9);display:flex;align-items:center;justify-content:center';
 d.innerHTML='<div style="background:var(--card);color:var(--fg);border-radius:16px;padding:14px;width:min(420px,94vw);max-height:92vh;overflow:auto;display:flex;flex-direction:column;gap:8px;text-align:center"></div>';
 document.body.appendChild(d);return d}
const btn=(p,t,cls,fn)=>{const b=document.createElement('button');b.innerHTML=t;b.className=cls||'';b.onclick=fn;p.appendChild(b);return b};
const row=p=>{const r=document.createElement('div');r.className='rw';p.appendChild(r);return r};

function releaseInput(){try{C.on=false;C.drag=false;joy.x=joy.y=0;for(const k in keys)keys[k]=false}catch(e){}}

/* ===== pausa ===== */
const u1=upd;upd=function(dt){if(PZ)return;return u1.apply(this,arguments)};
function resume(){PZ=false;if(pm){pm.remove();pm=null}}
function pause(){if(PZ||!inMatch())return;PZ=true;releaseInput();
 pm=modal();const b=pm.firstChild;
 b.innerHTML='<b style="font-size:24px">Pausa</b>';
 btn(b,'Continuar','r',resume);
 const r=row(b);btn(r,'Cómo jugar','g',()=>tutorial());btn(r,'Ajustes','g',()=>settings());
 btn(b,'Salir del partido','g',()=>{resume();gs('ex').onclick()})}

const pb=document.createElement('button');pb.className='m';pb.innerHTML='⏸';
pb.style.cssText='position:absolute;top:8px;right:122px;padding:6px 10px;font-size:15px;background:rgba(0,0,0,.45);z-index:5';
pb.onclick=pause;gs('game').appendChild(pb);
setInterval(()=>{pb.style.visibility=(inMatch()&&!PZ)?'visible':'hidden'},250);
addEventListener('keydown',e=>{if(e.key==='Escape'&&!PZ)pause()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});

/* ===== ajustes ===== */
function settings(){const d=modal(),b=d.firstChild;
 b.innerHTML='<b style="font-size:22px">Ajustes</b>'+
  '<label style="display:flex;flex-direction:column;gap:2px;text-align:left;font-size:15px;color:var(--fg)"><span>Volumen de efectos: <b id="srv"></b></span><input id="srr" type="range" min="0" max="100" step="5"></label>';
 const r=b.querySelector('#srr'),v=b.querySelector('#srv');
 r.value=Math.round(SR.getVol()*100);v.textContent=r.value+'%';
 r.oninput=()=>{SR.setVol(r.value/100);v.textContent=r.value+'%'};
 r.onchange=()=>SR.sfx.kick();
 const mu=btn(b,'','',()=>{SR.setMuted(!SR.isMuted());lm();if(!SR.isMuted())SR.sfx.kick()}),
  vb=btn(b,'','',()=>{SR.setVib(!SR.getVib());lv();if(SR.getVib())SR.vib(40)});
 const lm=()=>{mu.textContent='Sonido: '+(SR.isMuted()?'silenciado':'activado');mu.className=SR.isMuted()?'g':'on'},
  lv=()=>{vb.textContent='Vibración: '+(SR.getVib()?'activada':'desactivada');vb.className=SR.getVib()?'on':'g'};
 lm();lv();
 btn(b,'Cerrar','r',()=>d.remove())}

/* ===== cómo jugar ===== */
const STEPS=[
 ['pad','Moverte','Usa el joystick de la izquierda. En PC: WASD.'],
 ['ball','Tirar y pasar','Mantén Kick, arrastra para apuntar y suelta para tirar. Pass manda el balón a un compañero. En PC: espacio y P.'],
 ['run','Defender y regatear','Slide es una barrida (no se puede con balón). Dribble esquiva al rival. Run corre más, pero gasta energía.'],
 ['sparkle','Habilidades y regalos','Cada estilo trae 3 habilidades, una por botón. Los goles llenan FLOW y DESPERTAR: tócalos cuando digan LISTO. Al despertar hay una cinemática y cada gol suma 3 s. En Navidad recoge regalos para ganar premios.']];
function tutorial(after){let i=0;const d=modal(),b=d.firstChild;
 const end=()=>{d.remove();ss('sr_tut','1');if(after)after()};
 (function render(){const s=STEPS[i],last=i==STEPS.length-1;
  b.innerHTML='<div style="font-size:48px;line-height:1">'+ico(s[0])+'</div><b style="font-size:20px">'+s[1]+'</b>'+
   '<span style="font-size:15px;line-height:1.35">'+s[2]+'</span>'+
   '<div class="sr-dots">'+STEPS.map((_,k)=>'<i'+(k==i?' class="on"':'')+'></i>').join('')+'</div>';
  const r=row(b);
  if(i==0)btn(r,'Saltar','g',end);else btn(r,'Atrás','g',()=>{i--;render()});
  btn(r,last?'¡A jugar!':'Siguiente','r',()=>{if(last)end();else{i++;render()}})})()}

/* primer partido: se muestra el tutorial una sola vez (con el juego en pausa) */
const s1=start;start=function(){const r=s1.apply(this,arguments);
 if(!sg('sr_tut')){PZ=true;releaseInput();tutorial(()=>{PZ=false})}return r};

/* botones del lobby (solo visibles fuera de partido: clase .lu) */
function lb(t,right,fn){const b=document.createElement('button');b.className='lu';b.innerHTML=t;
 b.style.cssText='position:absolute;top:8px;right:'+right+'px;padding:6px 10px;font-size:15px;background:rgba(0,0,0,.45);z-index:5';
 b.onclick=fn;gs('game').appendChild(b)}
lb(ico('gear'),8,()=>settings());lb(ico('question'),122,()=>tutorial());
})();
