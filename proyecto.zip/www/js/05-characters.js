/* PERSONAJES: Isagi, Bachira, Nagi, Shidou, Kaiser, Loki. Teclas: C, V, B = habilidades · G = Awakening */
(()=>{
const {tone,noise,SF,COL}=SR,cl=(v,a,b)=>Math.max(a,Math.min(b,v)),near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
/* rarezas nuevas (Mítico, World Class, Master) */
RN.push('Mítico','World Class','Master');RC.push('#ff3b6b','#2ff7d0','#ffffff');DIF.push('Mítica','Mundial','Máxima');
NORM.length=0;NORM.push(50,26,13,6,3,1.5,.5);LUCK.length=0;LUCK.push(26,28,21,13,7,3.5,1.5);
/* personajes */
const XN='Shidou Repartidor';
const CHR={Isagi:{r:1,sk:['direct','fadeaway','finalshot']},Bachira:{r:2,sk:['steal','nutmeg','trance']},Nagi:{r:3,sk:['trap','fakevolley','trapshot']},
 Shidou:{r:4,sk:['header','drive','bigbang']},Kaiser:{r:5,sk:['kimpact','kdribble','route'],awk:'magnus'},Loki:{r:6,sk:['accel','tooslow','godspeed']}};
CHR[XN]={r:4,sk:['xpress','xbomb','xsleigh']};NSK[XN]=CHR[XN].sk;window.CHR=CHR;
const AWK=new Set(['xsleigh','finalshot','trance','trapshot','bigbang','magnus','godspeed']),TR=new Set(['xbomb','xsleigh','direct','finalshot','trapshot','drive','bigbang','kimpact','magnus','header']);
for(const n in CHR){const c=CHR[n];ST.push([n,c.r,'shot']);const a=c.sk.slice();if(c.awk)Object.defineProperty(a,2,{get:()=>G&&G.aw>0?c.awk:c.sk[2]});NSK[n]=a}
const D=(id,n,cd,need)=>{SKD[id]={n,cd,need}};
D('xpress','Entrega Express',30);D('xbomb','Regalo Bomba',45,1);D('xsleigh','Trineo Final',99,1);
Object.assign(COL,{xpress:'#7dff9a',xbomb:'#ff3b4b',xsleigh:'#ffffff'});
D('direct','Direct Shot',30,1);D('fadeaway','Fadeaway',55,1);D('finalshot','Final Shot',99,1);
D('steal','Steal / Heel',30);D('nutmeg','Nutmeg',45);D('trance','Monster Trance',99);
D('trap','Trap',25);D('fakevolley','Fake Volley',40);D('trapshot','Trap Shot',99);
D('header','Dragon Header',35);D('drive','Dragon Drive',50,1);D('bigbang','Big Bang Drive',99,1);
D('kimpact','Kaiser Impact',40,1);D('kdribble','Emperor Dribble',50);D('route','Emperor Route',55);D('magnus','Impact Magnus',99,1);
D('accel','Accelerate',30);D('tooslow','Too Slow',55);D('godspeed','Godspeed',99);
Object.assign(COL,{direct:'#2fd0ff',fadeaway:'#9fe8ff',finalshot:'#2fd0ff',steal:'#ffb21f',nutmeg:'#ff8ad8',trance:'#ffd21f',trap:'#b24dff',fakevolley:'#c36bff',trapshot:'#b24dff',header:'#ff6a3d',drive:'#ff3b6b',bigbang:'#ff3b6b',kimpact:'#2ff7d0',kdribble:'#2ff7d0',route:'#2ff7d0',magnus:'#2ff7d0',accel:'#fff36b',tooslow:'#fff36b',godspeed:'#fff36b'});
Object.assign(SF,{
 direct(){tone(150,.15,'sawtooth',.3,50);noise(.06,.3)},fadeaway(){noise(.35,.25);tone(300,.3,'sawtooth',.12,1200)},finalshot(){tone(60,.9,'sawtooth',.25,300);tone(1500,.9,'sine',.07,200)},
 steal(){tone(900,.08,'square',.15);tone(500,.12,'square',.15,0,.07)},nutmeg(){tone(500,.1,'triangle',.2,900);tone(900,.1,'triangle',.2,500,.1)},trance(){tone(110,1.2,'sawtooth',.16,440);tone(220,1.2,'square',.07,880)},
 trap(){tone(700,.25,'sine',.2,150);noise(.1,.15)},fakevolley(){tone(500,.12,'triangle',.18,300);tone(800,.15,'triangle',.18,1200,.1)},trapshot(){tone(500,.4,'sine',.2,100);tone(80,.8,'sawtooth',.25,260,.45)},
 header(){tone(250,.2,'square',.2,700);noise(.1,.2,.1)},drive(){tone(120,.35,'sawtooth',.3,40);noise(.25,.35);tone(1400,.35,'square',.06,300)},bigbang(){tone(50,1.2,'sawtooth',.3,400);noise(.8,.3,.3);tone(1800,1,'sine',.06,100)},
 kimpact(){tone(100,.3,'sawtooth',.35,30);noise(.2,.4)},kdribble(){noise(.3,.25);tone(220,.3,'sawtooth',.15,880)},route(){tone(400,.3,'triangle',.2,1600)},magnus(){tone(70,1,'sawtooth',.3,500);tone(1200,1,'sine',.08,300)},
 accel(){noise(.5,.25);tone(200,.5,'sawtooth',.15,2000)},tooslow(){tone(1600,.15,'square',.15,300);noise(.3,.3)},godspeed(){tone(2000,.12,'square',.14,200);noise(.18,.3)}});

/* utilidades compatibles con jugador humano e IA */
const isH=h=>typeof human==='function'&&G&&G.ps&&h===human();
const aim=h=>{if(isH(h))return aimDir(h);const gx=h.t?0:W,gy=H/2+(Math.random()-.5)*90,dx=gx-h.x,dy=gy-h.y,m=Math.hypot(dx,dy)||1;return{x:dx/m,y:dy/m}};
const fxt=(h,s)=>{if(!G||!G.fxs)return;G.fxs.push({t:1.2,x:h.x,y:h.y-110,s:isH(h)?s:`[IA] ${s}`})};
const rivals=h=>(G&&G.ps?G.ps.filter(q=>q.t!==h.t):[]);
const kick=(h,pw)=>{const a=aim(h);kickBall(h,h.x+a.x*400,h.y+a.y*400,pw)};
const dash=(h,t)=>{const a=aim(h);h.dr=t;h.ddx=a.x;h.ddy=a.y;h.fx=a.x;h.fy=a.y};
const inv=(h,ms)=>{h.shU=performance.now()+ms};
const cin=(h,n,col,d,fn,pre)=>{if(!isH(h)){if(pre)pre();if(fn)fn();return 1}G.cin={n,col,t:d,d,fn};if(pre)pre();return 1};
const shotCin=(h,n,col,d,pw,pierce)=>cin(h,n,col,d,()=>{kick(h,pw);h._pierce=pierce||0;if(isH(h))G.pierce=pierce||0},null);
const setPlow=(g,h,t,r)=>{if(isH(h))g.plow={t,r};else h._plow={t,r}};
const setSpr=(g,h,t,m)=>{if(isH(h))g.spr={t,m};else h._spr={t,m}};
const setDirect=(g,h,v)=>{if(isH(h))g.direct=v;else h._direct=v};
const setTrance=(g,h,v)=>{if(isH(h)){g.trance=v;g.tcd=0}else{h._trance=v;h._tcd=0}};
const addSkillFx=(g,fx)=>{if(!g)return;g._sfx=g._sfx||[];g._sfx.push(fx)};

/* habilidades */
const K={
 xpress(g,h){dash(h,.5);inv(h,700);const b=g.b;if(!b.o&&near(b,h)<170){b.o=h;b.vx=b.vy=0}setSpr(g,h,2,.4);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#7dff9a',t:.35});fxt(h,'¡Entrega Express!');return 1},
 xbomb(g,h){if(g.b.o!==h)return 0;for(const q of rivals(h))if(near(q,h)<140){q.fall=1.5;if(g.b.o===q)g.b.o=null}kick(h,880);h._pierce=.3;if(isH(h))g.pierce=.3;addSkillFx(g,{kind:'shards',x:h.x,y:h.y-8,col:'#ff3b4b',t:.45});fxt(h,'¡Regalo Bomba!');return 1},
 xsleigh(g,h){if(g.b.o!==h)return 0;return cin(h,'TRINEO FINAL','#ff3b4b',1.1,()=>{const d=Math.random()<.5?-1:1;kickBall(h,W,H/2-d*100,920);g.curve={t:.8,a:d*1100};h._pierce=.8;if(isH(h))g.pierce=.8})},
 direct(g,h){if(g.b.o!==h)return 0;kick(h,800);setDirect(g,h,.5);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#2fd0ff',t:.35});return 1},
 fadeaway(g,h){if(g.b.o!==h)return 0;dash(h,.55);setPlow(g,h,.6,50);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:-h.fx,dy:-h.fy,col:'#9fe8ff',t:.4});return 1},
 finalshot(g,h){return g.b.o===h?shotCin(h,'FINAL SHOT','#2fd0ff',.9,900):0},
 steal(g,h){const b=g.b,o=b.o;if(o===h)return isH(h)&&pass(1.3)?1:0;
  if(o&&o.t!==h.t&&near(o,h)<95){b.o=h;o.stun=.8;o.pk=.8;addSkillFx(g,{kind:'shards',x:h.x,y:h.y-8,col:'#ffb21f',t:.35});fxt(h,'¡Steal!');return 1}return 0},
 nutmeg(g,h){const a=aim(h);let t=null,bd=130;for(const q of rivals(h)){const dx=q.x-h.x,dy=q.y-h.y,d=Math.hypot(dx,dy);if(d<bd&&(dx*a.x+dy*a.y)/d>.5){t=q;bd=d}}
  if(!t)return 0;t.fall=1.6;t.vx=t.vy=0;if(g.b.o===t)g.b.o=null;dash(h,.5);addSkillFx(g,{kind:'cut',x:t.x,y:t.y-4,dx:a.x,dy:a.y,col:'#ff8ad8',t:.4});fxt(h,'¡Caño!');return 1},
 trance(g,h){setTrance(g,h,4);inv(h,4000);addSkillFx(g,{kind:'shards',x:h.x,y:h.y-10,col:'#ffd21f',t:.5});fxt(h,'MONSTER TRANCE');return 1},
 trap(g,h){const b=g.b;if(b.o||near(b,h)>190)return 0;b.vx=b.vy=0;b.o=h;addSkillFx(g,{kind:'arc',x:b.x,y:b.y,col:'#b24dff',t:.45});fxt(h,'¡Trap!');return 1},
 fakevolley(g,h){dash(h,.35);const k=g.kp[1];k.y=cl(k.y+(Math.random()<.5?-1:1)*55,GY0+12,GY1-12);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#c36bff',t:.35});fxt(h,'¡Finta!');return 1},
 trapshot(g,h){const b=g.b;if(!(b.o===h||(!b.o&&near(b,h)<260)))return 0;return cin(h,'TRAP SHOT','#b24dff',1,()=>{kick(h,900);h._pierce=.35;if(isH(h))g.pierce=.35},()=>{b.o=h;b.vx=b.vy=0})},
 header(g,h){const b=g.b;dash(h,.3);inv(h,400);if(!b.o&&near(b,h)<150){kick(h,880);addSkillFx(g,{kind:'shards',x:b.x,y:b.y,col:'#ff6a3d',t:.4});fxt(h,'¡DRAGON HEADER!');return 1}return 2},
 drive(g,h){if(g.b.o!==h)return 0;dash(h,.2);kick(h,900);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#ff3b6b',t:.4});return 1},
 bigbang(g,h){return g.b.o===h?shotCin(h,'BIG BANG DRIVE','#ff3b6b',1.1,900,1.3):0},
 kimpact(g,h){if(g.b.o!==h)return 0;kick(h,900);addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#2ff7d0',t:.4});return 1},
 kdribble(g,h){dash(h,.45);setPlow(g,h,.45,46);if(isH(h))g.skcd[0]=0;else if(h._skcd)h._skcd[0]=0;addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#2ff7d0',t:.35});fxt(h,'¡IMPACT listo!');return 1},
 route(g,h){const b=g.b,o=b.o;inv(h,800);dash(h,.35);
  if(o&&o.t==0&&!o.h&&near(o,h)<260){b.o=h;addSkillFx(g,{kind:'arc',x:h.x,y:h.y,col:'#2ff7d0',t:.4});fxt(h,'¡Subyugación!')}
  else if(!o&&near(b,h)<110){const a=aim(h);kick(h,820);g.curve={t:.7,a:(a.y>=0?-1:1)*600};addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:a.x,dy:a.y,col:'#2ff7d0',t:.4});fxt(h,'¡Volea curva!')}return 1},
 magnus(g,h){if(g.b.o!==h)return 0;return cin(h,'KAISER IMPACT MAGNUS','#2ff7d0',1,()=>{const s=Math.random()<.5?-1:1;kickBall(h,W,H/2-s*100,900);g.curve={t:.8,a:s*1100};h._pierce=.5;if(isH(h))g.pierce=.5})},
 accel(g,h){setSpr(g,h,2.5,.5);if(isH(h)){g.act=2.5;g.actK='dash'}addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:h.fx,dy:h.fy,col:'#fff36b',t:.4});return 1},
 tooslow(g,h){const b=g.b,o=b.o;let ok=0;
  if(!o&&near(b,h)<230){b.o=h;b.vx=b.vy=0;ok=1}else if(o&&o.t!==h.t&&near(o,h)<150){b.o=h;o.fall=1.5;ok=1}
  if(!ok)return 0;for(const q of rivals(h))if(near(q,h)<130)q.fall=Math.max(q.fall,1.2);addSkillFx(g,{kind:'arc',x:h.x,y:h.y,col:'#fff36b',t:.45});fxt(h,"¡IT'S TOO SLOW!");if(isH(h)){cv.style.filter='blur(3px)';setTimeout(()=>cv.style.filter='',700)}return 1},
 godspeed(g,h){const gs=isH(h)?g.gs:(h._gs||0);if(!(gs>0))return 0;const a=aim(h),x0=h.x,y0=h.y;if(isH(h))g.gs--;else h._gs--;
  h.fx=a.x;h.fy=a.y;h.x=cl(h.x+a.x*230,PR,W-PR);h.y=cl(h.y+a.y*230,PR,H-PR);inv(h,500);
  if(isH(h))(g.gh=g.gh||[]).push({x0,y0,x1:h.x,y1:h.y,t:.5});else(h._gh=h._gh||[]).push({x0,y0,x1:h.x,y1:h.y,t:.5});
  addSkillFx(g,{kind:'cut',x:h.x,y:h.y-8,dx:a.x,dy:a.y,col:'#fff36b',t:.35});
  const b=g.b,o=b.o;if(!o&&near(b,h)<150){b.o=h;b.vx=b.vy=0}else if(o&&o.t!==h.t&&near(o,h)<110){b.o=h;o.fall=1}
  if(b.o===h&&h.x>W-330){const s=Math.random()<.5?-1:1;kickBall(h,W,H/2+s*60,900)}return 3}
};

const us0=useSk;
useSk=function(i){const g=G;if(!g||g.end||g.pause>0||!g.skcd)return us0.apply(this,arguments);
 const id=sk(S.style)[i],f=K[id];if(!f)return us0.apply(this,arguments);
 const h=human();if(g.cin||g.skcd[i]>0||h.fall>0||(AWK.has(id)&&!(g.aw>0)))return;
 const r=f(g,h,i);if(!r)return;g.skcd[i]=r==2?6:r==3?.5:AWK.has(id)?99:SKD[id].cd;SR.fx(id,TR.has(id))};

window.aiCastSkill=function(p,i,mult=1){
 const g=G;if(!g||g.end||g.pause>0||g.cin||!p||p.fall>0)return false;
 const names=Object.keys(CHR);
 p._chr=p._chr||names[(p.i+(p.t||0)*2)%names.length];
 const ch=CHR[p._chr];if(!ch)return false;
 p._skcd=p._skcd||[0,0,0];if(p._skcd[i]>0)return false;
 const awOn=(p._aw||0)>0,id=(i===2&&ch.awk&&awOn)?ch.awk:ch.sk[i],fn=K[id];
 if(!fn||(AWK.has(id)&&!awOn))return false;
 const r=fn(g,p,i);if(!r)return false;
 const baseCd=r==2?6:r==3?.5:AWK.has(id)?99:(SKD[id]?SKD[id].cd:25);
 p._skcd[i]=Math.max(2.5,baseCd/Math.max(.5,mult));
 return true;
};

window.aiTickExtra=function(p,g,dt){
 if(!p||!g||g.end||g.pause>0)return;
 if(p._skcd)for(let i=0;i<3;i++)p._skcd[i]=Math.max(0,p._skcd[i]-dt);
 if((p._aw||0)>0){p._aw=Math.max(0,p._aw-dt);if(p._aw===0){p._trance=0;p._gs=0}}
 if((p._pierce||0)>0){p._pierce-=dt;for(const q of rivals(p))if(q.fall<=0&&near(q,g.b)<34)q.fall=1.2}
 if(p._plow&&p._plow.t>0){p._plow.t-=dt;for(const q of rivals(p))if(q.fall<=0&&near(q,p)<p._plow.r){q.fall=1.3;q.vx=p.vx;q.vy=p.vy;if(g.b.o===q){g.b.o=null;g.b.vx=p.vx;g.b.vy=p.vy}}}
 if((p._trance||0)>0){p._trance-=dt;inv(p,300);p._tcd=(p._tcd||0)-dt;if(p._tcd<=0&&p.dr<=0){dash(p,.3);p._plow={t:.3,r:42};p._tcd=.55}}
 if((p._direct||0)>0){p._direct-=dt;for(const q of rivals(p))if(q.sl>0&&near(q,g.b)<70){g.b.vy+=(Math.random()<.5?-1:1)*450;p._direct=0}}
 if(p._spr&&p._spr.t>0){p._spr.t-=dt;if(p.fall<=0){p.x=cl(p.x+p.vx*dt*p._spr.m,PR,W-PR);p.y=cl(p.y+p.vy*dt*p._spr.m,PR,H-PR)}
  if(g.b.o===p){g.b.x=p.x+p.fx*(PR+4);g.b.y=cl(p.y+9+p.fy*(PR+4),BR,H-BR)}}
 if(p._gh)p._gh=p._gh.filter(q=>(q.t-=dt)>0);
};

/* teclas C V B = habilidades, G = awakening */
addEventListener('keydown',e=>{const k=e.key.toLowerCase(),m={c:0,v:1,b:2};if(!G||G.end||!(k in m||k=='g'))return;e.stopImmediatePropagation();if(e.repeat)return;if(k=='g')awakeOn();else useSk(m[k])},true);

/* lógica por frame */
const up0=upd;
upd=function(dt){const g=G;if(!g||!g.kp||g.end||g.pause>0||innerHeight>innerWidth)return up0(dt);
 if(g._sfx)g._sfx=g._sfx.filter(v=>(v.t-=dt)>0);
 if(g.cin){g.cin.t-=dt;if(g.cin.t<=0){const f=g.cin.fn;g.cin=null;f()}return}
 const h=human(),ch=CHR[S.style.n];
 if(g.aw>0&&!g._aw){g._aw=1;g.gs=2;if(ch)g.skcd[2]=0}
 if(!(g.aw>0)&&g._aw){g._aw=0;g.trance=0;g.gs=0;if(ch)g.skcd[2]=ch.awk?10:99}
 const k1=g.kp[1];if(g.pierce>0)k1.x=1e5;
 up0(dt);
 if(G!==g)return;
 if(g.pierce>0){g.pierce-=dt;k1.x=W-16;for(const q of rivals(h))if(q.fall<=0&&near(q,g.b)<34)q.fall=1.2}
 if(g.plow&&g.plow.t>0){g.plow.t-=dt;for(const q of rivals(h))if(q.fall<=0&&near(q,h)<g.plow.r){q.fall=1.3;q.vx=h.vx;q.vy=h.vy;if(g.b.o===q){g.b.o=null;g.b.vx=h.vx;g.b.vy=h.vy}g.fxs.push({t:.8,x:q.x,y:q.y-60,s:'¡Derribado!'})}}
 if(g.trance>0){g.trance-=dt;inv(h,300);g.tcd-=dt;if(g.tcd<=0&&h.dr<=0){dash(h,.3);g.plow={t:.3,r:42};g.tcd=.55}}
 if(g.direct>0){g.direct-=dt;for(const q of rivals(h))if(q.sl>0&&near(q,g.b)<70){g.b.vy+=(Math.random()<.5?-1:1)*450;g.direct=0;fxt(h,'¡Desviado!')}}
 if(g.spr&&g.spr.t>0){g.spr.t-=dt;if(h.fall<=0){h.x=cl(h.x+h.vx*dt*g.spr.m,PR,W-PR);h.y=cl(h.y+h.vy*dt*g.spr.m,PR,H-PR)}
  if(g.b.o===h){g.b.x=h.x+h.fx*(PR+4);g.b.y=Math.min(H-BR,Math.max(BR,h.y+9+h.fy*(PR+4)))}}
 if(g.gh)g.gh=g.gh.filter(q=>(q.t-=dt)>0)};

/* textura asimétrica y con tonalidad exclusivamente en efectos de habilidades */
function drawSkillVfx(c,g,now){
 const b=g.b,spd=Math.hypot(b.vx,b.vy);
 if(!b.o&&spd>250){
  const ang=Math.atan2(b.vy,b.vx),nx=-Math.sin(ang),ny=Math.cos(ang),tail=cl(spd/13,26,76);
  const col=(g.pierce>0||(g.ps&&g.ps.some(q=>!q.h&&(q._pierce||0)>0)))?'#ff3b6b':(g.curve&&g.curve.t>0)?'#2ff7d0':'#ffd21f';
  c.save();
  const gr=c.createLinearGradient(b.x,b.y,b.x-Math.cos(ang)*tail,b.y-Math.sin(ang)*tail);
  gr.addColorStop(0,col);gr.addColorStop(.55,col);gr.addColorStop(1,'rgba(255,255,255,0)');
  c.strokeStyle=gr;c.lineWidth=BR*1.65;c.lineCap='round';c.globalAlpha=.6;
  c.beginPath();c.moveTo(b.x,b.y);c.lineTo(b.x-Math.cos(ang)*tail,b.y-Math.sin(ang)*tail);c.stroke();

  const shift=Math.sin(now/55)*6;
  c.strokeStyle='#fff';c.lineWidth=2.2;c.globalAlpha=.65;
  c.beginPath();
  c.moveTo(b.x+nx*shift,b.y+ny*shift);
  c.quadraticCurveTo(b.x-Math.cos(ang)*tail*.52+nx*(shift+8),b.y-Math.sin(ang)*tail*.52+ny*(shift+8),b.x-Math.cos(ang)*tail,b.y-Math.sin(ang)*tail);
  c.stroke();

  c.fillStyle=col;c.globalAlpha=.85;
  for(let i=0;i<3;i++){
   const d=(i+1)*tail*.28,side=(i%2?1:-1)*(6+i*3);
   c.beginPath();c.arc(b.x-Math.cos(ang)*d+nx*side,b.y-Math.sin(ang)*d+ny*side,2.2,0,7);c.fill();
  }
  c.restore();
 }

 for(const v of g._sfx||[]){
  const p=1-v.t/.45;c.save();c.globalAlpha=cl(v.t*2.2,0,1);
  if(v.kind==='cut'){
   const a=Math.atan2(v.dy||0,v.dx||1);
   c.translate(v.x,v.y);c.rotate(a);
   c.strokeStyle=v.col;c.lineWidth=5*(1-p*.45);c.lineCap='round';
   c.beginPath();c.moveTo(-28,-7);c.quadraticCurveTo(4,-19,34,-2);c.stroke();
   c.strokeStyle='#fff';c.lineWidth=2;
   c.beginPath();c.moveTo(-16,10);c.lineTo(26,5);c.stroke();
  }else if(v.kind==='shards'){
   c.strokeStyle=v.col;c.lineWidth=3;
   for(let i=0;i<7;i++){
    const ang=i*.95+p*1.3,r0=8+p*14,r1=24+p*34;
    c.beginPath();c.moveTo(v.x+Math.cos(ang)*r0,v.y+Math.sin(ang)*r0);
    c.lineTo(v.x+Math.cos(ang)*r1,v.y+Math.sin(ang)*r1);c.stroke();
   }
  }else if(v.kind==='arc'){
   c.strokeStyle=v.col;c.lineWidth=3;
   c.beginPath();c.ellipse(v.x,v.y+12,18+p*28,7+p*11,.12,0,Math.PI*1.75);c.stroke();
  }
  c.restore();
 }
}

/* dibujo: cinemáticas, estelas y efectos de habilidades */
const dw0=draw;
draw=function(){dw0.apply(this,arguments);const g=G;if(!g||!g.kp)return;
 const h=human(),c=cx,now=performance.now(),hx=h.x,hy=h.y-20,ch=CHR[S.style.n],e=document.getElementById('sl2');
 if(e)e.style.display=ch&&!ch.awk&&!(g.aw>0)?'none':'';
 SKD.godspeed.n='Godspeed ×'+(g.gs||0);
 c.save();
 drawSkillVfx(c,g,now);
 if(g.trance>0){const r=c.createRadialGradient(hx,hy,5,hx,hy,60);r.addColorStop(0,'rgba(255,210,31,.5)');r.addColorStop(1,'rgba(180,60,255,0)');c.fillStyle=r;c.globalAlpha=.7+.3*Math.sin(now/70);c.fillRect(hx-70,hy-70,140,140)}
 for(const q of g.gh||[]){c.globalAlpha=q.t*2;c.strokeStyle='#fff36b';c.lineWidth=14;c.lineCap='round';c.beginPath();c.moveTo(q.x0,q.y0-20);c.lineTo(q.x1,q.y1-20);c.stroke()}
 for(const p of g.ps||[])if(!p.h&&p._gh)for(const q of p._gh){c.globalAlpha=q.t*2;c.strokeStyle='#fff36b';c.lineWidth=12;c.lineCap='round';c.beginPath();c.moveTo(q.x0,q.y0-20);c.lineTo(q.x1,q.y1-20);c.stroke()}
 if(g.cin){const k=g.cin;c.globalAlpha=.55;c.fillStyle='#000';c.fillRect(0,0,W,H);c.globalAlpha=.8;c.strokeStyle=k.col;c.lineWidth=3;
  for(let i=0;i<26;i++){const a=i*.2417+now/900,r1=70+((i*53+now/3)%120),r2=r1+60+30*(i%3);c.beginPath();c.moveTo(hx+Math.cos(a)*r1,hy+Math.sin(a)*r1);c.lineTo(hx+Math.cos(a)*r2,hy+Math.sin(a)*r2);c.stroke()}
  c.globalAlpha=1;c.restore();c.save();blocky(h);c.fillStyle='#fff';c.beginPath();c.arc(g.b.x,g.b.y,BR,0,7);c.fill();
  c.textAlign='center';c.font='italic 900 '+(34+(1-k.t/k.d)*14)+'px sans-serif';c.lineWidth=7;c.strokeStyle='#000';c.strokeText(k.n,W/2,70);c.fillStyle=k.col;c.fillText(k.n,W/2,70)}
 c.restore()};
})();
