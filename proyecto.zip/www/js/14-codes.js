/* Striker Rivals · códigos de canje.
   Para añadir un código, agrega una línea en CODES. Recompensas posibles:
   coins (monedas), gems (gemas), spins (giros gratis), style (nombre exacto de un estilo de ST).
   until: 'AAAA-MM-DD' = último día en que se puede canjear (opcional).
   OJO: el juego funciona sin conexión, así que los códigos viajan dentro del APK:
   sirven para regalos y eventos, no para algo que deba estar protegido. */
(()=>{
const CODES={
 NAVIDAD26:{coins:300,gems:5,until:'2027-01-07'},
 PROTOTIPO:{coins:150,spins:3},
 // EJEMPLO:{style:'Cazador'},
};

const norm=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9Ñ]/g,'');
const TABLE={};for(const k in CODES){TABLE[norm(k)]=CODES[k];
 const st=CODES[k].style;if(st&&!ST.some(e=>e[0]===st))console.warn('códigos: el estilo "'+st+'" de '+k+' no existe')}

const expired=d=>{if(!d.until)return false;const p=d.until.split('-').map(Number);
 return Date.now()>new Date(p[0],p[1]-1,p[2]+1).getTime()};          // vale todo el último día

function redeem(raw){
 const k=norm(raw);if(!k)return{ok:false,msg:'Escribe un código'};
 const d=TABLE[k];if(!d)return{ok:false,msg:'Código no válido'};
 S.codes=S.codes||[];
 if(S.codes.includes(k))return{ok:false,msg:'Ya canjeaste este código'};
 if(expired(d))return{ok:false,msg:'Este código ya caducó'};
 S.codes.push(k);const L=[];
 if(d.coins){S.coins+=d.coins;L.push('+'+d.coins+' monedas')}
 if(d.gems){S.gems=(S.gems||0)+d.gems;L.push('+'+d.gems+' gemas')}
 if(d.spins){S.freeRoll=(S.freeRoll||0)+d.spins;L.push('+'+d.spins+' giros')}
 let full=false;
 if(d.style){const e=ST.find(s=>s[0]===d.style);
  if(e){const own=(S.own||[]).some(o=>o.n===e[0]);
   if(own){const c=10*(e[1]+1);S.coins+=c;L.push(e[0]+' repetido: +'+c+' monedas')}
   else{const r=addChar({n:e[0],r:e[1],ab:e[2]});full=r==='Slots llenos';L.push(full?e[0]+': slots llenos, elige qué hacer':'Nuevo estilo: '+e[0])}}}
 save();
 return{ok:true,msg:'¡Canjeado! '+L.join(' · '),full};
}

/* ---- pantalla de canje (botones grandes, cabe sin deslizar) ---- */
function open(){
 if(document.getElementById('cdm'))return;
 const m=document.createElement('div');m.id='cdm';
 m.innerHTML='<div class="cdb"><b>Canjear código</b>'+
  '<div class="cdr"><input id="cdi" maxlength="24" placeholder="Escribe tu código" autocomplete="off" autocapitalize="characters" spellcheck="false"><button id="cdg" class="r">Canjear</button></div>'+
  '<div id="cdo"></div><button id="cdx" class="g">Cerrar</button></div>';
 document.body.appendChild(m);
 const i=m.querySelector('#cdi'),o=m.querySelector('#cdo'),close=()=>m.remove();
 const go=()=>{const r=redeem(i.value);o.textContent=r.msg;o.className=r.ok?'ok':'no';
  if(r.ok){i.value='';const c=document.getElementById('coins');if(c)c.textContent=S.coins;if(r.full)close()}};
 m.querySelector('#cdg').onclick=go;m.querySelector('#cdx').onclick=close;
 i.addEventListener('keydown',e=>{if(e.key==='Enter')go()});
 setTimeout(()=>i.focus(),50);
}
const b=document.createElement('button');b.className='lu';b.innerHTML=ico('gift');b.title='Canjear código';   /* .lu = solo en el lobby */
b.style.cssText='position:absolute;top:8px;right:64px;padding:6px 10px;font-size:15px;background:rgba(0,0,0,.45);z-index:5';
b.onclick=open;document.getElementById('game').appendChild(b);
window.SRCodes={redeem,open};
})();
