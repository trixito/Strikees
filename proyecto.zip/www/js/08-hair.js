/* hair.js · peinados y piel de los 6 personajes (asimétricos). Coordenadas = espacio de la cabeza de drawChar */
window.HF=(()=>{
const OL='#05050f';
const poly=(pts,fill,lw)=>{X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.fillStyle=fill;X.fill();if(lw!==0){X.lineJoin='round';X.strokeStyle=OL;X.lineWidth=lw||13;X.stroke()}};
const strands=(list,c,w,a)=>{X.save();X.strokeStyle=c;X.globalAlpha=a==null?.5:a;X.lineWidth=w||7;X.lineCap='round';X.beginPath();for(const s of list){X.moveTo(s[0],s[1]);X.lineTo(s[2],s[3])}X.stroke();X.restore()};
const clipTo=(pts,fn)=>{X.save();X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.clip();fn();X.restore()};
const H={};
/* ISAGI: corto, despeinado, azul casi negro, dos mechones arriba */
const IS=[[244,226],[237,178],[252,146],[282,138],[296,116],[312,134],[322,86],[340,128],[358,112],[376,72],[390,124],[414,128],[434,160],[440,208],[424,216],[410,186],[392,198],[372,170],[350,202],[326,174],[300,200],[278,184],[262,214]];
H.Isagi={skin:['#ffdcb0','#d9a574'],front(){poly(IS,'#151a38');strands([[292,166,284,132],[346,150,368,100],[400,160,420,140],[270,190,262,160]],'#3a4a9a',7,.45)}};
/* BACHIRA: bob a la barbilla, negro por fuera, capa interior y puntas amarillas */
const BB=[[224,304],[216,240],[226,178],[262,138],[312,112],[372,108],[416,128],[448,176],[456,244],[452,298],[436,304],[428,262],[250,262],[236,300]];
H.Bachira={skin:['#ffdcb0','#d9a574'],
 back(){poly(BB,'#14141c');poly([[216,304],[220,276],[244,284],[246,304]],'#ffd21f',9);poly([[434,300],[440,270],[462,282],[452,304]],'#ffd21f',9)},
 front(){const F=[[240,300],[234,230],[234,176],[262,142],[312,116],[372,110],[418,130],[446,178],[448,240],[444,286],[428,292],[424,228],[418,198],[398,208],[376,190],[352,212],[330,192],[304,208],[282,194],[266,214],[262,250],[258,296]];
  poly(F,'#14141c');poly([[262,214],[274,252],[270,298],[250,302],[258,252],[252,222]],'#ffd21f',0);poly([[424,228],[418,266],[426,292],[442,288],[434,262],[434,236]],'#ffd21f',0);
  strands([[290,150,270,128],[360,140,396,130],[330,196,320,160]],'#4a4a62',7,.55)}};
/* NAGI: corto, desordenado, flequillo caído, blanco grisáceo */
const NG=[[242,228],[232,176],[254,142],[262,124],[292,128],[318,94],[336,124],[372,104],[388,130],[428,144],[444,196],[432,240],[420,214],[408,226],[396,196],[380,226],[364,198],[346,228],[326,200],[308,224],[292,198],[274,226],[262,206]];
H.Nagi={skin:['#f8e6d6','#d9bfae'],front(){poly(NG,'#eceff5');strands([[300,150,288,196],[352,130,350,196],[400,150,408,200],[270,160,262,200]],'#b3bacb',7,.7);strands([[330,112,322,150]],'#fff',6,.8)}};
/* SHIDOU: rubio platino en puntas hacia arriba, puntas rosa fucsia, piel morena */
const SH=[[246,224],[240,172],[252,152],[236,100],[274,130],[280,70],[312,122],[332,58],[354,118],[386,62],[398,128],[434,82],[430,152],[446,172],[438,222],[424,196],[408,206],[388,180],[364,206],[342,182],[318,208],[296,184],[274,210],[262,196]];
H.Shidou={skin:['#e3a672','#b67e4a'],front(){poly(SH,'#f4efd4');clipTo(SH,()=>{X.fillStyle='#ff2f92';for(const r of [[206,0,64,134],[250,0,60,114],[302,0,60,108],[356,0,60,112],[404,0,60,126]])X.fillRect(r[0],r[1],r[2],r[3])});X.beginPath();SH.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.strokeStyle=OL;X.lineWidth=13;X.lineJoin='round';X.stroke();strands([[300,176,290,140],[352,170,360,120],[392,176,414,130]],'#c9c3a0',7,.5)}};
/* KAISER: rubio claro estilo mullet, puntas azules */
const KB=[[262,196],[252,262],[236,322],[258,352],[274,322],[292,356],[306,304],[320,334],[332,290],[346,236]];
const KF=[[244,226],[238,176],[262,142],[304,118],[352,108],[396,118],[430,146],[444,196],[436,232],[424,206],[410,216],[394,188],[372,216],[352,184],[330,214],[310,186],[288,212],[270,194],[258,224]];
H.Kaiser={skin:['#fbe3c8','#d6ad88'],
 back(){poly(KB,'#f4dd8c');clipTo(KB,()=>{X.fillStyle='#2f6bff';X.fillRect(220,318,160,60)});X.beginPath();KB.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.strokeStyle=OL;X.lineWidth=13;X.lineJoin='round';X.stroke()},
 front(){poly(KF,'#f4dd8c');poly([[296,196],[282,242],[300,236],[308,198]],'#f4dd8c',9);poly([[380,196],[398,252],[410,236],[394,196]],'#f4dd8c',9);clipTo(KF,()=>{X.fillStyle='#2f6bff';X.fillRect(236,196,70,60);X.fillRect(356,194,100,60);X.fillRect(318,204,26,40)});strands([[300,160,330,128],[374,150,402,136],[270,176,262,156]],'#c4a95a',7,.55);
  X.beginPath();KF.forEach((p,i)=>i?X.lineTo(p[0],p[1]):X.moveTo(p[0],p[1]));X.closePath();X.strokeStyle=OL;X.lineWidth=13;X.lineJoin='round';X.stroke()}};
/* LOKI: muy corto, rizado pegado al cráneo, negro, piel oscura */
H.Loki={skin:['#8e5a3a','#6a3f26'],front(){const cx0=338,cy0=226,rx=100,ry=74,bump=[13,18,11,16,14,10,17,12,15,11,18,13,10,16],n=bump.length;
 X.beginPath();let first=true,pa=null;
 for(let i=0;i<=n;i++){const t=Math.PI+(i/n)*Math.PI,px=cx0+rx*Math.cos(t),py=cy0+ry*Math.sin(t);
  if(first){X.moveTo(px,py);first=false}else{const tm=Math.PI+((i-.5)/n)*Math.PI,mx=cx0+rx*Math.cos(tm),my=cy0+ry*Math.sin(tm),b=bump[i-1],nx=Math.cos(tm),ny=Math.sin(tm);X.quadraticCurveTo(mx+nx*(b*2),my+ny*(b*2),px,py)}}
 [[430,208],[412,196],[394,210],[372,194],[350,206],[328,194],[304,208],[282,198],[262,210],[244,228]].forEach(p=>X.lineTo(p[0],p[1]));X.closePath();X.fillStyle='#0d0d12';X.fill();X.strokeStyle=OL;X.lineWidth=13;X.lineJoin='round';X.stroke();
 X.strokeStyle='#3a3a48';X.globalAlpha=.7;X.lineWidth=5;X.lineCap='round';for(const c of [[290,150],[340,134],[392,144],[430,176],[258,186],[314,164],[366,160]]){X.beginPath();X.arc(c[0],c[1],7,3.6,5.6);X.stroke()}X.globalAlpha=1}};
return H})();
