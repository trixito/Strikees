/* PERSONAJE: edita SOLO este archivo para crear tu personaje.
   Coordenadas = plantilla_guia.png (ancho 800, alto ~900, pies en x=400,y=890).
   Los polígonos son listas de puntos [x,y]. Prueba abriendo index.html. */
var MI={
 skin:'#ffdcb0', skinShadow:'#d9a574',          // piel y sombra
 eyes:'#14142a',                                 // color de ojos
 head:{cx:338,cy:230,rx:95,ry:66},               // cabeza (elipse)
 hair:[[243,222],[236,150],[278,172],[282,100],[334,150],[358,75],[392,150],[440,98],[432,168],[482,150],[434,222],[420,190],[382,172],[340,182],[292,188],[252,214]], // forma del pelo
 cuerpo:{                                        // piezas del cuerpo
  lleg:[[335,560],[455,580],[445,700],[405,885],[315,895]],
  rleg:[[455,582],[525,548],[610,690],[665,810],[590,860],[545,866]],
  pel:[[340,550],[405,512],[500,530],[525,548],[458,580]],
  torso:[[278,325],[465,298],[525,545],[330,560]],
  larm:[[268,330],[300,350],[318,470],[218,632],[138,606],[200,470],[240,380]],
  rarm:[[470,296],[515,295],[700,445],[718,470],[692,545],[660,520],[560,420],[480,345]]},
 suits:null,       // trajes: [['#claro','#oscuro','#lineas'], ...] (reemplaza los primeros; el juego usa 4)
 hairColors:null,  // colores de pelo: ['#ffffff','#ff0000',...]
 extra(X){         // dibuja encima del personaje. Ejemplo (quita // para probar):
  // X.fillStyle='#e8233b';X.fillRect(250,205,180,14);   // cinta roja en la frente
 }
};
(()=>{try{
 Object.assign(CH,MI.cuerpo);
 if(MI.suits)MI.suits.forEach((s,i)=>{SUITS[i]=s});
 if(MI.hairColors)MI.hairColors.forEach((c,i)=>{HAIRS[i]=c});
 let s=drawChar.toString();
 const rep=(a,b)=>{if(!(a instanceof RegExp?a.test(s):s.includes(a)))throw new Error('no encuentro '+a);s=s.replace(a,b)};
 rep("sk='#ffdcb0',sd='#d9a574'","sk=MI.skin,sd=MI.skinShadow");
 rep("X.ellipse(338,230,95,66,-.06,0,7)","X.ellipse(MI.head.cx,MI.head.cy,MI.head.rx,MI.head.ry,-.06,0,7)");
 rep(/\[\[243,222\][^;]*?\]\]\.forEach/s,"MI.hair.forEach");
 rep("X.fillStyle='#14142a';X.beginPath();X.ellipse(300,242","X.fillStyle=MI.eyes;X.beginPath();X.ellipse(300,242");
 const k=s.lastIndexOf("X.restore()}");s=s.slice(0,k)+"MI.extra&&MI.extra(X);X.restore()}";
 drawChar=(0,eval)('('+s+')');
}catch(e){console.warn('personaje.js:',e)}})();
