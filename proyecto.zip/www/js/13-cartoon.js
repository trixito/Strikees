/* ===== Estilo dibujo para la pantalla de Roll (canvas) ===== */
function crect(c,x,y,w,h,fill,line){const r=Math.min(10,h/3),p=(dx,dy)=>{c.beginPath();c.moveTo(x+dx+r,y+dy);c.arcTo(x+dx+w,y+dy,x+dx+w,y+dy+h,r);c.arcTo(x+dx+w,y+dy+h,x+dx,y+dy+h,r);c.arcTo(x+dx,y+dy+h,x+dx,y+dy,r);c.arcTo(x+dx,y+dy,x+dx+w,y+dy,r);c.closePath()};
 c.save();c.lineJoin='round';p(0,3);c.fillStyle='#05050f';c.fill();p(0,0);c.fillStyle=fill;c.fill();c.lineWidth=6;c.strokeStyle='#05050f';c.stroke();c.lineWidth=2.5;c.strokeStyle=line;c.stroke();c.restore()}
(()=>{try{let s=rollP.toString(),n=0;
 const rp=(a,b)=>{if(s.includes(a)){s=s.replace(a,b);n++}else console.warn('cartoon: no encontrado',a.slice(0,40))};
 rp("c.fillStyle='rgba(0,0,30,.7)';c.fillRect(10,y,112,60);c.strokeStyle=RC[o.r];c.lineWidth=3;c.strokeRect(10,y,112,60);","crect(c,10,y,112,60,'#1a1450',RC[o.r]);");
 rp("c.fillStyle='rgba(10,20,80,.8)';c.fillRect(610,y,178,28);c.strokeStyle=RC[i];c.lineWidth=3;c.strokeRect(610,y,178,28);","crect(c,610,y,178,28,'#1a1450',RC[i]);");
 rp("c.fillStyle='rgba(0,30,0,.8)';c.fillRect(620,388,170,26);","crect(c,620,388,170,26,'#103a1c','#8dff8d');");
 if(n)rollP=(0,eval)('('+s+')')}catch(e){console.warn('cartoon roll',e)}})();
