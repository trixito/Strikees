const $=id=>document.getElementById(id);
let S={name:"",style:null,coins:0,rolled:0};
try{Object.assign(S,JSON.parse(localStorage.getItem("sr")||"{}"))}catch(e){}
const save=()=>{try{localStorage.setItem("sr",JSON.stringify(S))}catch(e){}};
const RN=["Común","Raro","Épico","Legendario"],RC=["#8a93b5","#1f9bff","#b24dff","#ffb21f"];
const AB={dash:["Ráfaga","Velocidad extra un instante"],shot:["Cañonazo","Tu próximo tiro sale potentísimo"],magnet:["Imán","Atrae el balón cerca de ti"],turbo:["Regate","Más velocidad y control"]};
const ST=[["Novato Veloz",0,"dash"],["Pie de Hierro",0,"shot"],["Cazador",1,"magnet"],["Rayo Corto",1,"dash"],["Rey del Regate",2,"turbo"],["Cañón Dorado",2,"shot"],["Meteoro Egoísta",3,"shot"],["Dios del Campo",3,"dash"]];
function rollStyle(){const x=Math.random(),r=x<.55?0:x<.83?1:x<.96?2:3;const p=ST.filter(s=>s[1]==r);const s=p[Math.floor(Math.random()*p.length)];return{n:s[0],r:s[1],ab:s[2]}}
/* Estilo por defecto: los jugadores nuevos empiezan con este (def:1 = no ocupa slot; se equipa solo
   el primer estilo que consigan). Las partidas que ya tienen estilo no cambian. */
const DEFAULT_STYLE='Novato Veloz';
if(!S.style){const e=ST.find(s=>s[0]===DEFAULT_STYLE);S.style={n:e[0],r:e[1],ab:e[2],def:1};save()}
function card(s){$("card").innerHTML=s?`<b style="color:${RC[s.r]}">${RN[s.r]}</b><br><big>${s.n}</big><br><small>${AB[s.ab][0]}: ${AB[s.ab][1]}</small>`:"Aún no tienes estilo. Haz tu primer roll gratis."}
let size=3;
function menu(){$("menu").style.display="flex";$("game").style.display="none";$("ov").style.display="none";$("nm").value=S.name;$("coins").textContent=S.coins;card(S.style);$("rb").textContent=S.style?"Roll (30 monedas)":"Roll gratis";
 $("chips").innerHTML="";for(let i=1;i<=3;i++){const b=document.createElement("button");b.textContent=i+"v"+i;b.className=i==size?"on":"g";b.onclick=()=>{size=i;menu()};$("chips").appendChild(b)}}
$("rb").onclick=()=>{const cost=S.style?30:0;if(S.coins<cost){$("card").innerHTML="Te faltan monedas. Gana partidos para conseguir más.";return}
 S.coins-=cost;$("coins").textContent=S.coins;let n=0;$("rb").disabled=true;const iv=setInterval(()=>{const t=rollStyle();card(t);if(++n>12){clearInterval(iv);S.style=t;save();$("rb").disabled=false;menu()}},90)};
$("nm").oninput=e=>{S.name=e.target.value.trim();save()};
function need(){if(!S.name){$("nm").focus();$("nm").style.borderColor="#e8233b";return false}if(!S.style){$("card").innerHTML="Primero haz tu roll.";return false}return true}
let RKM=null; /* datos de la Ranked en curso (null = partido normal) */
$("q").onclick=()=>{if(!need())return;RKM=null;start(.9,"Partido rápido")};
$("t").onclick=()=>{if(!need())return;rankedP()};
const cv=$("cv"),cx=cv.getContext("2d"),W=800,H=450,GY0=160,GY1=290,PR=14,BR=8;
cv.width=W;cv.height=H;
function fit(){const r=Math.min(innerWidth/W,innerHeight/H);cv.style.width=W*r+"px";cv.style.height=H*r+"px"}
addEventListener("resize",fit);
let G=null,keys={},joy={x:0,y:0};
function start(lvl,label){
 const ps=[];
 for(let t=0;t<2;t++)for(let i=0;i<size;i++){const fx=size==1?.3:(i==0?.12:.2+(i%2)*.15+(i>2?.1:0));const hx=(t?1-fx:fx)*W,hy=H*(i+1)/(size+1);
  ps.push({t,i,x:hx,y:hy,vx:0,vy:0,hx,hy,h:t==0&&i==(size>>1),kc:0})}
 G={ps,b:{x:W/2,y:H/2,vx:0,vy:0},sc:[0,0],time:180,lvl,label,rk:RKM,big:!!(RKM&&RKM.big),pause:1,msg:"¡Vamos!",ot:false,end:false,cd:0,act:0,actK:"",armed:0};
 $("menu").style.display="none";$("game").style.display="block";$("ov").style.display="none";fit();
 $("ba").textContent=AB[S.style.ab][0];last=performance.now();
}
function reset(){const g=G;g.ps.forEach(p=>{p.x=p.hx;p.y=p.hy;p.vx=p.vy=0});g.b.x=W/2;g.b.y=H/2;g.b.vx=g.b.vy=0}
function useAb(){const g=G;if(!g||g.cd>0||g.end)return;const k=S.style.ab;g.cd=7;if(k=="shot")g.armed=5;else{g.actK=k;g.act=k=="magnet"?2.5:k=="dash"?1.6:2.2}}
function human(){return G.ps.find(p=>p.h)}
function shoot(){const g=G;if(!g||g.end||g.pause>0)return;const p=human(),b=g.b;if(Math.hypot(b.x-p.x,b.y-p.y)>PR+BR+24)return;
 let ax=W-p.x,ay=H/2-p.y;if(Math.hypot(joy.x,joy.y)>.3){ax=joy.x;ay=joy.y}const m=Math.hypot(ax,ay)||1;
 const pw=520*(1+.1*S.style.r)*(g.armed>0?1.7:1);g.armed=0;b.vx=ax/m*pw;b.vy=ay/m*pw}
function kick(p,tx,ty,pw){const b=G.b,dx=tx-b.x,dy=ty-b.y,m=Math.hypot(dx,dy)||1;b.vx=dx/m*pw;b.vy=dy/m*pw;p.kc=.6}
function goal(t){const g=G;g.sc[t]++;g.pause=1.6;g.msg=t==0?"¡GOL! "+(S.name||"Tú"):"Gol rival";if(g.ot)finish()}
function upd(dt){const g=G,b=g.b;if(g.end)return;
 if(g.pause>0){g.pause-=dt;if(g.pause<=0&&!g.end){g.msg="";reset()}return}
 g.time-=dt;g.cd=Math.max(0,g.cd-dt);g.act=Math.max(0,g.act-dt);g.armed=Math.max(0,g.armed-dt);
 if(g.time<=0){if(g.sc[0]!=g.sc[1]||!g.rk)return finish();if(!g.ot){g.ot=true;g.time=45;g.pause=1.5;g.msg="¡Gol de oro!"}else{g.sc[Math.random()<.5?0:1]++;return finish()}}
 let jx=joy.x+(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0),jy=joy.y+(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0);
 const jm=Math.hypot(jx,jy);if(jm>1){jx/=jm;jy/=jm}
 for(const p of g.ps){p.kc-=dt;let tx=0,ty=0;
  if(p.h){const r=S.style.r;let sp=190*(1+.06*r);if(g.act>0&&g.actK=="dash")sp*=1.7;if(g.act>0&&g.actK=="turbo")sp*=1.35;tx=jx*sp;ty=jy*sp;
   if(g.act>0&&g.actK=="magnet"){const dx=p.x-b.x,dy=p.y-b.y,d=Math.hypot(dx,dy);if(d<170&&d>PR){b.vx+=dx/d*1100*dt;b.vy+=dy/d*1100*dt}}}
  else{const sp=150*g.lvl*(p.t==1?1:.9),own=g.ps.filter(q=>q.t==p.t&&!q.h);let ch=own[0];for(const q of own)if(Math.hypot(q.x-b.x,q.y-b.y)<Math.hypot(ch.x-b.x,ch.y-b.y))ch=q;
   const near=Math.hypot(b.x-p.x,b.y-p.y)<PR+BR+10;let gx=p.t?0:W,gy=H/2,px,py;
   if(near){px=gx;py=gy;if(p.kc<=0&&(Math.abs(gx-p.x)<300||Math.random()<.02))kick(p,gx,Math.min(GY1-12,Math.max(GY0+12,gy+(Math.random()-.5)*110)),430+130*g.lvl)}
   else if(ch===p){px=b.x;py=b.y}else{px=p.hx+(b.x-W/2)*.25;py=p.hy+(b.y-H/2)*.2}
   const dx=px-p.x,dy=py-p.y,d=Math.hypot(dx,dy);if(d>6){tx=dx/d*sp;ty=dy/d*sp}}
  p.vx+=(tx-p.vx)*Math.min(1,dt*10);p.vy+=(ty-p.vy)*Math.min(1,dt*10);
  p.x=Math.min(W-PR,Math.max(PR,p.x+p.vx*dt));p.y=Math.min(H-PR,Math.max(PR,p.y+p.vy*dt));
  const dx=b.x-p.x,dy=b.y-p.y,d=Math.hypot(dx,dy);
  if(d<PR+BR&&d>0){const nx=dx/d,ny=dy/d;b.x=p.x+nx*(PR+BR);b.y=p.y+ny*(PR+BR);b.vx=p.vx*1.15+nx*80;b.vy=p.vy*1.15+ny*80}}
 const f=Math.pow(.5,dt*1.4);b.vx*=f;b.vy*=f;const sp=Math.hypot(b.vx,b.vy);if(sp>900){b.vx*=900/sp;b.vy*=900/sp}
 b.x+=b.vx*dt;b.y+=b.vy*dt;
 if(b.y<BR){b.y=BR;b.vy=Math.abs(b.vy)*.8}if(b.y>H-BR){b.y=H-BR;b.vy=-Math.abs(b.vy)*.8}
 const inG=b.y>GY0&&b.y<GY1;
 if(b.x<BR){if(inG&&b.x<0)return goal(1);if(!inG){b.x=BR;b.vx=Math.abs(b.vx)*.8}}
 if(b.x>W-BR){if(inG&&b.x>W)return goal(0);if(!inG){b.x=W-BR;b.vx=-Math.abs(b.vx)*.8}}
}
function ov(h,p,btn,fn){$("oh").textContent=h;$("op").textContent=p;$("ob").textContent=btn;$("ob").onclick=fn;const b2=$("ob2");if(b2)b2.style.display="none";$("ov").style.display="flex"}
function finish(){const g=G;g.end=true;const win=g.sc[0]>g.sc[1],draw=g.sc[0]==g.sc[1],res=g.sc[0]+" - "+g.sc[1];
 const cm=CM(),c0=Math.round((win?50:draw?15:5)*cm);S.coins+=c0;
 if(!g.rk){save();return ov(win?"¡Victoria!":draw?"Empate":"Derrota",res+" · +"+c0+" monedas","Volver al menú",menu)}
 return rankedEnd(g,win,res,c0)}
function blocky(p){const sp=Math.hypot(p.vx,p.vy),w=Math.sin(performance.now()/90+p.i*2)*Math.min(1,sp/120)*5,fy=p.y+13,tc=p.t?"#e8233b":"#1f6bff",skin=p.h?"#ffd9a8":"#f2c28f",hair=p.h?RC[S.style.r]:"#3b2a1a",dir=p.vx<-10?-1:1;
 cx.fillStyle="rgba(0,0,0,.28)";cx.beginPath();cx.ellipse(p.x,fy,12,4,0,0,7);cx.fill();
 const R=(x,y,w2,h,c)=>{cx.fillStyle=c;cx.fillRect(p.x+x,fy+y,w2,h);cx.strokeStyle="rgba(0,0,0,.6)";cx.lineWidth=1.5;cx.strokeRect(p.x+x,fy+y,w2,h)};
 R(-7,-10-w/2,6,10,"#222a44");R(1,-10+w/2,6,10,"#222a44");
 R(-14,-24+w/2,5,13,skin);R(9,-24-w/2,5,13,skin);
 R(-9,-24,18,15,tc);
 R(-7,-37,14,13,skin);R(-7,-37,14,4,hair);
 cx.fillStyle="#111";cx.fillRect(p.x-4+dir*2,fy-31,2,3);cx.fillRect(p.x+2+dir*2,fy-31,2,3);
 cx.fillStyle="#fff";cx.font="bold 9px sans-serif";cx.textAlign="center";cx.fillText(p.i+1,p.x,fy-13);
 if(p.h){cx.font="bold 13px sans-serif";cx.fillText(S.name||"Tú",p.x,fy-52);cx.fillStyle="#ffd21f";cx.beginPath();cx.moveTo(p.x-5,fy-47);cx.lineTo(p.x+5,fy-47);cx.lineTo(p.x,fy-41);cx.fill()}}
function draw(){const g=G;cx.clearRect(0,0,W,H);
 for(let i=0;i<10;i++){cx.fillStyle=g.xm?(i%2?"#dcebf7":"#eef7ff"):i%2?"#2f9e5b":"#33a862";cx.fillRect(i*80,0,80,H)}
 cx.strokeStyle=g.xm?"#c8102e":"rgba(255,255,255,.85)";cx.lineWidth=3;cx.strokeRect(2,2,W-4,H-4);cx.beginPath();cx.moveTo(W/2,0);cx.lineTo(W/2,H);cx.stroke();
 cx.beginPath();cx.arc(W/2,H/2,55,0,7);cx.stroke();cx.strokeRect(0,100,110,250);cx.strokeRect(W-110,100,110,250);
 cx.fillStyle="rgba(10,10,10,.55)";cx.fillRect(0,GY0,8,GY1-GY0);cx.fillRect(W-8,GY0,8,GY1-GY0);
 for(const p of [...g.ps].sort((a,b)=>a.y-b.y))blocky(p);
 cx.fillStyle="#fff";cx.beginPath();cx.arc(g.b.x,g.b.y,BR,0,7);cx.fill();cx.strokeStyle="#111";cx.lineWidth=2;cx.stroke();
 cx.fillStyle="rgba(0,0,0,.55)";cx.fillRect(W/2-90,0,180,34);cx.fillStyle="#fff";cx.font="bold 22px sans-serif";cx.textAlign="center";
 cx.fillText(g.sc[0]+"  ·  "+g.sc[1],W/2,25);cx.font="13px sans-serif";cx.textAlign="left";cx.fillText((g.ot?"GOL DE ORO":Math.max(0,Math.ceil(g.time))+"s"),W/2+98,22);cx.fillText(g.label,12,20);
 if(g.msg){cx.textAlign="center";cx.font="italic 900 54px sans-serif";cx.fillStyle="#fff";cx.strokeStyle="#111";cx.lineWidth=6;cx.strokeText(g.msg,W/2,H/2-60);cx.fillText(g.msg,W/2,H/2-60)}
 const ba=$("ba");const t=g.armed>0?"¡Listo!":g.cd>0?Math.ceil(g.cd)+"s":AB[S.style.ab][0];if(ba.textContent!=t)ba.textContent=t;ba.style.opacity=g.cd>0&&!g.armed?.5:1}
let last=0;
function loop(n){const dt=Math.min(.05,(n-last)/1000);last=n;if(G&&$("game").style.display=="block"){upd(dt);draw()}requestAnimationFrame(loop)}
requestAnimationFrame(loop);
const jz=$("jz"),st=$("st");let jid=null;
function jm(e){const r=jz.getBoundingClientRect(),x=(e.clientX-r.left-65)/50,y=(e.clientY-r.top-65)/50,m=Math.hypot(x,y),k=m>1?1/m:1;joy.x=x*k;joy.y=y*k;st.style.transform=`translate(${joy.x*40}px,${joy.y*40}px)`}
jz.onpointerdown=e=>{jid=e.pointerId;jz.setPointerCapture(jid);jm(e)};
jz.onpointermove=e=>{if(e.pointerId==jid)jm(e)};
jz.onpointerup=jz.onpointercancel=()=>{jid=null;joy.x=joy.y=0;st.style.transform=""};
$("bs").onpointerdown=shoot;$("ba").onpointerdown=useAb;
$("ex").onclick=()=>{if(G&&G.rk&&!G.end&&typeof rankedForfeit=="function")rankedForfeit(G);G=null;RKM=null;menu()};
addEventListener("keydown",e=>{keys[e.key]=true;keys[e.key.toLowerCase()]=true;if(e.key==" ")shoot();if(e.key.toLowerCase()=="e")useAb()});
addEventListener("keyup",e=>{keys[e.key]=false;keys[e.key.toLowerCase()]=false});
const SLD=.42;
function face(p,x,y){const m=Math.hypot(x,y);if(m>.1){p.fx=x/m;p.fy=y/m}}
function dribble(p){if(!p||p.drc>0||p.fall>0||p.sl>0)return;p.drc=1.6;p.dr=.35;p.ddx=p.fx;p.ddy=p.fy}
function slide(p){if(!p||p.slc>0||p.fall>0||p.dr>0||p.sl>0)return;p.slc=1.1;p.sl=SLD}
function kickBall(p,tx,ty,pw){const b=G.b,dx=tx-p.x,dy=ty-p.y,m=Math.hypot(dx,dy)||1;b.o=null;p.pk=.45;b.x=p.x+dx/m*(PR+BR+2);b.y=p.y+dy/m*(PR+BR+2);b.vx=dx/m*pw;b.vy=dy/m*pw}
function tackle(p){const b=G.b,o=b.o;if(!o||o.t==p.t||p.fall>0||Math.hypot(o.x-p.x,o.y-p.y)>PR*2+6)return;
 if(o.dr>0){p.fall=1.5;p.sl=0;G.fxs.push({t:1.4,x:o.x,y:o.y-50,s:'¡Tobillos rotos!'})}
 else{b.o=p;o.stun=.6;o.pk=.6;p.sl=.12;G.fxs.push({t:1,x:p.x,y:p.y-50,s:'¡Robo!'})}}
function shoot(){const g=G;if(!g||g.end||g.pause>0)return;const p=human(),b=g.b;if(p.fall>0)return;if(b.o!==p&&(b.o||Math.hypot(b.x-p.x,b.y-p.y)>PR+BR+24))return;
 let ax=W-p.x,ay=H/2-p.y;if(Math.hypot(joy.x,joy.y)>.3){ax=joy.x;ay=joy.y}
 const m=Math.hypot(ax,ay)||1,pw=520*(1+.1*S.style.r)*(g.armed>0?1.7:1);g.armed=0;b.o=null;p.pk=.4;b.x=p.x+ax/m*(PR+BR+2);b.y=p.y+ay/m*(PR+BR+2);b.vx=ax/m*pw;b.vy=ay/m*pw}
const startOld=start,resetOld=reset,menuOld=menu,drawOld=draw;
start=function(l,lb){startOld(l,lb);G.ps.forEach(p=>{p.fx=p.t?-1:1;p.fy=0;p.ddx=p.ddy=0;for(const k of ['kc','pk','drc','slc','dr','sl','fall','stun'])p[k]=0});G.b.o=null;G.fxs=[];
 try{if(matchMedia('(pointer:coarse)').matches&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().then(()=>screen.orientation.lock('landscape')).catch(()=>{})}catch(e){}};
reset=function(){resetOld();G.b.o=null;G.ps.forEach(p=>{p.sl=p.dr=p.fall=p.stun=0})};
const HUM_DIFF_SP=[1.08,1.0,.96,.92];
function upd(dt){const g=G,b=g.b;if(g.end||innerHeight>innerWidth)return;
 g.fxs=g.fxs.filter(f=>(f.t-=dt)>0);
 if(g.pause>0){g.pause-=dt;if(g.pause<=0&&!g.end){g.msg='';reset()}return}
 g.time-=dt;g.cd=Math.max(0,g.cd-dt);g.act=Math.max(0,g.act-dt);g.armed=Math.max(0,g.armed-dt);
 if(g.time<=0&&!g.ot){if(g.sc[0]!=g.sc[1])return finish();g.ot=true;g.time=1e9;g.pause=1.5;g.msg='¡GOL DE ORO!'}
 let jx=joy.x+(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0),jy=joy.y+(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0);
 const hSpMult=HUM_DIFF_SP[(g._diffIdx!=null)?g._diffIdx:1]||1;
 for(const p of g.ps){
  for(const k of ['kc','pk','drc','slc','dr','sl','fall','stun'])p[k]=Math.max(0,p[k]-dt);
  let sp=0,dx=0,dy=0;
  if(p.h){sp=190*(1+.06*S.style.r)*hSpMult;if(g.act>0&&g.actK=='dash')sp*=1.7;if(g.act>0&&g.actK=='turbo')sp*=1.35;sp*=(g.aw>0?1.35:g.fl>0?1.2:1)*(g.run?1.25:1);dx=jx;dy=jy;
   if(g.act>0&&g.actK=='magnet'&&!b.o){const mx=p.x-b.x,my=p.y-b.y,d=Math.hypot(mx,my);if(d<190&&d>PR){b.vx+=mx/d*1100*dt;b.vy+=my/d*1100*dt}}}
  else{const A=aiTick(p,g,b,dt);dx=A[0];dy=A[1];sp=A[2]}
  if(b.o===p)sp*=.93;if(p.stun>0)sp*=.3;
  if(p.dr>0){dx=p.ddx;dy=p.ddy;sp=340}
  if(p.sl>0){dx=p.fx;dy=p.fy;sp=410*(.5+p.sl/SLD*.5)}
  if(p.fall>0)sp=0;
  const m=Math.hypot(dx,dy);if(m>1){dx/=m;dy/=m}
  if(m>.1&&p.sl<=0&&p.dr<=0&&p.fall<=0)face(p,dx,dy);
  const k=Math.min(1,dt*(p.sl>0||p.dr>0?20:10));p.vx+=(dx*sp-p.vx)*k;p.vy+=(dy*sp-p.vy)*k;
  p.x=Math.min(W-PR,Math.max(PR,p.x+p.vx*dt));p.y=Math.min(H-PR,Math.max(PR,p.y+p.vy*dt));
  if(p.sl>0)tackle(p);
  if(!b.o&&p.fall<=0&&p.stun<=0&&p.pk<=0&&Math.hypot(b.x-p.x,b.y-p.y)<PR+BR+6){b.o=p;b.vx=b.vy=0}}
 if(b.o){const o=b.o;b.x=o.x+o.fx*(PR+4);b.y=Math.min(H-BR,Math.max(BR,o.y+9+o.fy*(PR+4)))}
 else{const f=Math.pow(.5,dt*1.4);b.vx*=f;b.vy*=f;const s=Math.hypot(b.vx,b.vy);if(s>900){b.vx*=900/s;b.vy*=900/s}b.x+=b.vx*dt;b.y+=b.vy*dt;
  if(b.y<BR){b.y=BR;b.vy=Math.abs(b.vy)*.8}if(b.y>H-BR){b.y=H-BR;b.vy=-Math.abs(b.vy)*.8}}
 const inG=b.y>GY0&&b.y<GY1;
 if(b.x<BR){if(inG&&b.x<0)return goal(1);if(!inG){b.x=BR;b.vx=Math.abs(b.vx)*.8}}
 if(b.x>W-BR){if(inG&&b.x>W)return goal(0);if(!inG){b.x=W-BR;b.vx=-Math.abs(b.vx)*.8}}
}
function blocky(p){const sp=Math.hypot(p.vx,p.vy),w=Math.sin(performance.now()/90+p.i*2)*Math.min(1,sp/120)*5,fy=p.y+14,dir=p.fx<-.15?-1:p.fx>.15?1:(p.dl||1);p.dl=dir;
 const navy=p.t?'#4a1420':'#1b1d3f',ln=p.t?'#ff7a3d':'#7a55e8',skin=p.h?'#ffd9a8':'#f2c28f',hair=p.h?'#f4f4ff':['#3b2a1a','#1a1a1a','#c98a2b','#8a3b2a'][p.i%4];
 cx.fillStyle='rgba(0,0,0,.28)';cx.beginPath();cx.ellipse(p.x,fy,13,4,0,0,7);cx.fill();
 cx.save();cx.translate(p.x,fy);if(p.fall>0)cx.rotate(dir*1.5);else if(p.sl>0)cx.rotate(dir*1.25);
 const R=(x,y,w2,h,c)=>{cx.fillStyle=c;cx.fillRect(x,y,w2,h);cx.strokeStyle='rgba(0,0,0,.7)';cx.lineWidth=1.5;cx.strokeRect(x,y,w2,h)};
 R(-8,-12-w/2,7,9,navy);R(1,-12+w/2,7,9,navy);R(-8,-3-w/2,7,3,skin);R(1,-3+w/2,7,3,skin);
 R(-16,-27+w/2,6,15,navy);R(10,-27-w/2,6,15,navy);R(-10,-28,20,17,navy);
 cx.strokeStyle=ln;cx.lineWidth=1.6;cx.beginPath();cx.moveTo(-10,-28);cx.lineTo(10,-11);cx.moveTo(10,-28);cx.lineTo(-10,-11);cx.moveTo(-10,-19);cx.lineTo(10,-19);
 cx.moveTo(-8,-10-w/2);cx.lineTo(-2,-5-w/2);cx.moveTo(2,-9+w/2);cx.lineTo(8,-5+w/2);cx.moveTo(-16,-21+w/2);cx.lineTo(-10,-19+w/2);cx.moveTo(10,-21-w/2);cx.lineTo(16,-19-w/2);cx.stroke();
 cx.fillStyle=skin;cx.beginPath();cx.ellipse(0,-37,9,8,0,0,7);cx.fill();cx.strokeStyle='rgba(0,0,0,.7)';cx.lineWidth=1.5;cx.stroke();
 cx.fillStyle=hair;cx.beginPath();cx.ellipse(0,-40,9.5,6,0,Math.PI,0);cx.fill();
 cx.fillStyle='#111';cx.fillRect(-4+dir*2.5,-38,2,3);cx.fillRect(2+dir*2.5,-38,2,3);
 cx.restore();
 if(p.h){cx.fillStyle='#fff';cx.font='bold 13px sans-serif';cx.textAlign='center';cx.fillText(S.name||'Tú',p.x,fy-56);cx.fillStyle='#ffd21f';cx.beginPath();cx.moveTo(p.x-5,fy-52);cx.lineTo(p.x+5,fy-52);cx.lineTo(p.x,fy-46);cx.fill()}}
const rot=document.createElement('div');rot.id='rot';rot.style.cssText='display:none;position:fixed;inset:0;z-index:9;background:#0c1022;color:#fff;align-items:center;justify-content:center;text-align:center;font:800 22px sans-serif;padding:30px';rot.textContent='Gira el teléfono en horizontal para jugar';document.body.appendChild(rot);
function chk(){rot.style.display=($('game').style.display=='block'&&innerHeight>innerWidth)?'flex':'none'}
addEventListener('resize',chk);
menu=function(){menuOld();chk()};
draw=function(){drawOld();chk();const g=G;if(!g)return;cx.textAlign='center';cx.font='italic 900 22px sans-serif';for(const f of g.fxs){const y=f.y-(1.4-f.t)*20;cx.globalAlpha=Math.min(1,f.t*2);cx.fillStyle='#ffd21f';cx.strokeStyle='#111';cx.lineWidth=4;cx.strokeText(f.s,f.x,y);cx.fillText(f.s,f.x,y)}cx.globalAlpha=1};
function mk(id,t,css,fn){const b=document.createElement('button');b.className='ab';b.id=id;b.textContent=t;b.style.cssText=css;b.onpointerdown=fn;$('game').appendChild(b)}
mk('bd','Dribble','right:18px;bottom:122px;width:66px;height:66px;background:#8a3bff;font-size:12px',()=>{if(G&&!G.end)dribble(human())});
mk('bl','Barrida','right:108px;bottom:108px;width:66px;height:66px;background:#e8860f;font-size:12px',()=>{if(G&&!G.end)slide(human())});
const ba=$('ba');ba.style.right='112px';ba.style.bottom='14px';ba.style.width=ba.style.height='62px';
$('bs').onpointerdown=shoot;
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(!G||G.end)return;if(k=='f')dribble(human());if(k=='q')slide(human())});
const FAB=(()=>{const c=document.createElement('canvas');c.width=c.height=6;const k=c.getContext('2d');k.strokeStyle='rgba(255,255,255,.16)';k.lineWidth=1;k.beginPath();k.moveTo(0,6);k.lineTo(6,0);k.moveTo(-3,3);k.lineTo(3,-3);k.moveTo(3,9);k.lineTo(9,3);k.stroke();k.fillStyle='rgba(0,0,0,.2)';k.fillRect(0,0,1,1);k.fillRect(3,3,1,1);return cx.createPattern(c,'repeat')})();
function Pth(a){const q=new Path2D();q.moveTo(a[0][0],a[0][1]);for(let i=1;i<a.length;i++)q.lineTo(a[i][0],a[i][1]);q.closePath();return q}
function part(a,c1,c2){const q=Pth(a),y0=Math.min(...a.map(s=>s[1])),y1=Math.max(...a.map(s=>s[1])),g=cx.createLinearGradient(0,y0,0,y1);g.addColorStop(0,c1);g.addColorStop(1,c2);cx.fillStyle=g;cx.fill(q);cx.fillStyle=FAB;cx.fill(q);cx.lineJoin='round';cx.strokeStyle='rgba(5,5,15,.9)';cx.lineWidth=1.6;cx.stroke(q)}
function stripe(a,c){cx.beginPath();cx.moveTo(a[0][0],a[0][1]);for(let i=1;i<a.length;i++)cx.lineTo(a[i][0],a[i][1]);cx.strokeStyle=c;cx.globalAlpha=.3;cx.lineWidth=4.5;cx.stroke();cx.globalAlpha=1;cx.lineWidth=2;cx.stroke()}
function blocky(p){const t=performance.now()/110,sp=Math.hypot(p.vx,p.vy),w=Math.sin(t+p.i*2)*Math.min(1,sp/110),fy=p.y+18,dir=p.fx<-.15?-1:p.fx>.15?1:(p.dl||1);p.dl=dir;
 const nv=p.t?['#6a2234','#2a0c14']:['#33377a','#10112b'],ln=p.t?'#ff8a4a':'#9a78ff',sk=p.h?'#ffdcb0':'#f0c08a',sd=p.h?'#d9a574':'#cf9a68',
  hc=p.h?['#ffffff','#b9bfd9']:[['#5a4030','#241508'],['#3a3a3a','#050505'],['#e0aa48','#8a5a14'],['#aa5640','#4d1a0e']][p.i%4];
 cx.fillStyle='rgba(0,0,0,.3)';cx.beginPath();cx.ellipse(p.x,fy,19,6,0,0,7);cx.fill();
 if(p.h){cx.strokeStyle='#ffd21f';cx.lineWidth=2.5;cx.beginPath();cx.ellipse(p.x,fy,23,8,0,0,7);cx.stroke()}
 cx.save();cx.translate(p.x,fy);if(p.fall>0)cx.rotate(dir*1.5);else if(p.sl>0)cx.rotate(dir*1.25);cx.scale(1.2*dir,1.2);
 const lo=-w*5,ro=4+w*5,lL=Math.max(0,w)*5,lR=Math.max(0,-w)*5,ao=-w*5,bo=w*5;
 cx.fillStyle=sk;cx.beginPath();cx.ellipse(-8+lo,-lL,6,2.6,0,0,7);cx.ellipse(8+ro,-lR,6,2.6,0,0,7);cx.fill();cx.strokeStyle='rgba(5,5,15,.8)';cx.lineWidth=1.2;cx.stroke();
 part([[-12,-18],[-1,-18],[-2+lo,-lL-1],[-15+lo,-lL-1]],nv[0],nv[1]);part([[1,-18],[12,-18],[16+ro,-lR-1],[3+ro,-lR-1]],nv[0],nv[1]);
 stripe([[-10,-16],[-4+lo*.5,-8]],ln);stripe([[10,-16],[6+ro*.5,-8]],ln);
 part([[-12,-23],[12,-23],[11,-15],[-11,-15]],nv[0],nv[1]);stripe([[-12,-19],[12,-19]],ln);
 part([[-4,-50],[4,-50],[4,-44],[-4,-44]],sk,sd);
 part([[-14,-46],[14,-46],[13,-21],[-13,-21]],nv[0],nv[1]);
 stripe([[-14,-44],[0,-34],[14,-44]],ln);stripe([[-13,-24],[0,-33],[13,-24]],ln);stripe([[0,-34],[0,-24]],ln);
 cx.beginPath();for(let i=0;i<6;i++){const q=i*Math.PI/3;cx.lineTo(-8+4*Math.cos(q),-40+4*Math.sin(q))}cx.closePath();cx.fillStyle='#0b0c22';cx.fill();cx.strokeStyle=ln;cx.lineWidth=1.2;cx.stroke();
 part([[-14,-45],[-8,-43],[-17+ao,-17],[-29+ao,-20]],nv[0],nv[1]);part([[8,-43],[14,-45],[30+bo,-24],[18+bo,-18]],nv[0],nv[1]);
 stripe([[-12,-40],[-21+ao,-24]],ln);stripe([[12,-40],[22+bo,-27]],ln);
 cx.fillStyle=sk;cx.beginPath();cx.ellipse(-23+ao,-16,4.5,4,0,0,7);cx.ellipse(24+bo,-20,4.5,4,0,0,7);cx.fill();cx.strokeStyle='rgba(5,5,15,.8)';cx.lineWidth=1.2;cx.stroke();
 const hg=cx.createRadialGradient(-4,-59,2,0,-56,15);hg.addColorStop(0,sk);hg.addColorStop(1,sd);cx.fillStyle=hg;cx.beginPath();cx.ellipse(0,-56,13,11,0,0,7);cx.fill();cx.strokeStyle='rgba(5,5,15,.9)';cx.lineWidth=1.6;cx.stroke();
 const hr=cx.createLinearGradient(0,-71,0,-56);hr.addColorStop(0,hc[0]);hr.addColorStop(1,hc[1]);cx.fillStyle=hr;cx.beginPath();[[-13,-56],[-14,-62],[-10,-61],[-11,-69],[-5,-64],[-2,-71],[2,-65],[7,-70],[8,-63],[13,-66],[12,-60],[14,-56],[9,-58],[4,-60],[-3,-58],[-9,-59]].forEach((s,i)=>i?cx.lineTo(s[0],s[1]):cx.moveTo(s[0],s[1]));cx.closePath();cx.fill();cx.stroke();
 cx.strokeStyle='rgba(0,0,0,.28)';cx.lineWidth=1;cx.beginPath();cx.moveTo(-6,-61);cx.lineTo(-7,-67);cx.moveTo(0,-62);cx.lineTo(1,-68);cx.moveTo(6,-61);cx.lineTo(8,-66);cx.stroke();
 cx.fillStyle='#1a1a2e';cx.beginPath();cx.ellipse(-5,-54,2,2.7,0,0,7);cx.ellipse(5,-54,2,2.7,0,0,7);cx.fill();cx.fillStyle='#fff';cx.fillRect(-5.8,-55.4,1.2,1.2);cx.fillRect(4.2,-55.4,1.2,1.2);
 cx.strokeStyle='rgba(30,20,20,.8)';cx.lineWidth=1.2;cx.beginPath();cx.moveTo(-8,-58);cx.lineTo(-2.5,-57);cx.moveTo(8,-58);cx.lineTo(2.5,-57);cx.moveTo(-2,-49);cx.lineTo(2,-49);cx.stroke();
 cx.restore();
 if(p.h){cx.fillStyle='#fff';cx.strokeStyle='#111';cx.lineWidth=3;cx.font='bold 14px sans-serif';cx.textAlign='center';cx.strokeText(S.name||'Tú',p.x,fy-102);cx.fillText(S.name||'Tú',p.x,fy-102);cx.fillStyle='#ffd21f';cx.beginPath();cx.moveTo(p.x-6,fy-97);cx.lineTo(p.x+6,fy-97);cx.lineTo(p.x,fy-90);cx.fill()}}
const SKD={shot:{n:'Meteoro',need:1,cd:9},turn:{n:'Giro Mágico',need:1,cd:7},pass:{n:'Pase Perfecto',need:1,cd:6},dash:{n:'Ráfaga',cd:6},magnet:{n:'Imán',cd:9},wall:{n:'Muro',cd:10},blitz:{n:'Presión',cd:8}};
const NSK={'Novato Veloz':['dash','turn','wall'],'Pie de Hierro':['shot','wall','magnet'],'Cazador':['magnet','blitz','pass'],'Rayo Corto':['dash','shot','turn'],'Rey del Regate':['turn','blitz','pass'],'Cañón Dorado':['shot','dash','wall'],'Meteoro Egoísta':['shot','turn','blitz'],'Dios del Campo':['pass','magnet','dash']};
const sk=s=>NSK[s.n]||['dash','turn','wall'];
function gain(f,a){const g=G;g.flow=Math.min(100,g.flow+f);g.awm=Math.min(100,g.awm+a)}
function card(s){$('card').innerHTML=s?'<b style=color:'+RC[s.r]+'>'+RN[s.r]+'</b><br><big>'+s.n+'</big><br><small>'+sk(s).map(k=>SKD[k].n+(SKD[k].need?' · con balón':'')).join(' · ')+'</small>':'Aún no tienes estilo. Haz tu primer roll gratis.'}
function slide(p){if(!p||p.slc>0||p.fall>0||p.dr>0||p.sl>0||G.b.o===p)return;p.slc=1.8;p.sl=.45;p.hit=false}
function tackle(p){const b=G.b,o=b.o;if(p.sl>0&&p.sl<=.06&&!p.hit&&p.fall<=0)p.fall=.7;
 if(!o||o.t==p.t||p.fall>0||Math.hypot(o.x-p.x,o.y-p.y)>PR*2+6)return;
 const prot=o.dr>0||performance.now()<(o.shU||0)||(o.h&&G.aw>0);
 if(prot){p.fall=1.8;p.sl=0;G.fxs.push({t:1.4,x:o.x,y:o.y-60,s:o.dr>0?'¡Tobillos rotos!':'¡Bloqueado!'});if(o.h)gain(35,10)}
 else{p.hit=true;b.o=null;b.vx=p.fx*140;b.vy=p.fy*140+(Math.random()-.5)*80;o.fall=2.2;o.pk=2.4;p.pk=.6;p.sl=.12;G.fxs.push({t:1.1,x:o.x,y:o.y-60,s:'¡Barrida!'});if(p.h)gain(25,5)}}
function pass(m){const g=G;m=m||1;if(!g||g.end||g.pause>0)return false;const p=human();if(p.fall>0)return false;if(g.b.o!==p)return typeof askPass=='function'?askPass(g,p):false;let best=null,bs=-9;const j=Math.hypot(joy.x,joy.y)>.3,dx=j?joy.x:p.fx,dy=j?joy.y:p.fy;
 for(const q of g.ps)if(q.t==0&&!q.h){const vx=q.x-p.x,vy=q.y-p.y,d=Math.hypot(vx,vy)||1,s=(vx*dx+vy*dy)/d;if(s>bs){bs=s;best=q}}
 if(!best)return false;kickBall(p,best.x+best.vx*.25,best.y+best.vy*.25,Math.min(760,380+Math.hypot(best.x-p.x,best.y-p.y)*.9)*m);gain(8,0);return true}
function shoot(){const g=G;if(!g||g.end||g.pause>0)return;const p=human(),b=g.b;if(p.fall>0)return;if(b.o!==p&&(b.o||Math.hypot(b.x-p.x,b.y-p.y)>PR+BR+24))return;
 let ax=W-p.x,ay=H/2-p.y;if(Math.hypot(joy.x,joy.y)>.3){ax=joy.x;ay=joy.y}
 const m=Math.hypot(ax,ay)||1,pw=520*(1+.1*S.style.r)*(g.aw>0?1.5:g.fl>0?1.25:1);b.o=null;p.pk=.4;b.x=p.x+ax/m*(PR+BR+2);b.y=p.y+ay/m*(PR+BR+2);b.vx=ax/m*pw;b.vy=ay/m*pw;gain(5,0)}
function useSk(i){const g=G;if(!g||g.end||g.pause>0)return;const p=human(),id=sk(S.style)[i],d=SKD[id];if(g.skcd[i]>0||p.fall>0)return;if(d.need&&g.b.o!==p)return;
 if(id=='shot')kickBall(p,W,H/2+(Math.random()-.5)*80,860*(1+.1*S.style.r)*(g.aw>0?1.3:1));
 else if(id=='turn'){p.dr=.6;p.ddx=p.fx;p.ddy=p.fy}
 else if(id=='pass'){if(!pass(1.5))return}
 else if(id=='dash'){g.act=1.6;g.actK='dash'}
 else if(id=='magnet'){g.act=2.5;g.actK='magnet'}
 else if(id=='blitz'){g.act=2.5;g.actK='turbo';p.slc=0}
 else if(id=='wall')p.shU=performance.now()+3000;
 g.skcd[i]=d.cd;g.fxs.push({t:1,x:p.x,y:p.y-95,s:d.n})}
function useAb(){useSk(0)}
function flowOn(){const g=G;if(g&&!g.end&&g.flow>=100&&g.fl<=0){g.fl=12;g.flow=0;g.fxs.push({t:1.3,x:human().x,y:human().y-95,s:'¡FLOW!'})}}
function awakeOn(){const g=G;if(g&&!g.end&&!(g.pause>0)&&!g.cin&&g.awm>=100&&g.aw<=0)awakenStart(g)}
const goalB=goal;goal=function(t){goalB(t);if(t==0&&G){if(G.aw>0)awakenExtend(G);gain(40,50)}};
const startB=start;start=function(l,lb){startB(l,lb);const g=G;g.flow=g.awm=g.fl=g.aw=0;g.run=false;g.skcd=[0,0,0]};
const updB=upd;upd=function(dt){updB(dt);const g=G;if(!g||g.end||g.pause>0||innerHeight>innerWidth)return;const f=g.fl>0?1.5:1;g.skcd=g.skcd.map(c=>Math.max(0,c-dt*f));g.fl=Math.max(0,g.fl-dt);g.aw=Math.max(0,g.aw-dt)};
document.head.appendChild(Object.assign(document.createElement('style'),{textContent:'.rb{position:absolute;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;padding:0;border:3px solid #2fd0ff;background:radial-gradient(circle at 30% 25%,#2a5fb8,#0a1d4a 70%);box-shadow:0 0 10px #2fd0ff99,inset 0 0 10px #000a}.rb:active{transform:scale(.92)}.rb b,.sl b{font-size:22px;line-height:22px;font-weight:400}.rb i,.sl i{font:800 10px sans-serif;font-style:normal}.sl{position:absolute;bottom:10px;width:76px;height:54px;border-radius:9px;border:2px solid #2fd0ff;background:linear-gradient(#123a7a,#0a1d4a);color:#fff;font:800 10px sans-serif;padding:2px;line-height:1.2;box-shadow:0 0 8px #2fd0ff66}.bar{display:block;width:150px;height:24px;border-radius:12px;border:2px solid #fff;color:#fff;font:800 11px sans-serif;padding:0;margin-bottom:6px}'}));
['bs','ba','bd','bl'].forEach(i=>{const e=$(i);if(e)e.style.display='none'});
function mk2(id,ic,lb,css,fn){const b=document.createElement('button');b.id=id;b.className='rb';b.style.cssText=css;b.innerHTML='<b>'+ic+'</b><i>'+lb+'</i>';b.onpointerdown=fn;$('game').appendChild(b)}
mk2('bk','','Kick','right:22px;bottom:20px;width:78px;height:78px',()=>shoot());
mk2('bsl','','Slide','right:112px;bottom:16px;width:64px;height:64px',()=>{if(G&&!G.end)slide(human())});
mk2('bdr','','Dribble','right:20px;bottom:108px;width:68px;height:68px',()=>{if(G&&!G.end)dribble(human())});
mk2('bps','↔','Pass','right:98px;bottom:92px;width:68px;height:68px',()=>pass(1));
mk2('brn','','Run','right:20px;bottom:190px;width:62px;height:62px',()=>{if(G)G.run=!G.run});
for(let i=0;i<3;i++){const b=document.createElement('button');b.id='sl'+i;b.className='sl';b.style.left='calc(50% - 119px + '+i*81+'px)';b.onpointerdown=()=>useSk(i);$('game').appendChild(b)}
const hud=document.createElement('div');hud.style.cssText='position:absolute;left:12px;top:8px';
const fb=document.createElement('button'),wb=document.createElement('button');fb.className=wb.className='bar';fb.onpointerdown=flowOn;wb.onpointerdown=awakeOn;hud.appendChild(fb);hud.appendChild(wb);$('game').appendChild(hud);
function ui(g){const h=human(),l=sk(S.style),now=performance.now();
 if(g.fl>0){const c='47,208,255',gr=cx.createRadialGradient(h.x,h.y-20,5,h.x,h.y-20,60);gr.addColorStop(0,'rgba('+c+',.4)');gr.addColorStop(1,'rgba('+c+',0)');cx.fillStyle=gr;cx.fillRect(h.x-70,h.y-90,140,140);cx.strokeStyle='rgb('+c+')';cx.lineWidth=3+Math.sin(now/90)*1.5;cx.beginPath();cx.ellipse(h.x,h.y+18,30,11,0,0,7);cx.stroke()}
 if(now<(h.shU||0)){cx.strokeStyle='#fff';cx.lineWidth=3;cx.beginPath();cx.ellipse(h.x,h.y-20,28,42,0,0,7);cx.stroke()}
 fb.style.background='linear-gradient(90deg,#111 '+g.flow+'%,#fff '+g.flow+'%)';fb.textContent=g.fl>0?'FLOW '+Math.ceil(g.fl)+'s':g.flow>=100?'¡FLOW LISTO! Toca':'FLOW '+Math.floor(g.flow)+'%';
 const AP=awProfile(S.style&&S.style.n);wb.style.background=g.aw>0?'linear-gradient(90deg,'+AP.c+' '+Math.min(100,100*g.aw/(g.awd||15))+'%,#111 0)':'linear-gradient(90deg,transparent '+g.awm+'%,#fff '+g.awm+'%),repeating-linear-gradient(135deg,#111 0 3px,#fff 3px 6px)';wb.textContent=g.aw>0?AP.h+' '+Math.ceil(g.aw)+'s':g.awm>=100?'¡DESPERTAR LISTO! Toca':'DESPERTAR '+Math.floor(g.awm)+'%';
 $('bsl').style.opacity=g.b.o===h?.35:1;$('brn').style.borderColor=g.run?'#ffd21f':'#2fd0ff';
 for(let i=0;i<3;i++){const d=SKD[l[i]],ok=!d.need||g.b.o===h,t=g.skcd[i]>0?Math.ceil(g.skcd[i])+'s':d.need?(ok?'listo':'sin balón'):'listo',e=$('sl'+i),hh=d.n+'<br>'+t;if(e.dataset.h!=hh){e.dataset.h=hh;e.innerHTML=hh}e.style.opacity=ok&&g.skcd[i]<=0?1:.5}}
const drawC=draw;draw=function(){drawC();if(G)ui(G)};
addEventListener('keydown',e=>{if(!G||G.end)return;const k=e.key.toLowerCase();if(k=='1'||k=='2'||k=='3')useSk(+k-1);if(k=='p')pass(1);if(k=='r')G.run=!G.run;if(k=='x')flowOn();if(k=='c')awakeOn()});
const SUITS=[['#22244c','#0a0b20','#8f78e6'],['#6a2234','#2a0c14','#ff8a4a'],['#1f6b4a','#0a2a1c','#5cffb0'],['#7a6a1f','#2a2408','#ffe35c']],HAIRS=['#ffffff','#2a2a2a','#e0aa48','#aa5640','#4aa3ff','#c36bff'],HAI=['#3b2a1a','#1a1a1a','#e0aa48','#aa5640','#5a4a9a'];
S.look=S.look||{h:'#ffffff',s:0};S.freeRoll=S.freeRoll||0;
/* Aspecto del jugador: por defecto manda TU skin del vestidor; con S.look.pc=1 se usa el aspecto del personaje equipado. */
const lookCh=()=>S.look.pc&&S.style?S.style.n:null;let X=cx;
try{FAB.setTransform(new DOMMatrix().scale(9))}catch(e){}
const CH={lleg:[[335,560],[455,580],[445,700],[405,885],[315,895]],rleg:[[455,582],[525,548],[610,690],[665,810],[590,860],[545,866]],pel:[[340,550],[405,512],[500,530],[525,548],[458,580]],torso:[[278,325],[465,298],[525,545],[330,560]],larm:[[268,330],[300,350],[318,470],[218,632],[138,606],[200,470],[240,380]],rarm:[[470,296],[515,295],[700,445],[718,470],[692,545],[660,520],[560,420],[480,345]]};
function xpart(poly,pv,ang,c,ln){X.save();X.translate(pv[0],pv[1]);X.rotate(ang);X.translate(-pv[0],-pv[1]);const q=Pth(poly);X.fillStyle=c[1];for(let k=5;k>0;k--){X.save();X.translate(5*k,-4*k);X.fill(q);X.restore()}
 const y0=Math.min(...poly.map(s=>s[1])),y1=Math.max(...poly.map(s=>s[1])),g=X.createLinearGradient(0,y0,0,y1);g.addColorStop(0,c[0]);g.addColorStop(1,c[1]);X.fillStyle=g;X.fill(q);X.fillStyle=FAB;X.fill(q);
 if(ln){X.save();X.clip(q);for(const s of ln){X.beginPath();X.moveTo(s[0][0],s[0][1]);X.lineTo(s[1][0],s[1][1]);X.strokeStyle=c[2];X.globalAlpha=.3;X.lineWidth=16;X.stroke();X.globalAlpha=1;X.lineWidth=7;X.stroke()}X.restore()}
 X.lineJoin='round';X.strokeStyle='#05050f';X.lineWidth=13;X.stroke(q);X.restore()}
function drawChar(x,y,sc,o){if(typeof MI==='undefined')return;const w=o.w||0,HX=window.HF&&HF[o.ch],su=(HX&&HX.suit)||o.suit,sk=(HX&&HX.skin[0])||MI.skin,sd=(HX&&HX.skin[1])||MI.skinShadow;X.save();X.translate(x,y);if(o.rot)X.rotate(o.rot);X.scale(sc*(o.dir||1),sc);X.translate(-400,-890);
 xpart(CH.lleg,[400,575],w*.35,su,[[[345,600],[330,880]],[[330,705],[455,690]],[[455,590],[320,780]]]);xpart([[317,858],[409,858],[405,886],[315,896]],[400,575],w*.35,[sk,sd],0);xpart(CH.rleg,[490,570],-w*.35,su,[[[500,600],[640,820]],[[470,690],[620,700]],[[525,560],[560,780]]]);xpart([[600,840],[665,809],[666,816],[590,861],[546,867]],[490,570],-w*.35,[sk,sd],0);
 xpart(CH.pel,[0,0],0,su,[[[345,552],[520,548]]]);xpart([[300,280],[365,280],[370,325],[300,330]],[0,0],0,[sk,sd],0);
 xpart(CH.torso,[0,0],0,su,[[[285,335],[520,540]],[[460,305],[335,555]],[[400,296],[400,552]],[[275,440],[525,430]],[[300,500],[510,505]]]);xpart([[296,288],[372,284],[378,334],[290,338]],[0,0],0,su,[[[290,312],[380,308]]]);
 X.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3;X.lineTo(330+24*Math.cos(a),385+24*Math.sin(a))}X.closePath();X.fillStyle='#07121a';X.fill();X.strokeStyle='#3fe0b8';X.lineWidth=9;X.stroke();
 xpart(CH.larm,[285,335],-w*.3,su,[[[285,360],[170,615]],[[215,440],[320,500]],[[190,540],[290,560]]]);xpart(CH.rarm,[480,300],w*.3,su,[[[490,310],[700,480]],[[600,390],[620,520]],[[540,350],[690,420]]]);
 if(HX&&HX.back)HX.back();const hg=X.createRadialGradient(300,200,10,338,230,110);hg.addColorStop(0,sk);hg.addColorStop(1,sd);X.fillStyle=hg;X.beginPath();X.ellipse(MI.head.cx,MI.head.cy,MI.head.rx,MI.head.ry,-.06,0,7);X.fill();X.strokeStyle='#05050f';X.lineWidth=13;X.stroke();
 if(HX)HX.front();else{X.fillStyle=o.hair;X.beginPath();MI.hair.forEach((s,i)=>i?X.lineTo(s[0],s[1]):X.moveTo(s[0],s[1]));X.closePath();X.fill();X.stroke();
 X.strokeStyle='rgba(0,0,0,.25)';X.lineWidth=8;X.beginPath();X.moveTo(300,170);X.lineTo(295,120);X.moveTo(350,160);X.lineTo(358,100);X.moveTo(400,165);X.lineTo(430,115);X.stroke()}
 X.fillStyle=MI.eyes;X.beginPath();X.ellipse(300,242,11,17,0,0,7);X.ellipse(378,238,11,17,0,0,7);X.fill();X.fillStyle='#fff';X.fillRect(296,232,6,6);X.fillRect(374,228,6,6);
 X.strokeStyle='#14142a';X.lineWidth=9;X.beginPath();X.moveTo(282,214);X.lineTo(318,220);X.moveTo(396,214);X.lineTo(360,220);X.moveTo(330,280);X.lineTo(352,282);X.stroke();MI.extra&&MI.extra(X);X.restore()}
function blocky(p){X=cx;const sp=Math.hypot(p.vx,p.vy),w=Math.sin(p.ph||0)*Math.min(1,sp/110),fy=p.y+18,dir=p.fx<-.15?-1:p.fx>.15?1:(p.dl||1);p.dl=dir;
 cx.fillStyle='rgba(0,0,0,.3)';cx.beginPath();cx.ellipse(p.x,fy,19,6,0,0,7);cx.fill();
 if(p.h){cx.strokeStyle='#ffd21f';cx.lineWidth=2.5;cx.beginPath();cx.ellipse(p.x,fy,23,8,0,0,7);cx.stroke()}
 drawChar(p.x,fy,.1,{me:p===human(),dir,w,rot:p.fall>0?dir*1.5:p.sl>0?dir*1.25:0,suit:SUITS[p.t&&!p.h?(S.look.s+1)%4:S.look.s],hair:p.h?S.look.h:HAI[(p.i+p.t*2)%5],ch:p.h?lookCh():null});
 if(p.h){cx.fillStyle='#fff';cx.strokeStyle='#111';cx.lineWidth=3;cx.font='bold 14px sans-serif';cx.textAlign='center';cx.strokeText(S.name||'Tú',p.x,fy-90);cx.fillText(S.name||'Tú',p.x,fy-90);cx.fillStyle='#ffd21f';cx.beginPath();cx.moveTo(p.x-6,fy-85);cx.lineTo(p.x+6,fy-85);cx.lineTo(p.x,fy-78);cx.fill()}}
document.head.appendChild(Object.assign(document.createElement('style'),{textContent:'#game.lob .m{display:none}#game:not(.lob) .lu{display:none}#pn{position:fixed;inset:0;z-index:8;background:rgba(5,8,20,.88);display:flex;align-items:center;justify-content:center}#pn,#pn *{touch-action:pan-y}#pb{background:var(--card);color:var(--fg);border-radius:16px;padding:14px;display:flex;flex-wrap:wrap;gap:14px;align-items:center;justify-content:center;max-width:94vw;max-height:94vh;overflow:auto}#pn .col{display:flex;flex-direction:column;gap:8px;min-width:190px;max-width:240px;align-items:stretch}#pn .rw{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}#pn .sw{width:34px;height:34px;border-radius:50%;padding:0;border:3px solid #fff}#pn canvas{background:#0e1536;border-radius:12px;max-width:100%}'}));
let PN=null,pA=null;
function panel(h){closeP();PN=document.createElement('div');PN.id='pn';PN.innerHTML='<div id=pb>'+h+'</div>';document.body.appendChild(PN)}
function closeP(){if(PN){PN.remove();PN=null}pA=null}
function pd(c,w,h,fn){const f=t=>{if(pA!==f)return;X=c;c.clearRect(0,0,w,h);fn(t);X=cx;requestAnimationFrame(f)};pA=f;requestAnimationFrame(f)}
function wardrobe(){panel('<canvas id=pc width=200 height=240></canvas><div class=col><label>Nombre</label><input id=nm2 maxlength=14 placeholder=Nombre><label>Pelo</label><div class=rw id=wh></div><label>Traje</label><div class=rw id=ws></div><label>Aspecto</label><div class=rw id=wl></div><button id=pk>Listo</button></div>');
 const c=$('pc').getContext('2d'),i=$('nm2');i.value=S.name;i.oninput=()=>{S.name=i.value.trim();save()};
 HAIRS.forEach(h=>{const b=document.createElement('button');b.className='sw';b.style.background=h;b.onclick=()=>{S.look.h=h;save()};$('wh').appendChild(b)});
 SUITS.forEach((s,k)=>{const b=document.createElement('button');b.className='sw';b.style.background='linear-gradient(135deg,'+s[0]+' 50%,'+s[2]+' 50%)';b.onclick=()=>{S.look.s=k;save()};$('ws').appendChild(b)});
 const wl=()=>{$('wl').innerHTML='';[['Mi skin',0],['Personaje',1]].forEach(([t,v])=>{const b=document.createElement('button');b.textContent=t;b.className=(S.look.pc?1:0)==v?'on':'g';b.onclick=()=>{S.look.pc=v;save();wl()};$('wl').appendChild(b)})};wl();
 $('pk').onclick=()=>{if(!S.name){i.style.borderColor='#e8233b';return}closeP()};
 pd(c,200,240,t=>{c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.ellipse(100,218,48,12,0,0,7);c.fill();drawChar(100,218,.21,{dir:1,w:Math.sin(t/500)*.2,me:1,suit:SUITS[S.look.s],hair:S.look.h,ch:lookCh()})})}
function rollP(){panel('<canvas id=pc width=320 height=250></canvas><div class=col><div id=rc></div><button id=rg class=r></button><button id=rx class=g>Cerrar</button></div>');
 const c=$('pc').getContext('2d');let md=0,t0=0,res=null;
 const lab=()=>{$('rg').textContent=S.freeRoll>0?'Roll gratis ('+S.freeRoll+')':S.style?'Roll (30 monedas)':'Primer roll gratis'},info=()=>{const s=S.style;$('rc').innerHTML=s?'<b>'+s.n+'</b> ('+RN[s.r]+')<br>'+sk(s).map(k=>SKD[k].n).join(' · ')+'<br>Monedas: '+S.coins:'Sin estilo todavía'};lab();info();
 $('rx').onclick=closeP;
 $('rg').onclick=()=>{if(md)return;const fr=S.freeRoll>0,cost=fr?0:S.style?30:0;if(S.coins<cost){$('rc').textContent='Te faltan monedas.';return}if(fr)S.freeRoll--;S.coins-=cost;md=1;t0=performance.now();res=rollStyle();$('rc').textContent='Girando...'};
 pd(c,320,250,t=>{if(md&&t-t0>1900){md=0;S.style=res;save();lab();info()}
  const r=md?Math.floor(t/110)%4:S.style?S.style.r:0,col=RC[r];c.save();c.translate(160,130);c.rotate(t/1500);for(let i=0;i<14;i++){c.rotate(Math.PI*2/14);c.fillStyle=col;c.globalAlpha=md?.35:.2;c.beginPath();c.moveTo(0,0);c.lineTo(300,-24);c.lineTo(300,24);c.fill()}c.restore();c.globalAlpha=1;
  c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.ellipse(160,226,50,12,0,0,7);c.fill();
  drawChar(160+(md?(Math.random()-.5)*6:0),226,.2,{dir:1,w:md?Math.sin(t/60)*.6:Math.sin(t/400)*.15,me:1,suit:SUITS[S.look.s],hair:md?col:S.look.h});
  c.textAlign='center';c.font='italic 900 20px sans-serif';c.fillStyle='#fff';c.strokeStyle='#000';c.lineWidth=4;const tx=md?ST[Math.floor(t/80)%ST.length][0]:S.style?S.style.n:'¿?';c.strokeText(tx,160,24);c.fillText(tx,160,24)})}
const PZ=[['20',20],['50',50],['ROLL',0,1],['100',100],['30',30],['200',200],['10',10],['500',500]],PW=[20,17,12,6,22,3,19,1];
function luckyP(){panel('<canvas id=pc width=280 height=280></canvas><div class=col><div id=rc>Gira y gana monedas o rolls</div><button id=rg class=r></button><button id=rx class=g>Cerrar</button></div>');
 const c=$('pc').getContext('2d');let rot=0,sp=null;const free=()=>!S.lk||Date.now()-S.lk>864e5,lab=()=>{$('rg').textContent=free()?'Giro gratis':'Girar (20 monedas)'};lab();$('rx').onclick=closeP;
 $('rg').onclick=()=>{if(sp)return;if(!free()){if(S.coins<20){$('rc').textContent='Te faltan monedas.';return}S.coins-=20}else S.lk=Date.now();save();let r=Math.random()*100,i=0;for(;i<7;i++){if(r<PW[i])break;r-=PW[i]}
  sp={f:rot,to:Math.ceil((rot+1800)/360)*360-(i*45+22.5)+(Math.random()-.5)*28,t0:performance.now(),i};$('rc').textContent='Girando...'};
 pd(c,280,280,t=>{if(sp){const k=Math.min(1,(t-sp.t0)/3200);rot=sp.f+(sp.to-sp.f)*(1-Math.pow(1-k,3));if(k>=1){const z=PZ[sp.i];if(z[2])S.freeRoll++;else S.coins+=z[1];save();$('rc').textContent=z[2]?'¡Ganaste un Roll gratis!':'¡Ganaste '+z[1]+' monedas!';sp=null;lab()}}
  c.save();c.translate(140,150);c.rotate(rot*Math.PI/180);for(let i=0;i<8;i++){c.fillStyle=PZ[i][2]?'#b24dff':i%2?'#1f6bff':'#e8233b';c.beginPath();c.moveTo(0,0);c.arc(0,0,120,(i*45-90)*Math.PI/180,(i*45-45)*Math.PI/180);c.fill();c.strokeStyle='#fff';c.lineWidth=2;c.stroke();c.save();c.rotate((i*45+22.5)*Math.PI/180);c.fillStyle='#fff';c.font='bold 18px sans-serif';c.textAlign='center';c.fillText(PZ[i][0],0,-80);c.restore()}c.restore();
  c.fillStyle='#ffd21f';c.beginPath();c.moveTo(128,4);c.lineTo(152,4);c.lineTo(140,36);c.fill();c.beginPath();c.arc(140,150,12,0,7);c.fill()})}
function doorP(){panel('<div class=col><b>Campo</b><div class=rw id=dz></div><div id=dm></div><button id=dq>Partido rápido</button><button id=dt class=r>Ranked</button><button id=dx class=g>Cerrar</button></div>');
 for(let i=1;i<=3;i++){const b=document.createElement('button');b.textContent=i+'v'+i;b.className=i==size?'on':'g';b.onclick=()=>{size=i;[...$('dz').children].forEach((e,k)=>e.className=k+1==size?'on':'g')};$('dz').appendChild(b)}
 $('dx').onclick=closeP;const go=f=>{if(!S.style){$('dm').textContent='Primero haz tu Roll de estilo.';return}closeP();f()};
 $('dq').onclick=()=>go(()=>{RKM=null;start(.9,'Partido rápido')});$('dt').onclick=()=>go(()=>rankedP())}
let LB=null;const STN=[{id:'mir',x:130,n:'Vestidor'},{id:'lucky',x:300,n:'Giro de Suerte'},{id:'roll',x:500,n:'Roll de Estilos'},{id:'door',x:670,n:'Campo'}];
const near=()=>{if(!LB||LB.y>=275)return;let b=null,d=75;for(const s of STN){const e=Math.abs(LB.x-s.x);if(e<d){d=e;b=s}}return b};
function inter(id){({mir:wardrobe,lucky:luckyP,roll:rollP,door:doorP})[id]()}
function lobby(){G=null;cv.style.transform='';$('game').classList.remove('cine');RKM=null;closeP();$('menu').style.display='none';$('ov').style.display='none';$('game').style.display='block';$('game').classList.add('lob');LB=LB||{x:400,y:340,fx:1,vx:0,vy:0,ph:0};['bk','bsl','bdr','bps','brn','sl0','sl1','sl2','ex'].forEach(i=>$(i).classList.add('m'));hud.classList.add('m');fit();chk();if(!S.name)wardrobe()}
mk2('bu','','Usar','right:22px;bottom:20px;width:84px;height:84px',()=>{const n=near();if(n&&!PN)inter(n.id)});$('bu').classList.add('lu');
const startL=start;start=function(l,b){LB=null;closeP();$('game').classList.remove('lob');startL(l,b)};
function lobFrame(dt){const L=LB;let jx=joy.x+(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0),jy=joy.y+(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0);const m=Math.hypot(jx,jy);if(m>1){jx/=m;jy/=m}if(PN)jx=jy=0;
 L.vx+=(jx*170-L.vx)*Math.min(1,dt*10);L.vy+=(jy*170-L.vy)*Math.min(1,dt*10);L.x=Math.min(770,Math.max(30,L.x+L.vx*dt));L.y=Math.min(430,Math.max(215,L.y+L.vy*dt));if(Math.abs(jx)>.1)L.fx=jx>0?1:-1;L.ph+=dt*Math.hypot(L.vx,L.vy)/22;$('bu').style.opacity=near()?1:.4}
function stn(s,t,nr){const x=s.x;X=cx;if(nr){cx.strokeStyle='#ffd21f';cx.lineWidth=3;cx.beginPath();cx.ellipse(x,206,54,14,0,0,7);cx.stroke()}
 cx.fillStyle='rgba(0,0,0,.3)';cx.beginPath();cx.ellipse(x,200,46,10,0,0,7);cx.fill();
 if(s.id=='mir'){cx.fillStyle='#8a5a2b';cx.fillRect(x-34,60,68,136);const g=cx.createLinearGradient(x-28,68,x+28,188);g.addColorStop(0,'#cfeaff');g.addColorStop(1,'#6aa4e0');cx.fillStyle=g;cx.fillRect(x-28,68,56,120);cx.save();cx.globalAlpha=.7;cx.beginPath();cx.rect(x-28,68,56,120);cx.clip();drawChar(x,186,.1,{dir:1,me:1,suit:SUITS[S.look.s],hair:S.look.h,ch:lookCh()});cx.restore()}
 else if(s.id=='lucky'){cx.fillStyle='#555';cx.fillRect(x-6,140,12,56);cx.save();cx.translate(x,100);cx.rotate(t/2500);for(let i=0;i<8;i++){cx.fillStyle=i%2?'#1f6bff':'#e8233b';cx.beginPath();cx.moveTo(0,0);cx.arc(0,0,44,i*Math.PI/4,(i+1)*Math.PI/4);cx.fill()}cx.restore();cx.fillStyle='#ffd21f';cx.beginPath();cx.moveTo(x-6,52);cx.lineTo(x+6,52);cx.lineTo(x,64);cx.fill()}
 else if(s.id=='roll'){const g=cx.createLinearGradient(x-34,0,x+34,0);g.addColorStop(0,'#5a1fa8');g.addColorStop(.5,'#9a4cff');g.addColorStop(1,'#4a1890');cx.fillStyle=g;cx.fillRect(x-34,100,68,96);cx.fillStyle='#0b0c22';cx.fillRect(x-14,160,28,22);cx.fillStyle='rgba(190,235,255,.45)';cx.beginPath();cx.arc(x,92,36,0,7);cx.fill();RC.concat(RC).forEach((c2,i)=>{cx.fillStyle=c2;cx.beginPath();cx.arc(x-20+(i%4)*13,98+Math.sin(t/300+i)*4-(i>3?14:0),6,0,7);cx.fill()})}
 else{cx.fillStyle='#10132a';cx.fillRect(x-40,62,80,134);const g=cx.createLinearGradient(0,70,0,196);g.addColorStop(0,'#bfffd6');g.addColorStop(1,'#2fb865');cx.fillStyle=g;cx.fillRect(x-32,70,64,126);cx.strokeStyle='#ffd21f';cx.lineWidth=3;cx.strokeRect(x-40,62,80,134)}
 cx.font='bold 13px sans-serif';cx.textAlign='center';cx.strokeStyle='#000';cx.lineWidth=3;cx.fillStyle='#fff';cx.strokeText(s.n,x,x>=560?64:50);cx.fillText(s.n,x,x>=560?64:50);if(nr){cx.fillStyle='#ffd21f';cx.fillText('¡Toca Usar!',x,232)}}
function lobDraw(t){const L=LB;X=cx;cx.clearRect(0,0,W,H);let g=cx.createLinearGradient(0,0,0,190);g.addColorStop(0,'#1d2a66');g.addColorStop(1,'#0e1536');cx.fillStyle=g;cx.fillRect(0,0,W,190);
 for(let i=0;i<11;i++){const x=i*74+4,lg=cx.createLinearGradient(x,0,x+66,0);lg.addColorStop(0,'#3f5fb0');lg.addColorStop(.5,'#5d84d6');lg.addColorStop(1,'#34509a');cx.fillStyle=lg;cx.fillRect(x,30,66,150);cx.fillStyle='#0b1230';for(let k=0;k<3;k++)cx.fillRect(x+10,42+k*10,46,5);cx.fillStyle='#ffd21f';cx.fillRect(x+54,110,4,16);cx.strokeStyle='#0b1230';cx.lineWidth=2;cx.strokeRect(x,30,66,150)}
 g=cx.createLinearGradient(0,190,0,H);g.addColorStop(0,'#2a3a7a');g.addColorStop(1,'#101a45');cx.fillStyle=g;cx.fillRect(0,190,W,H-190);cx.strokeStyle='rgba(120,160,255,.15)';cx.lineWidth=2;for(let i=0;i<9;i++){const y=190+Math.pow(i/8,1.6)*260;cx.beginPath();cx.moveTo(0,y);cx.lineTo(W,y);cx.stroke()}for(let i=-8;i<=8;i++){cx.beginPath();cx.moveTo(400+i*60,190);cx.lineTo(400+i*150,H);cx.stroke()}
 cx.fillStyle='#2fd0ff';cx.fillRect(0,184,W,6);const n=near();STN.forEach(s=>stn(s,t,n===s));
 cx.fillStyle='rgba(0,0,0,.45)';cx.fillRect(W/2-130,6,260,28);cx.fillStyle='#fff';cx.font='bold 15px sans-serif';cx.textAlign='center';cx.fillText((S.name||'Jugador')+'  ·  '+S.coins+' monedas',W/2,26);
 cx.fillStyle='rgba(0,0,0,.3)';cx.beginPath();cx.ellipse(L.x,L.y,22,7,0,0,7);cx.fill();drawChar(L.x,L.y,.125,{dir:L.fx,w:Math.sin(L.ph)*Math.min(1,Math.hypot(L.vx,L.vy)/100),me:1,suit:SUITS[S.look.s],hair:S.look.h,ch:lookCh()})}
let lt=0;(function lf(n){const dt=Math.min(.05,(n-lt)/1000);lt=n;if(LB&&!G&&$('game').style.display=='block'&&innerHeight<=innerWidth){lobFrame(dt);lobDraw(n)}requestAnimationFrame(lf)})(0);
addEventListener('keydown',e=>{if(LB&&!PN&&e.key.toLowerCase()=='e'){const n=near();if(n)inter(n.id)}});
const NORM=[55,28,13,4],LUCK=[30,32,23,15],DIF=['Fácil','Media','Alta','Élite'];
function lk(n){let h=0;for(const c of n)h=(h*31+c.charCodeAt(0))>>>0;return{hair:HAIRS[h%6],suit:SUITS[(h>>>3)%4]}}
function rollP(){closeP();S.own=S.own||[];if(S.style&&!S.own.find(o=>o.n==S.style.n))S.own.push(S.style);if(!S.rs0){S.rs0=1;S.freeRoll+=3}S.ls=S.ls||0;save();
 const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;z-index:8;background:#000;display:flex;align-items:center;justify-content:center';const cv2=document.createElement('canvas');cv2.width=W;cv2.height=H;ov.appendChild(cv2);document.body.appendChild(ov);const c=cv2.getContext('2d');
 const R={show:S.style,lucky:false,md:0,t0:0,res:null,fx:-9e9,msg:'',hits:[]};let alive=true;const close=()=>{alive=false;ov.remove()};{const xb=document.createElement('button');xb.className='xc';xb.textContent='\u2715';xb.setAttribute('aria-label','Cerrar');xb.onclick=close;ov.appendChild(xb)}
 cv2.onpointerdown=e=>{const r=cv2.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;for(const h of R.hits)if(x>=h.x&&x<=h.x+h.w&&y>=h.y&&y<=h.y+h.h){h.fn();break}};
 const pick=a=>{let r=Math.random()*a.reduce((s,v)=>s+v,0),i=0;for(;i<a.length-1;i++){if(r<a[i])break;r-=a[i]}return i};
 const fin=()=>{R.md=0;const s=R.res;R.show=s;R.fx=performance.now();if(S.own.find(o=>o.n==s.n)){if(R.pm&&s.r>=3){S.gems+=2;R.msg='Repetido: +2 gemas'}else{S.coins+=10*(s.r+1);R.msg='Repetido: +'+10*(s.r+1)+' monedas'}}else{R.msg=addChar(s)}save()};
 const go=()=>{if(R.md)return;R.msg='';R.pm=0;if(S.freeRoll<1){if(S.coins>=30){S.coins-=30;S.freeRoll++;R.msg='Giro comprado con 30 monedas'}else{R.msg='Sin giros ni 30 monedas. Gana partidos o usa Premium.';return}}const lu=R.lucky&&S.ls>0;if(R.lucky&&!lu)R.msg='Sin giros de suerte: probabilidad normal';S.freeRoll--;if(lu)S.ls--;let r=pick(lu?LUCK:NORM);S.pity=(S.pity||0)+1;if(S.pity>=30&&r<2)r=2+(Math.random()<.3?1:0);if(r>=2)S.pity=0;const p=ST.filter(e=>e[1]==r),e=p[Math.floor(Math.random()*p.length)];R.res={n:e[0],r:e[1],ab:e[2]};save();if(S.skip)fin();else{R.md=1;R.t0=performance.now()}};
 const gemGo=()=>{if(R.md)return;R.msg='';if((S.gems||0)<10){R.msg='Te faltan gemas (10)';return}S.gems-=10;R.pm=1;const P=[0,30,40,20,7,2.5,.5];let r=pick(P),p=ST.filter(e=>e[1]==r);while(!p.length&&r>1){r--;p=ST.filter(e=>e[1]==r)}const e=p[Math.floor(Math.random()*p.length)];S.pity=0;R.res={n:e[0],r:e[1],ab:e[2]};save();if(S.skip)fin();else{R.md=1;R.t0=performance.now()}};const tx=(s,x,y,sz,col)=>skTx(c,s,x,y,sz,col);
 const bt=(x,y,w,h,s,bg,bd,fn,sz)=>{skBtn(c,x,y,w,h,s,bg,sz);R.hits.push({x,y,w,h,fn})};
 (function f(t){if(!alive)return;const k=Math.min(innerWidth/W,innerHeight/H);cv2.style.width=W*k+'px';cv2.style.height=H*k+'px';X=c;R.hits=[];if(R.md&&t-R.t0>1800)fin();
  skPaper(c);
  c.strokeStyle='rgba(43,43,48,.16)';c.lineWidth=2.2;c.lineCap='round';for(let i=0;i<8;i++){c.beginPath();c.moveTo(i*115,0);c.lineTo(400+(i-3.5)*40,250);c.stroke()}
  skFloor(c);c.strokeStyle='#2b2b30';c.lineWidth=2.4;c.beginPath();c.moveTo(0,370);c.lineTo(330,300);c.moveTo(800,370);c.lineTo(470,300);c.stroke();
  const sh=R.md?{n:ST[Math.floor(t/70)%ST.length][0],r:Math.floor(t/110)%4}:R.show,col=sh?RC[sh.r]:'#2fd0ff';
  c.save();c.translate(400,260);c.rotate(t/2000);for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.fillStyle=col;c.globalAlpha=R.md?.28:.14;c.beginPath();c.moveTo(0,0);c.lineTo(500,-34);c.lineTo(500,34);c.fill()}c.restore();c.globalAlpha=1;
  c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.ellipse(400,392,70,14,0,0,7);c.fill();
  const lo=sh&&!(S.style&&sh.n==S.style.n)?lk(sh.n):{hair:S.look.h,suit:SUITS[S.look.s]};
  drawChar(400+(R.md?Math.sin(t/40)*4:0),392,.38,{dir:1,w:R.md?Math.sin(t/70)*.7:Math.sin(t/500)*.25,suit:lo.suit,hair:lo.hair,ch:sh&&sh.n});
  const dt=t-R.fx;if(dt<900){const p=dt/900;c.fillStyle='rgba(255,236,160,'+(1-p)*.55+')';c.fillRect(0,0,W,H);c.strokeStyle=col;c.globalAlpha=1-p;c.lineWidth=7;for(let i=0;i<5;i++){c.beginPath();c.moveTo(250+i*70+p*60,330-p*20);c.lineTo(310+i*70+p*60,150-p*20);c.stroke()}c.globalAlpha=1}
  tx(sh?sh.n:'¿?',400,40,38,'#fff');if(sh){tx(sk(sh).map(q=>SKD[q].n).join(' · '),400,64,13,'#dfe8ff');tx('Dificultad: '+DIF[sh.r],400,84,14,RC[sh.r])}else tx('Haz tu primer giro',400,64,13,'#dfe8ff');
  tx(R.msg,400,108,18,'#ffd21f');
  tx('Estilos: '+S.own.length,66,56,12,'#fff');[...S.own].sort((a,b)=>b.r-a.r).slice(0,4).forEach((o,i)=>{const y=66+i*68,eq=S.style&&S.style.n==o.n;crect(c,10,y,112,60,'#fcf9f1',RC[o.r]);tx(o.n,66,y+20,12,'#fff');bt(18,y+30,96,24,eq?'Equipado':'Equipar',eq?'#1c7a3a':'#2a2a5a','#fff',()=>{S.style=o;R.show=o;save()},12)});
  bt(610,48,86,24,'NORMAL',R.lucky?'#1b2a6a':'#1c7a3a','#e8c14a',()=>{R.lucky=false},12);bt(702,48,86,24,'SUERTE',R.lucky?'#1c7a3a':'#1b2a6a','#e8c14a',()=>{R.lucky=true},12);
  const od=R.lucky?LUCK:NORM;for(let i=6;i>=0;i--){const y=84+(6-i)*32;crect(c,610,y,178,28,'#fcf9f1',RC[i]);tx(RN[i]+' - '+(od[i]!=null?od[i]+'%':'solo premium'),700,y+19,13,'#fff')}
  gi(c,'gem',134,360,20);tx((S.gems||0)+' · Pity '+(S.pity||0)+'/30',217,374,13,'#d9a0ff');tx('Suerte: '+S.ls,207,392,13,'#ffd21f');bt(290,398,220,40,R.md?'GIRANDO...':'GIROS RESTANTES: '+S.freeRoll,'#1c7a3a','#7dff9a',go,16);
  bt(130,404,154,34,'PREMIUM 10','#5a1fa8','#d9a0ff',gemGo,13);gi(c,'gem',252,409,22);bt(14,404,110,34,'VOLVER','#a01020','#ff6a6a',close,16);
  bt(620,316,170,32,'SKIP GIROS: '+(S.skip?'ON':'OFF'),'#14306a','#2fd0ff',()=>{S.skip=!S.skip;save()},13);
  bt(620,352,170,30,'COMPRAR GIRO (30)','#6a4a14','#e8c14a',()=>{if(S.coins>=30){S.coins-=30;S.freeRoll++;save()}else R.msg='Te faltan monedas'},12);
  crect(c,620,388,170,26,'#fcf9f1','#3b8f5a');gi(c,'coin',630,390,22);tx(S.coins.toLocaleString(),715,407,15,'#8dff8d');
  bt(620,418,170,28,'COMPRAR SUERTE (100)','#6a4a14','#e8c14a',()=>{if(S.coins>=100){S.coins-=100;S.ls+=3;save()}else R.msg='Te faltan monedas'},12);
  X=cx;requestAnimationFrame(f)})(performance.now())}
AB.meta=["Meta Visión","Ralentiza rivales"];AB.chaos=["Tiro Caótico","Tiro curvo imparable"];
ST.push(["Depredador",3,"meta"],["Rey Egoísta",3,"chaos"],["Genio del Caos",2,"chaos"],["Visionario",2,"pass"],["Cazagoles Hambriento",1,"shot"]);
Object.assign(NSK,{"Depredador":["meta","shot","dash"],"Rey Egoísta":["chaos","shot","blitz"],"Genio del Caos":["chaos","turn","meta"],"Visionario":["meta","pass","magnet"],"Cazagoles Hambriento":["shot","blitz","dash"]});
SKD.meta={n:"Meta Visión",cd:14};SKD.chaos={n:"Tiro Caótico",need:1,cd:8};
const useSkB=useSk;
useSk=function(i){const g=G;if(!g||g.end||g.pause>0)return;const id=sk(S.style)[i];
 if(id=="meta"||id=="chaos"){const p=human(),d=SKD[id];if(g.skcd[i]>0||p.fall>0)return;if(d.need&&g.b.o!==p)return;
  if(id=="meta")g.meta=3.5;else{kickBall(p,W,H/2+(Math.random()-.5)*60,800*(1+.1*S.style.r));g.curve={t:.8,a:(Math.random()<.5?-1:1)*900}}
  g.skcd[i]=d.cd;g.fxs.push({t:1,x:p.x,y:p.y-95,s:d.n});return}
 useSkB(i)};
const RK=[[0,"Novato"],[5,"Delantero"],[15,"Egoísta"],[40,"Número 1"]];
const rank=()=>{if(typeof rkName=="function"&&S.rk&&(S.rk.w+S.rk.l)>0)return rkName();let r=RK[0][1];for(const k of RK)if((S.goals||0)>=k[0])r=k[1];return r};
const sb=document.createElement("button");sb.className="bar";sb.style.cssText+=";margin-top:0";hud.appendChild(sb);
const startK=start;start=function(l,b){startK(l,b);const g=G;g.st=100;g.meta=0;g.l0=0;g.gfx=0;g.curve=null;g.kp=[{x:16,y:H/2},{x:W-16,y:H/2}]};
const updK=upd;
upd=function(dt){const g=G;if(!g||g.end||innerHeight>innerWidth)return updK(dt);
 if(g.meta>0){if(!g.l0)g.l0=g.lvl;g.lvl=g.l0*.5;g.meta-=dt}else if(g.l0){g.lvl=g.l0;g.l0=0}
 const h=human(),mv=Math.hypot(h.vx,h.vy)>20;
 if(g.pause<=0){if(g.run&&mv)g.st=Math.max(0,g.st-dt*20);else g.st=Math.min(100,g.st+dt*(g.run?6:14));if(g.st<=0)g.run=false}
 updK(dt);g.gfx=Math.max(0,(g.gfx||0)-dt);
 if(g.pause>0||g.end)return;const b=g.b;
 if(g.curve&&g.curve.t>0&&!b.o){g.curve.t-=dt;b.vy+=g.curve.a*dt}
 g.kp.forEach((k,t)=>{const mx=t?G.lvl*125:105;const dy=Math.max(GY0+12,Math.min(GY1-12,b.y))-k.y;k.y+=Math.max(-mx*dt,Math.min(mx*dt,dy));
  if(!b.o&&Math.abs(b.x-k.x)<24&&Math.abs(b.y-k.y)<28){b.vx=(t?-1:1)*Math.max(260,Math.abs(b.vx)*.7);b.vy+=(b.y-k.y)*6;b.x=k.x+(t?-1:1)*24;g.fxs.push({t:.8,x:k.x,y:k.y-60,s:"¡Atajada!"})}})};
const drawK=draw;
draw=function(){drawK();const g=G;if(!g||!g.kp)return;X=cx;
 g.kp.forEach((k,t)=>{cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(k.x,k.y+18,19,6,0,0,7);cx.fill();drawChar(k.x,k.y+18,.1,{dir:t?-1:1,w:Math.sin(performance.now()/150)*.25,suit:SUITS[t?3:2],hair:HAI[t?1:3]})});
 if(g.meta>0){cx.fillStyle="rgba(20,70,255,.16)";cx.fillRect(0,0,W,H);cx.strokeStyle="rgba(120,200,255,.35)";cx.lineWidth=2;cx.beginPath();cx.arc(g.b.x,g.b.y,16+Math.sin(performance.now()/80)*3,0,7);cx.stroke()}
 if(g.gfx>0){const a=Math.min(1,g.gfx*2);cx.save();cx.globalAlpha=a*.55;cx.strokeStyle="#2fd0ff";cx.lineWidth=3;for(let i=0;i<28;i++){const y=(i*37+performance.now()*.9)%H;cx.beginPath();cx.moveTo(0,y);cx.lineTo(W,y-60);cx.stroke()}cx.restore();
  cx.save();cx.globalAlpha=a;cx.translate(W/2,H/2+30);cx.rotate(-.08);cx.textAlign="center";cx.font="italic 900 78px sans-serif";cx.lineWidth=10;cx.strokeStyle="#0a1a6a";cx.strokeText("¡GOOOL!",0,0);cx.fillStyle="#fff";cx.fillText("¡GOOOL!",0,0);cx.font="italic 900 24px sans-serif";cx.fillStyle="#2fd0ff";cx.fillText("EGO +1",0,34);cx.restore()}
 const f=g.st/100;sb.style.background="linear-gradient(90deg,"+(f<.25?"#ff4a4a":"#5cff8a")+" "+g.st+"%,#10304f "+g.st+"%)";sb.textContent="STAMINA "+Math.floor(g.st)+"%"};
const lobK=lobDraw;
lobDraw=function(t){lobK(t);cx.fillStyle="rgba(0,0,0,.45)";cx.fillRect(W/2-130,424,260,22);cx.fillStyle="#2fd0ff";cx.font="bold 13px sans-serif";cx.textAlign="center";cx.fillText("Rango: "+rank()+"  ·  Goles: "+(S.goals||0),W/2,440)};
const goalK=goal;goal=function(t){goalK(t);if(G&&t==0){G.gfx=1.4;S.goals=(S.goals||0)+1;save()}};

const C={on:false,t0:0,drag:false,dx:0,dy:0,cxp:0,cyp:0};
function aimDir(p){let ax,ay;
 if(C.drag){ax=C.dx;ay=C.dy}
 else if(Math.hypot(joy.x,joy.y)>.3){ax=joy.x;ay=joy.y}
 else{ax=(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0);ay=(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0)}
 if(Math.hypot(ax,ay)<.3){ax=p.fx;ay=p.fy}
 let m=Math.hypot(ax,ay)||1;ax/=m;ay/=m;
 if(ax>.15){const yy=p.y+ay/ax*(W-p.x),lo=GY0+16,hi=GY1-16;
  if(yy>lo-55&&yy<hi+55){const ty=Math.min(hi,Math.max(lo,yy)),dx=W-p.x,dy=ty-p.y,mm=Math.hypot(dx,dy);ax=dx/mm;ay=dy/mm}}
 return{x:ax,y:ay}}
const chg=()=>C.on?Math.min(1,(performance.now()-C.t0)/700):0;
function chargeStart(){const g=G;if(!g||g.end||g.pause>0||C.on)return;const p=human();if(p.fall>0)return;C.on=true;C.t0=performance.now()}
function chargeRelease(){if(!C.on)return;const ch=chg();C.on=false;const g=G;if(!g||g.end||g.pause>0)return;
 const p=human(),b=g.b;if(p.fall>0)return;if(b.o!==p&&(b.o||Math.hypot(b.x-p.x,b.y-p.y)>PR+BR+24))return;
 const a=aimDir(p),pw=Math.min(900,(440+420*ch)*(1+.06*S.style.r)*(g.aw>0?1.4:g.fl>0?1.2:1));
 b.o=null;p.pk=.4;b.x=p.x+a.x*(PR+BR+2);b.y=p.y+a.y*(PR+BR+2);b.vx=a.x*pw;b.vy=a.y*pw;p.fx=a.x;p.fy=a.y;gain(5,0)}
shoot=function(){chargeStart()};
{const bk=$('bk');
 bk.onpointerdown=e=>{e.preventDefault();bk.setPointerCapture(e.pointerId);const r=bk.getBoundingClientRect();C.cxp=r.left+r.width/2;C.cyp=r.top+r.height/2;C.drag=false;chargeStart()};
 bk.onpointermove=e=>{if(!C.on)return;const dx=e.clientX-C.cxp,dy=e.clientY-C.cyp;if(Math.hypot(dx,dy)>18){C.drag=true;C.dx=dx;C.dy=dy}else C.drag=false};
 bk.onpointerup=bk.onpointercancel=()=>{chargeRelease();C.drag=false}}
addEventListener('keyup',e=>{if(e.key==' ')chargeRelease()});
const drawA=draw;
draw=function(){drawA();const g=G;if(!g||g.end||g.pause>0||!g.kp)return;const p=human(),b=g.b;if(b.o!==p&&!C.on)return;
 const a=aimDir(p),ch=chg(),len=70+110*ch,x0=b.o===p?b.x:p.x,y0=b.o===p?b.y:p.y;
 cx.save();cx.setLineDash([8,7]);cx.lineWidth=3;cx.strokeStyle=ch>.85?'#ffd21f':'#2fd0ff';cx.globalAlpha=C.on?1:.5;
 cx.beginPath();cx.moveTo(x0,y0);cx.lineTo(x0+a.x*len,y0+a.y*len);cx.stroke();cx.setLineDash([]);
 const tx2=x0+a.x*len,ty2=y0+a.y*len,an=Math.atan2(a.y,a.x);cx.fillStyle=cx.strokeStyle;cx.beginPath();cx.moveTo(tx2+Math.cos(an)*10,ty2+Math.sin(an)*10);cx.lineTo(tx2+Math.cos(an+2.5)*9,ty2+Math.sin(an+2.5)*9);cx.lineTo(tx2+Math.cos(an-2.5)*9,ty2+Math.sin(an-2.5)*9);cx.fill();
 if(C.on){cx.globalAlpha=1;cx.fillStyle='rgba(0,0,0,.6)';cx.fillRect(p.x-24,p.y+28,48,6);cx.fillStyle=ch>.85?'#ffd21f':'#2fd0ff';cx.fillRect(p.x-23,p.y+29,46*ch,4)}
 cx.restore()};

menu=function(){lobby()};
menu();
