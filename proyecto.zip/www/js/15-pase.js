/* ===== Pase de Temporada: niveles con XP, pista gratis + pista premium (se compra con gemas) ===== */
(()=>{
const LV=25,PRICE=60,need=l=>100+10*(l-1);
S.bp=S.bp||{xp:0,f:[],p:[],prem:0,seen:1};save();
const lvl=()=>{let x=S.bp.xp,l=1;while(l<LV&&x>=need(l)){x-=need(l);l++}return l};
const prog=()=>{let x=S.bp.xp,l=1;while(l<LV&&x>=need(l)){x-=need(l);l++}return l>=LV?[1,1]:[x,need(l)]};
const rw=(l,p)=>{if(!p){if(l==LV)return['gems',6];if(l%5==0)return['gems',3];if(l%2==0)return['giros',1];return['coins',60+8*l]}
 if(l==LV)return['slot',1];if(l%5==0)return['gems',5];if(l%3==0)return['suerte',1];if(l%2==0)return['giros',2];return['coins',120+12*l]};
const IC={coins:'coin',gems:'gem',giros:'ball',suerte:'bolt',slot:'gift'};
const tx=([t,n])=>t=='slot'?'Slot extra':t=='giros'?n+(n>1?' giros':' giro'):t=='suerte'?'+'+n+' suerte':n+(t=='gems'?' gemas':' monedas');
const give=([t,n])=>{if(t=='coins')S.coins+=n;else if(t=='gems')S.gems=(S.gems||0)+n;else if(t=='giros')S.freeRoll=(S.freeRoll||0)+n;else if(t=='suerte')S.ls=(S.ls||0)+n;else if(t=='slot')S.slots=(S.slots||1)+1};
const pending=()=>{const l=lvl();for(let i=1;i<=l;i++){if(!S.bp.f.includes(i))return true;if(S.bp.prem&&!S.bp.p.includes(i))return true}return false};
const st=document.createElement('style');st.textContent='.bp{display:flex;flex-direction:column;gap:6px;text-align:center}.bp h3{margin:0;font-size:22px}.bp .pbar{height:18px;border:3px solid var(--gr);border-radius:9px 12px 8px 11px;overflow:hidden;background:var(--pap2)}.bp .pbar i{display:block;height:100%;background:#d9433a url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'8\' height=\'8\'><path d=\'M-1 9L9 -1M-1 5L5 -1\' stroke=\'%23f7d6cf\' stroke-width=\'1.4\'/></svg>\")}.bp .rw{display:grid;grid-template-columns:42px 1fr 1fr;gap:6px;align-items:center}.bp .nv{font-weight:900;border:3px solid var(--gr);border-radius:52% 46% 55% 44%;padding:4px 0;background:var(--pap2)}.bp .nv.on{background:var(--yel)}.bp .c{border:2.5px solid var(--gr);border-radius:12px 8px 14px 9px;padding:5px 3px;font-size:13px;min-height:44px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;background:var(--pap2)}.bp .c.ok{background:#fff3c8}.bp .c.dn{opacity:.5}.bp .c.lk{opacity:.55}.bp .c button{padding:2px 10px;font-size:13px}.bp .hd{display:grid;grid-template-columns:42px 1fr 1fr;gap:6px;font-weight:900}.bpd{position:absolute;top:1px;right:1px;width:11px;height:11px;border-radius:50% 46% 52% 48%;background:#e8233b;border:2px solid #050505;display:none}';document.head.appendChild(st);
const dot=document.createElement('i');dot.className='bpd';
const upd=()=>{dot.style.display=pending()?'block':'none'};
function open(){const d=document.createElement('div');d.className='sr-box';d.style.cssText='position:fixed;inset:0;z-index:25;background:rgba(5,8,20,.92);display:flex;align-items:center;justify-content:center';
 const w=document.createElement('div');w.style.cssText='background:var(--card);color:var(--fg);border-radius:16px;padding:12px;width:min(460px,95vw);max-height:92vh;overflow:auto;touch-action:pan-y';d.appendChild(w);document.body.appendChild(d);
 const draw=()=>{const sc=w.scrollTop,l=lvl(),[x,n]=prog(),maxed=l>=LV;let h='<div class="bp"><h3>'+ico('trophy')+' Pase de Temporada</h3><b>Nivel '+l+(maxed?' · máximo':'')+'</b><div class="pbar"><i style="width:'+(maxed?100:Math.round(100*x/n))+'%"></i></div><small>'+(maxed?'Completaste el pase':x+' / '+n+' XP')+' · gol +10 · partido +15 · victoria +40 · campeón +60</small>';
  if(!S.bp.prem)h+='<button class="r" data-a="prem">Desbloquear Premium: '+PRICE+' '+ico('gem')+'</button>';
  h+='<div class="hd"><span></span><span>Gratis</span><span>Premium</span></div>';
  for(let i=1;i<=LV;i++){const cell=(p)=>{const r=rw(i,p),done=(p?S.bp.p:S.bp.f).includes(i),lk=i>l||(p&&!S.bp.prem);
    const lab=ico(IC[r[0]])+' '+tx(r);
    if(done)return'<div class="c dn">'+lab+'<span>'+ico('check')+' Listo</span></div>';
    if(lk)return'<div class="c lk">'+lab+'<span>'+(p&&!S.bp.prem?ico('lock'):'')+(i>l?' Nv '+i:'')+'</span></div>';
    return'<div class="c ok">'+lab+'<button class="r" data-a="cl" data-l="'+i+'" data-p="'+(p?1:0)+'">Reclamar</button></div>'};
   h+='<div class="rw"><div class="nv'+(i==l?' on':'')+'">'+i+'</div>'+cell(0)+cell(1)+'</div>'}
  h+='<button data-a="x" class="g" style="margin-top:6px">Cerrar</button></div>';w.innerHTML=h;w.scrollTop=sc};
 w.onclick=e=>{const b=e.target.closest('button');if(!b)return;const a=b.dataset.a;
  if(a=='x'){d.remove();return}
  if(a=='prem'){if((S.gems||0)<PRICE){b.textContent='Te faltan gemas ('+PRICE+')';return}S.gems-=PRICE;S.bp.prem=1;save();upd();draw();return}
  if(a=='cl'){const i=+b.dataset.l,p=+b.dataset.p,arr=p?S.bp.p:S.bp.f;if(i>lvl()||arr.includes(i)||(p&&!S.bp.prem))return;give(rw(i,p));arr.push(i);save();upd();draw()}};
 draw()}
const b=document.createElement('button');b.className='lu';b.innerHTML=ico('trophy');b.title='Pase de temporada';b.style.cssText='position:absolute;top:8px;right:180px;padding:6px 10px;font-size:15px;background:rgba(0,0,0,.45);z-index:5';b.appendChild(dot);b.onclick=open;document.getElementById('game').appendChild(b);upd();
window.bpAdd=n=>{S.bp.xp+=n;save();upd()};
const g1=goal;goal=function(t){if(t==0&&G&&!G.end){G.bpx=(G.bpx||0)+10;bpAdd(10)}return g1.apply(this,arguments)};
const f1=finish;finish=function(){const g=G,was=g&&g.end;const r=f1.apply(this,arguments);
 if(g&&g.end&&!was){let n=15;if(g.sc[0]>g.sc[1]){n+=40;if(/Final/.test(g.label||''))n+=60}bpAdd(n);const tot=n+(g.bpx||0),l=lvl();let t=' · +'+tot+' XP';if(l>(S.bp.seen||1)){t+=' · ¡Nivel '+l+'!';S.bp.seen=l;save()}const o=$('op');if(o)o.innerHTML+=t}return r};
})();
