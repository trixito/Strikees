// TEST=tests/pedir.test.js node tests/harness.js www
const assert=require('assert');let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};const get=e=>run(e);
get("localStorage.setItem('sr_tut','1');S.name='T';S.style={n:'Isagi',r:1,ab:'dash'};size=3;start(.9,'T')");
for(let i=0;i<100;i++)get('upd(.016)');
get("(()=>{const g=G,h=human(),m=g.ps.find(q=>q.t==0&&!q.h);globalThis.__m=m;m.x=300;m.y=225;h.x=420;h.y=140;for(const q of g.ps)if(q.t==1){q.x=700;q.y=40}g.b.o=m;g.b.x=m.x;g.b.y=m.y;g.b.vx=g.b.vy=0;m.kc=0})()");
ok(get('pass(1)')===true,'pedir pase con compañero con balón');
let got=false;for(let i=0;i<120&&!got;i++){get('upd(.016)');got=get('G.b.o===human()||Math.hypot(G.b.vx,G.b.vy)>200')}
ok(got,'el compañero pasa tras la petición');
get("G.b.o=G.ps.find(q=>q.t==1);");ok(get('pass(1)')===false,'sin compañero con balón no hace nada');
console.log('pedir: '+n+' OK');
