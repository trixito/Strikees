// Los personajes de la IA ya no son siempre los mismos (antes el rival 1v1 era siempre Nagi).
const assert=require('assert');const g=e=>run(e);
const cnt={},N=600;let dup=0,mine=0,xmas=0;
for(let k=0;k<N;k++){
  g(`S.name='T';S.style={n:'Isagi',r:1,ab:'shot'};size=${1+k%3};start(.9,'Test')`);
  g('G.pause=0;G.cin=0');const r=g('G.ps.filter(p=>!p.h).map(p=>{try{aiCastSkill(p,0)}catch(e){}return [p.t,p._chr]})');
  const seen={};
  for(const [t,c] of r){ if(t===1)cnt[c]=(cnt[c]||0)+1; if(c==='Isagi')mine++; if(c==='Shidou Repartidor')xmas++; if(seen[t+c])dup++; seen[t+c]=1 }
}
const tot=Object.values(cnt).reduce((a,b)=>a+b,0);
console.log('rivales:',Object.entries(cnt).map(([k,v])=>k+' '+Math.round(100*v/tot)+'%').join(', '));
assert.strictEqual(mine,0,'nadie repite tu personaje');
assert.strictEqual(xmas,0,'sin el exclusivo del evento');
assert.strictEqual(dup,0,'sin repetidos dentro de un equipo');
assert.ok(Object.keys(cnt).length>=4,'hay variedad');
assert.ok(Math.max(...Object.values(cnt))/tot<.3,'ninguno domina');
assert.strictEqual(errors.length,0,errors.join(';'));
