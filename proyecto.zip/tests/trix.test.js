// node: TEST=tests/trix.test.js node tests/harness.js www
const assert=require('assert');const get=e=>run(e);let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};
get("localStorage.setItem('sr_tut','1')");
ok(get("ST.some(s=>s[0]==='Trix'&&s[1]===7)"),'Trix en la lista de estilos');
ok(get("typeof HF.Trix.front==='function'&&typeof HF.Trix.back==='function'"),'peinado');
ok(get("rollP.toString().includes('trixPick')&&rollP.toString().includes('trixBanner')"),'parches del Roll aplicados');
ok(get("Date.now()<TRIX_END"),'evento abierto en la fecha del arnés');
ok(get("(()=>{const r=Math.random;Math.random=()=>0.001;const v=trixPick(2);Math.random=()=>0.9;const w=trixPick(2);Math.random=r;return v===7&&w===2})()"),'2% por giro');
ok(get("sk({n:'Trix'}).join()")==='trixzig,ultrakill,trixdragon','habilidades base');
const setup=()=>get("S.diff=1;S.name='T';S.style={n:'Trix',r:7,ab:'shot'};tour=null;start(1,'t');G.pause=0;G.cin=null;G.aw=0;G.skcd=[0,0,0];var H0=human();H0.fall=0;");
const frames=k=>get(`for(let i=0;i<${k};i++){upd(0.016);draw()}`);

// Dribble del Manipulador: aturde al rival que se cruza
setup();get("G.b.o=H0;H0.x=300;H0.y=225;H0.fx=1;H0.fy=0;var Q=G.ps.find(q=>q.t==1&&!q.h);Q.x=330;Q.y=225;Q.stun=0");
get("useSk(0)");ok(get("G.tz>0&&G.skcd[0]>0"),'zig-zag activo con cooldown');
frames(30);ok(get("Q.stun>0||Q._tf>0"),'el rival se aturde de miedo');
setup();get("G.b.o=null;useSk(0)");ok(get("!(G.tz>0)&&G.skcd[0]==0"),'sin balón no se lanza');

// UltraKill
setup();get("G.b.o=null;G.b.x=200;G.b.y=225;G.b.vx=-600;G.b.vy=0;H0.x=500;H0.y=300;useSk(1)");
ok(get("G.b.vx>0&&!G.b.o&&G.skcd[1]>0"),'salva el balón con una volea (bote suelto)');
ok(get("Math.hypot(G.b.vx,G.b.vy)<=460"),'el rebote queda flojo');
setup();get("G.b.o=null;G.b.x=600;G.b.y=225;G.b.vx=0;G.b.vy=0;useSk(1)");ok(get("G.uk>0"),'queda en guardia');
get("G.b.x=250;G.b.y=225;G.b.vx=-700;G.b.vy=0");frames(1);ok(get("G.b.vx>0"),'la guardia reacciona sola');

// Despertar
setup();get("G.aw=15;G.awm=0");frames(2);ok(get("G._tx==1&&G.skcd[2]==0"),'el despertar libera las 3 habilidades');
ok(get("sk(S.style).join()")==='trixportal,trixaura,trixdragon','slots del despertar');
get("H0.x=300;H0.y=225;H0.fx=1;H0.fy=0;useSk(0)");ok(get("!!G.portals&&G.portals.uses==3"),'portal abierto');
get("H0.x=G.portals.a.x;H0.y=G.portals.a.y");frames(1);ok(get("Math.hypot(H0.x-G.portals.b.x,H0.y-G.portals.b.y)<60&&G.portals.uses==2"),'se teletransporta (límite 3)');
setup();get("G.aw=15");frames(2);get("G.b.o=null;var Q2=G.ps.find(q=>q.t==1&&!q.h);H0.x=300;H0.y=225;Q2.x=360;Q2.y=225;G.b.o=Q2;useSk(1)");
ok(get("G.aura>0"),'aura activa');frames(2);ok(get("G.b.o===H0"),'el rival entrega el balón por miedo');

// Disparo del Dragón: ganar = gol seguro
setup();get("G.aw=15");frames(2);get("G.b.o=H0;G.skcd[2]=0;useSk(2)");ok(get("!!G.dg"),'duelo 1v1 iniciado');
get("for(let i=0;i<40;i++)useSk(2)");frames(80);ok(get("G.sc[0]===1&&G.pause>0&&!G.dg"),'ganar el duelo es gol seguro');
// perder = atajado
setup();get("G.aw=15");frames(2);get("S.diff=3;G._diffIdx=3;G.b.o=H0;G.skcd[2]=0;useSk(2)");get("for(let i=0;i<300&&G.dg;i++){upd(0.016);draw()}");
ok(get("G.sc[0]===0&&!G.dg&&!G.b.o&&G.b.vx<0"),'perder el duelo: el portero ataja y el balón queda suelto');
ok(get("G.skcd[2]>50"),'solo una vez por despertar');
// otros estilos no se ven afectados
get("S.style={n:'Isagi',r:1,ab:'dash'};tour=null;start(1,'t');G.pause=0;G.cin=null");frames(60);
assert.strictEqual(errors.length,0,errors.join(';'));
console.log('trix: '+n+' comprobaciones OK');
