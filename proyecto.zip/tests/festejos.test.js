// TEST=tests/festejos.test.js node tests/harness.js www
const assert=require('assert');let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};const get=e=>run(e);
get("localStorage.setItem('sr_tut','1');S.name='T';S.style={n:'Isagi',r:1,ab:'dash'}");
for(const id of ['clasico','fuego','rayo','s67','ayano']){
 get(`S.cel='${id}';size=3;start(.9,'Test');for(let i=0;i<100;i++)upd(.016);goal(0)`);
 ok(get('G.cel&&G.cel.id')===id,'goal dispara '+id);
 for(let i=0;i<20;i++)get('upd(.016);draw()');get('G.cel.t0-=3000');get('draw()');
 ok(get('!G.cel'),id+' termina');}
get('goal(1)');ok(get('!G.cel'),'gol rival sin festejo');
get('celP()');get('lobDraw');ok(get("STN.some(s=>s.id==='cel')"),'estación Festejos');
console.log('festejos: '+n+' OK');
