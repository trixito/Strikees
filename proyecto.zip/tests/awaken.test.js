// TEST=tests/awaken.test.js node tests/harness.js www
const assert=require('assert');const get=e=>run(e);let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};
get("localStorage.setItem('sr_tut','1')");
ok(errors.length===0,'carga sin errores: '+errors.join(' | '));
const setup=(sty,r)=>get(`S.diff=1;S.name='T';S.style={n:'${sty}',r:${r||3},ab:'dash'};size=2;start(1,'t');G.pause=0;G.cin=null;G.skcd=[0,0,0];var H0=human();H0.fall=0;`);
const frames=k=>get(`for(let i=0;i<${k};i++){upd(0.016);draw()}`);
// perfiles
ok(get("awProfile('Isagi').t==='METAVISIÓN'&&awProfile('Trix').h==='MULTIVERSO'&&awProfile('Novato Veloz').t==='DESPERTAR'&&awProfile().t==='DESPERTAR'"),'perfiles por personaje y por defecto');
ok(get("['Isagi','Bachira','Nagi','Shidou','Kaiser','Loki','Shidou Repartidor','Trix'].every(n=>{const p=awProfile(n);return p.t&&p.h&&p.s&&/^#[0-9a-f]{6}$/i.test(p.c)&&/^#[0-9a-f]{6}$/i.test(p.c2)})"),'colores válidos (hex de 6 dígitos)');
// sin barra llena no hay despertar; con barra llena empieza la cinemática y congela el partido
setup('Isagi',1);get("G.awm=50;awakeOn()");ok(get("!G.cin&&G.aw===0"),'sin la barra llena no despierta');
get("G.awm=100;G.b.o=null;G.b.vx=300;awakeOn()");
ok(get("G.cin&&G.cin.k==='awaken'&&G.cin.n==='METAVISIÓN'&&G.awm===0&&G.aw===0"),'cinemática de despertar: barra a 0 y aún sin buff');
get("var P0=G.ps.map(p=>[p.x,p.y]).join(),B0=G.b.x");frames(60);
ok(get("G.ps.map(p=>[p.x,p.y]).join()===P0&&G.b.x===B0"),'el partido está congelado durante la cinemática');
get("awakeOn()");ok(get("G.cin.k==='awaken'"),'no se puede reiniciar durante la cinemática');
frames(100);
ok(get("!G.cin&&G.aw>12&&G.aw<=15&&G.awd===15&&!!G.flash"),'al terminar la cinemática empieza el despertar con destello');
ok(get("G.fxs.some(f=>/METAVISI/.test(f.s))"),'aviso flotante del despertar');
// aura, viñeta y HUD sin errores; el gol alarga el despertar
frames(30);get("var A0=G.aw;goal(0)");ok(get("G.aw>A0+2"),'un gol suma 3 s al despertar');
get("G.pause=0;G.end=false;G.aw=2;");frames(5);
// fin del despertar
get("G.aw=.01");frames(3);ok(get("G.aw===0&&G._aw===0"),'termina el despertar');
// todos los estilos: cinemática de despertar, aura y aura de la IA sin lanzar errores
const names=get("ST.map(s=>s[0]).concat(['Trix'])");
for(const nm of names){setup(nm,3);get("G.awm=100;awakeOn()");frames(140);get("G.aw=8;var Q=G.ps.find(q=>!q.h);Q._chr=null;Q._aw=6");frames(20);}
ok(true,'cinemática+aura en '+names.length+' estilos');
// cut-in de habilidad de despertar (Bachira: Monster Trance) y reglas de bloqueo
setup('Bachira',2);get("G.aw=15");frames(3);get("G.skcd[2]=0;useSk(2)");
ok(get("G.cin&&G.cin.k==='skill'&&G.cin.n==='MONSTER TRANCE'&&G.skcd[2]>0&&!(G.trance>0)"),'Monster Trance abre cut-in y aún no activa');
frames(70);ok(get("!G.cin&&G.trance>0"),'al terminar el cut-in empieza el trance');
for(const [nm,sk] of [['Isagi',2],['Nagi',2],['Shidou',2],['Kaiser',2],['Shidou Repartidor',2]]){setup(nm,4);get("G.aw=15");frames(3);get(`G.b.o=human();G.skcd[2]=0;useSk(2)`);ok(get("G.cin&&G.cin.k==='skill'"),nm+': cut-in de despertar');frames(90);ok(get("!G.cin"),nm+': el cut-in termina');}
// IA: despertar con aviso, aura y sin congelar
setup('Isagi',1);get("var R=G.ps.find(q=>q.t===1&&!q.h);R._aw=0;aiAwakenFx(G,R);R._aw=6");
ok(get("!G.cin&&G.fxs.some(f=>/¡/.test(f.s))&&G._sfx&&G._sfx.length>0&&!!R._chr"),'IA: aviso + efecto, elige personaje y no congela');frames(30);
// el temblor termina solo y el lobby deja el canvas centrado (el canvas falso no guarda estilos: se revisa el código)
get("var _pn=performance.now;G.shk={t0:_pn(),d:200,m:6};draw();var T1=!!G.shk;performance.now=()=>_pn()+1000;draw();performance.now=_pn");
ok(get("T1&&!G.shk"),'el temblor expira');
ok(get("lobby.toString().includes(\"cv.style.transform=''\")&&lobby.toString().includes(\"classList.remove('cine')\")"),'lobby limpia el temblor y oculta la clase de cinemática');
console.log('awaken: '+n+' comprobaciones OK');
