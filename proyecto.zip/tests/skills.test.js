// Rework de robo: ya no es automático, depende de posición/ángulo, respeta escudos y el balón suelto se disputa.
const assert=require('assert');const g=e=>run(e);
const setup=sty=>g(`S.name='T';S.style={n:'${sty}',r:3,ab:'shot'};size=2;start(.9,'Test');G.pause=0;G.cin=0;G.skcd=[0,0,0];joy.x=1;joy.y=0;`);
const N=600;
const trial=(body,cast,res)=>g(`(()=>{let ok=0;const h=human(),r=G.ps.find(p=>p.t===1),m=G.ps.find(p=>p.t===0&&p!==h);
 G.ps.forEach(p=>{if(p!==h&&p!==r&&p!==m){p.x=30;p.y=30}});m.x=40;m.y=420;
 for(let k=0;k<${N};k++){h.x=400;h.y=300;h.fall=0;h.stun=0;h.dr=0;h.sl=0;h.shU=0;h.fx=1;h.fy=0;
  r.x=460;r.y=300;r.fx=1;r.fy=0;r.fall=0;r.stun=0;r.dr=0;r.shU=0;r.sl=0;r._skcd=[0,0,0];r._chr=undefined;
  G.skcd=[0,0,0];G.cin=0;G.b.vx=0;G.b.vy=0;G.aw=0;
  ${body}
  ${cast}
  if(${res})ok++}
 return ok/${N}})()`);
let r;
// --- Steal (Bachira): de espaldas / de frente / protegido
setup('Bachira');
const holder=f=>`G.b.o=r;G.b.x=r.x;G.b.y=r.y;r.fx=${f};`;
const back=trial(holder(1),'useSk(0);','G.b.o===h');           // el poseedor mira hacia otro lado
const front=trial(holder(-1),'useSk(0);','G.b.o===h');          // el poseedor te mira de frente
console.log('steal humano: por la espalda '+back+' · de frente '+front);
assert.ok(back>.65&&back<.95,'por la espalda casi siempre pero no siempre');
assert.ok(front>.25&&front<.55,'de frente cuesta bastante');
assert.ok(back>front+.2,'el ángulo importa');
const blocked=trial(holder(1)+'r.shU=performance.now()+3000;','useSk(0);','G.b.o===h');
assert.strictEqual(blocked,0,'el Muro bloquea el robo');
assert.ok(g('human().fall')>0,'y te hace tropezar');
const dashing=trial(holder(1)+'r.dr=.4;','useSk(0);','G.b.o===h');assert.strictEqual(dashing,0,'la Ráfaga también');
// IA robando al humano
const ai=trial('G.b.o=h;G.b.x=h.x;G.b.y=h.y;r.x=340;r.y=300;h.fx=1;r._chr="Bachira";','aiCastSkill(r,0);','G.b.o===r');
console.log('steal IA: '+ai);assert.ok(ai>.25&&ai<.95,'la IA tampoco roba siempre');
// --- Nutmeg contra protegido
const nut=body=>g(`(()=>{const h=human(),r=G.ps.find(p=>p.t===1);G.ps.forEach(p=>{if(p!==h&&p!==r){p.x=30;p.y=30}});
 h.x=400;h.y=300;h.fall=0;h.stun=0;r.x=470;r.y=300;r.fall=0;r.dr=0;r.shU=0;G.skcd=[0,0,0];G.b.o=null;${body}useSk(1);return [r.fall,h.fall]})()`);
r=nut('');assert.ok(r[0]>0&&r[1]===0,'nutmeg derriba al rival');
r=nut('r.shU=performance.now()+3000;');assert.ok(r[0]===0&&r[1]>0,'nutmeg no atraviesa el Muro');

// --- Trap (Nagi): balón suelto
setup('Nagi');
const loose=(vx,rx)=>`G.b.o=null;G.b.x=500;G.b.y=300;G.b.vx=${vx};G.b.vy=0;r.x=${rx};r.y=300;`;
const slow=trial(loose(0,1000),'useSk(0);','G.b.o===h'),fast=trial(loose(900,1000),'useSk(0);','G.b.o===h');
console.log('trap: balón lento '+slow+' · balón rápido '+fast);
assert.ok(slow>.88&&slow<1,'balón lento: casi seguro');assert.ok(fast>.25&&fast<.5,'balón rápido: difícil');
const lost=trial(loose(0,510),'useSk(0);','G.b.o===h');assert.strictEqual(lost,0,'si el rival está más cerca del balón, lo pierdes');
// --- Finta: mueve al portero que ATACA el equipo (antes siempre el derecho)
const keeper=who=>g(`(()=>{const h=human(),r=G.ps.find(p=>p.t===1);G.kp[0].y=G.kp[1].y=H/2;h.fall=0;r.fall=0;G.skcd=[0,0,0];r._skcd=[0,0,0];r._chr='Nagi';
 ${who==='h'?'useSk(1)':'aiCastSkill(r,1)'};return [G.kp[0].y!==H/2,G.kp[1].y!==H/2]})()`);
assert.deepStrictEqual(keeper('h'),[false,true],'humano mueve al portero rival (derecha)');
assert.deepStrictEqual(keeper('ai'),[true,false],'la IA mueve al portero del humano (izquierda)');

// --- Route (Kaiser): roba a rivales, no a compañeros
setup('Kaiser');
const route=trial('G.b.o=r;G.b.x=r.x;G.b.y=r.y;r.x=520;r.fx=-1;','useSk(2);','G.b.o===h');
console.log('route: '+route);assert.ok(route>.35&&route<.8,'Subyugación a un rival: a veces');
const mate=trial('const mm=G.ps.find(p=>p.t===0&&p!==h);mm.x=480;mm.y=300;G.b.o=mm;G.b.x=mm.x;G.b.y=mm.y;','useSk(2);','G.b.o===h');
assert.strictEqual(mate,0,'ya no roba a tus propios compañeros');
assert.strictEqual(errors.length,0,errors.join(';'));
console.log('skills: OK');
