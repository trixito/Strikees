// TEST=tests/flows.test.js node tests/harness.js www
const assert=require('assert');const get=e=>run(e);let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};
get("localStorage.setItem('sr_tut','1')");
ok(get("window.SRFlows&&SRFlows.FL.length===10"),'10 flows');
ok(get("STN.some(s=>s.id==='flow')&&STN.length===7"),'estación Flows en el mapa');
// primer giro gratis, luego cuesta monedas; repetido devuelve monedas
get("S.coins=100;S.flowOwn=[];S.flow=null;S.flowFreeUsed=0;var r1=SRFlows.spin()");
ok(get("r1.ok&&S.flowFreeUsed===1&&S.coins===100&&S.flowOwn.length===1&&S.flow===S.flowOwn[0]"),'primer giro gratis y se equipa solo');
get("var r2=SRFlows.spin()");ok(get("r2.ok&&S.coins<=100-SRFlows.cost+60"),'el segundo giro cuesta monedas');
get("S.coins=0;var r3=SRFlows.spin()");ok(get("!r3.ok"),'sin monedas no gira');
get("S.coins=0;S.flowOwn=['Pulso Firme'];var r4=SRFlows.give('Pulso Firme')");ok(get("r4.dup&&S.coins===10"),'repetido da monedas');
ok(get("!SRFlows.give('No existe').ok"),'flow inexistente');
const setup=f=>get(`S.diff=1;S.name='T';S.style={n:'Isagi',r:1,ab:'dash'};S.flowOwn=['${f}'];S.flow='${f}';start(1,'t');G.pause=0;G.cin=null;var H0=human();H0.fall=0;`);
const frames=k=>get(`for(let i=0;i<${k};i++){upd(0.016);draw()}`);
// duración extra
setup('Pulso Firme');get("G.flow=100;flowOn()");frames(2);ok(get("G.fl>14.5"),'Pulso Firme: +4 s');
setup('Rey del Campo');get("G.flow=100;flowOn()");frames(2);ok(get("G.fl>17.5"),'Rey del Campo: +6 s');
// sin Flow equipado no cambia nada
get("S.flow=null;S.style={n:'Isagi',r:1,ab:'dash'};start(1,'t');G.pause=0;G.cin=null;G.flow=100;flowOn()");frames(2);ok(get("G.fl<=12"),'sin Flow equipado: 12 s normales');
// stamina infinita
setup('Segundo Aire');get("G.flow=100;flowOn();G.st=10");frames(2);ok(get("G.st>=100"),'Segundo Aire: stamina llena');
// gol carga despertar
setup('Hambre de Gol');get("G.flow=100;flowOn()");frames(2);get("G.awm=0;goal(0)");ok(get("G.awm>=90"),'Hambre de Gol: el gol carga el despertar de más');
setup('Hambre de Gol');get("G.awm=0;goal(0)");ok(get("G.awm<60"),'sin Flow activo: carga normal');
// tiro más fuerte (el tiro sale al soltar Kick)
const kick=()=>{get("G.b.o=H0;H0.x=300;H0.y=225;H0.fx=1;H0.fy=0;chargeStart();chargeRelease()");return get("Math.hypot(G.b.vx,G.b.vy)")};
setup('Ojo de Halcón');const pw0=kick();
setup('Ojo de Halcón');get("G.flow=100;flowOn()");frames(1);const pw1=kick();
ok(pw0>0&&pw1>pw0*1.3,'Ojo de Halcón: el tiro sale con más fuerza ('+Math.round(pw0)+' → '+Math.round(pw1)+')');
setup('Pulso Firme');get("G.flow=100;flowOn()");frames(1);const pw2=kick();ok(Math.abs(pw2-pw0*1.2)<pw0*.05,'otros Flows no tocan la fuerza del tiro');
// metavisión: rival cercano más lento
setup('Metavisión');get("G.flow=100;flowOn();var Q=G.ps.find(q=>q.t==1&&!q.h);Q.x=H0.x+60;Q.y=H0.y");frames(5);ok(get("Q.x>=0"),'Metavisión corre sin errores');
// nombre en el botón (no rompe el HUD)
frames(3);
// canje por código
ok(get("typeof SRCodes.redeem==='function'"),'códigos');
// otros estilos y partida normal no se rompen
get("S.flow=null;S.style={n:'Isagi',r:1,ab:'dash'};start(1,'t');G.pause=0;G.cin=null");frames(120);
assert.strictEqual(errors.length,0,errors.join(';'));
console.log('flows: '+n+' comprobaciones OK');
