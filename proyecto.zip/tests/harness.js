// Prueba de humo sin navegador: carga los js en orden con DOM/canvas falsos,
// juega partidos simulados con azar fijo y devuelve una huella del estado.
const vm=require('vm'),fs=require('fs'),path=require('path');
const dir=process.argv[2]||path.join(__dirname,'../www');
let seed=12345;const rnd=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
let clock=1e5;const errors=[];
const stub=()=>{const f=function(){return stub()};return new Proxy(f,{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:k==='complete'?true:k==='naturalWidth'?32:k==='width'||k==='height'?100:k==='children'?[]:k==='dataset'?{}:k==='style'||k==='classList'?stub():(k in t?t[k]:stub()),set:(t,k,v)=>{t[k]=v;return true},apply:()=>stub()})};
const store={};if(process.env.SAVE)store.sr=process.env.SAVE;
const ctx=new Proxy({}, {get:(t,k)=>k==='measureText'?()=>({width:10}):/^create(Linear|Radial)Gradient$/.test(k)?()=>({addColorStop(){}}):k==='createPattern'?()=>({}):k==='canvas'?stub():()=>{},set:()=>true});
const els={};
const mk=id=>{const e=stub();return e};
const doc={getElementById:id=>els[id]||(els[id]=Object.assign(mk(id),{})),createElement:t=>t==='canvas'?{width:0,height:0,style:{},getContext:()=>ctx,getBoundingClientRect:()=>({left:0,top:0,width:800,height:450}),set onpointerdown(f){}}:stub(),head:stub(),body:stub(),documentElement:stub(),addEventListener(){},querySelector:()=>stub(),querySelectorAll:()=>[],fonts:{ready:Promise.resolve()}};
const FD=class extends Date{constructor(...a){a.length?super(...a):super(1.79e12)}static now(){return 1.79e12}};
const g=globalThis;
const __o={window:g,document:doc,Date:FD,innerWidth:800,innerHeight:450,devicePixelRatio:1,
 localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>delete store[k]},
 navigator:{vibrate(){}},matchMedia:()=>({matches:false}),screen:{orientation:{lock:()=>Promise.resolve()}},
 Image:class{constructor(){this.complete=true;this.naturalWidth=32}set src(v){}},
 Path2D:class{moveTo(){}lineTo(){}closePath(){}},DOMMatrix:class{scale(){return this}},
 addEventListener(){},removeEventListener(){},requestAnimationFrame:()=>1,cancelAnimationFrame(){},setTimeout:(f)=>0,setInterval:()=>0,clearInterval(){},
 AudioContext:undefined,webkitAudioContext:undefined,getComputedStyle:()=>({}),
 HTMLElement:class{},Element:class{},Node:class{}};
for(const k in __o)Object.defineProperty(g,k,{value:__o[k],configurable:true,writable:true});
Math.random=rnd;performance.now=()=>clock;
let files=fs.readdirSync(path.join(dir,'js')).filter(f=>f.endsWith('.js')).sort();
if(process.env.ONLY)files=files.filter(f=>process.env.ONLY.split(',').includes(f));
for(const f of files){try{vm.runInThisContext(fs.readFileSync(path.join(dir,'js',f),'utf8'),{filename:f})}catch(e){errors.push('LOAD '+f+': '+e.message)}}
if(process.env.DUMP){const d={};for(const n of process.env.DUMP.split(','))d[n]=vm.runInThisContext(n+'.toString()');fs.writeFileSync(process.env.DUMPFILE,JSON.stringify(d));process.exit(0)}
const trace=[];
const R=v=>Math.round(v*10)/10;
function snap(tag){const G=vm.runInThisContext('G');if(!G)return;trace.push(tag+JSON.stringify({ps:G.ps.map(p=>[R(p.x),R(p.y)]),b:[R(G.b.x),R(G.b.y)],sc:G.sc,t:R(G.time),pause:R(G.pause)}))}
const run=s=>vm.runInThisContext(s);
if(process.env.TEST){global.run=run;global.FD=FD;global.errors=errors;require(path.resolve(process.env.TEST));process.exit(process.exitCode||0)}
function play(label,setup,frames){
  try{
    run(setup);
    for(let f=0;f<frames;f++){
      clock+=16;
      const a=f*0.05;
      run(`joy.x=${Math.cos(a*1.3).toFixed(3)};joy.y=${Math.sin(a).toFixed(3)};`);
      if(f%40==10)run('try{shoot();if(typeof chargeRelease=="function")chargeRelease()}catch(e){throw e}');
      if(f%90==20)run('useSk(0)');
      if(f%130==50)run('useSk(1)');
      if(f%170==80)run('useSk(2)');
      if(f%110==30)run('dribble(human())');
      if(f%150==60)run('slide(human())');
      if(f%100==70)run('pass(1)');
      try{run('upd(0.016);draw()')}catch(e){errors.push(label+' f'+f+': '+e.message);break}
      if(f%60==0)snap(label+':'+f+':');
    }
  }catch(e){errors.push(label+' setup: '+e.message)}
}
const styles=run('ST.map(s=>s[0])');
let i=0;
for(const nm of styles.slice(0,6)){
  play('style'+(i++),`S.name='T';S.style=rollStyle();S.style={n:${JSON.stringify(nm)},r:1,ab:'dash'};size=${1+i%3};start(.9,'Test')`,1500);
}
play('ranked',`S.style={n:'Isagi',r:1,ab:'dash'};startRanked()`,1200);
play('xmas',`S.style={n:'Nagi',r:3,ab:'dash'};size=2;start(1,'Navidad');G.xm=1;G.gifts=[];G.gt=1`,800);
const out={errors,trace};
const crypto=require('crypto');
console.log(JSON.stringify({errors:errors.slice(0,12),nerr:errors.length,frames:trace.length,hash:crypto.createHash('md5').update(trace.join('|')).digest('hex')}));
if(process.argv[3])fs.writeFileSync(process.argv[3],trace.join('\n'));
