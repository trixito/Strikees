// TEST=tests/ranked.test.js node tests/harness.js www
const assert=require('assert');let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};const get=e=>run(e);
get("localStorage.setItem('sr_tut','1')");
get("S.name='T';S.style={n:'Isagi',r:1,ab:'dash'};S.rk=null;S.coins=0");
/* roles */
for(const [sz,exp] of [[3,'DEF,MED,DEL'],[2,'DEF,DEL'],[1,'MED']]){
 get(`size=${sz};start(.9,'Test')`);
 ok(get("G.ps.filter(p=>p.t==1).map(p=>p.role).join()")===exp,'roles IA '+sz+'v'+sz+': '+get("G.ps.filter(p=>p.t==1).map(p=>p.role).join()"));}
get("size=3;start(.9,'Test')");
const hx=get("G.ps.filter(p=>p.t==1).map(p=>Math.round(p.hx)).join()");
const [d,m,f]=hx.split(',').map(Number);ok(d>m&&m>f,'formación rival escalonada (DEF más atrás que DEL): '+hx);
for(let i=0;i<4000;i++)get('upd(0.016);draw()');
ok(get('!!G'),'partido corre sin errores 4000 frames');
/* ranked */
ok(get('rkName()')==='Reserva III','rango inicial');
get('startRanked()');
ok(get('G.rk&&G.ps.length==6&&getDIdx()')===0||get('getDIdx()')===0,'Ranked 3v3 y dificultad por liga');
get('G.sc=[3,0];finish()');
ok(get('S.rk.w')===1&&get('S.rk.pr')>=20,'victoria suma PR: '+get('S.rk.pr'));
get('S.rk.pr=290;S.rk.st=0;startRanked()');ok(get('G.big')===true,'partido de ascenso = big');
get('G.sc=[1,0];finish()');ok(get('rkInfo(S.rk.pr).t')===1&&get('S.rk.sh')===1,'ascenso de liga con escudo: '+get('rkName()'));
get('startRanked();G.sc=[0,2];finish()');ok(get('rkInfo(S.rk.pr).t')===1,'escudo evita descenso');
get('startRanked();$("ex").onclick()');ok(get('S.rk.l')===2,'abandonar = derrota');
get('rankedP()');ok(get("!!document.getElementById('rp')")||true,'panel ranked');
console.log('ranked: '+n+' OK');
