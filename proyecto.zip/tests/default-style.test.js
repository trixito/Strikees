// Partida nueva: estilo por defecto que no ocupa slot. Partida vieja: no cambia.
const assert=require('assert');const g=e=>run(e);
if(process.env.SAVE){
  assert.strictEqual(g('S.style.n'),'Pie de Hierro','conserva su estilo');
  assert.ok(!g('S.style.def')&&!g('S.own.some(o=>o.def)'),'no se le añade el estilo base');
  console.log('guardado viejo: OK');
}else{
  assert.strictEqual(g('S.style.n'),'Novato Veloz','estilo por defecto');
  assert.deepStrictEqual(g('({r:S.style.r,ab:S.style.ab,def:S.style.def})'),{r:0,ab:'dash',def:1});
  assert.ok(JSON.parse(localStorage.getItem('sr')).style,'queda guardado');
  assert.strictEqual(g('S.slots'),1,'1 slot libre');
  assert.strictEqual(g('addChar({n:"Cazador",r:1,ab:"magnet"})'),'¡Nuevo estilo!','el primer roll cabe en el slot');
  assert.strictEqual(g('S.style.n'),'Cazador','se equipa solo al salir del estilo base');
  assert.ok(g('S.own.some(o=>o.n==="Novato Veloz")'),'el base sigue disponible');
  assert.strictEqual(g('addChar({n:"Rayo Corto",r:1,ab:"dash"})'),'Slots llenos','el siguiente sí respeta los slots');
  console.log('partida nueva: OK');
}
assert.strictEqual(errors.length,0,errors.join(';'));
