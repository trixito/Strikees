// TEST=tests/tienda.test.js node tests/harness.js www
const assert=require('assert');
run("S.coins=1000;S.gems=100;S.cosOwn=[];for(let i=0;i<8;i++)SRShop.open('cos','coins')");
assert.strictEqual(run('S.cosOwn.length>0'),true);
assert.strictEqual(run("S.coins=0;SRShop.open('fest','coins').ok"),false);
run("S.cos={head:'corona',aura:'oro'};drawChar(100,100,.1,{me:1,dir:1,suit:SUITS[0],hair:'#fff'});SRShop.shop()");
run("S.gems=10;SRFlows.spin(true)");assert.strictEqual(run('S.gems'),0);
assert.deepStrictEqual(errors,[]);console.log('tienda OK');
