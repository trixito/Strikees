// Prioridad de aspecto: tu skin del vestidor manda; "Personaje" usa el del personaje equipado.
const assert=require('assert');const g=e=>run(e);
g(`window.__log=[];const __o=drawChar;drawChar=function(x,y,sc,o){__log.push([o.ch||null,o.hair,o.suit&&o.suit.join()]);return __o.apply(this,arguments)}`);
const mine=pc=>{g(`S.look={h:'#abcdef',s:1,pc:${pc}};S.style={n:'Nagi',r:3,ab:'shot'};size=2;start(.9,'Test');G.pause=0;G.cin=0;__log.length=0`);
 for(let i=0;i<60;i++)g('upd(.016);draw()');
 return [...new Set(g('__log').filter(l=>l[1]==='#abcdef').map(l=>l[0]))]};
assert.deepStrictEqual(mine(0),[null],'tu skin: nunca el personaje');
assert.deepStrictEqual(mine(1),['Nagi'],'Personaje: siempre el personaje');
// cambiar de estilo equipado ya no cambia tu aspecto
g(`S.look={h:'#abcdef',s:1}`);const seen=new Set();
for(const n of ['Isagi','Nagi','Novato Veloz','Bachira','Loki']){g(`S.style={n:'${n}',r:1,ab:'shot'};start(.9,'Test');G.pause=0;G.cin=0;__log.length=0`);for(let i=0;i<10;i++)g('upd(.016);draw()');g('__log').filter(l=>l[1]==='#abcdef').forEach(l=>seen.add(l[0]+'|'+l[2]))}
assert.strictEqual(seen.size,1,'mismo aspecto con cualquier estilo: '+[...seen]);
assert.strictEqual(errors.length,0,errors.join(';'));
console.log('look: OK');
