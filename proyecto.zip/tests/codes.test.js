// node: TEST=tests/codes.test.js node tests/harness.js www
const fs=require('fs'),path=require('path'),assert=require('assert');
const get=e=>run(e);
let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};
const R=t=>get(`SRCodes.redeem(${JSON.stringify(t)})`);
get('S.coins=0;S.gems=0;S.freeRoll=0;S.codes=[]');

ok(!R('').ok&&R('').msg==='Escribe un código','vacío');
ok(R('XXXX').msg==='Código no válido','inválido');

let r=R(' navidad-26 ');                        // minúsculas, espacios y guiones
ok(r.ok&&get('S.coins')===300&&get('S.gems')===5,'canje NAVIDAD26: '+r.msg);
r=R('NAVIDAD26');ok(!r.ok&&r.msg==='Ya canjeaste este código'&&get('S.coins')===300,'no se repite');
r=R('prototipo');ok(r.ok&&get('S.freeRoll')===3&&get('S.coins')===450,'PROTOTIPO');
ok(JSON.parse(localStorage.getItem('sr')).codes.length===2,'se guarda en el guardado');

// caducidad: el último día aún vale; el siguiente ya no
get('S.codes=[]');const now=FD.now;
FD.now=()=>new Date(2027,0,7,23,30).getTime();ok(R('NAVIDAD26').ok,'último día vale');
get('S.codes=[]');FD.now=()=>new Date(2027,0,8,0,5).getTime();r=R('NAVIDAD26');
ok(!r.ok&&r.msg==='Este código ya caducó','caduca al día siguiente');FD.now=now;

// recompensa de estilo (nuevo, y repetido => monedas), con una copia que activa dos ejemplos
let src=fs.readFileSync(path.join(process.argv[2],'js/14-codes.js'),'utf8');
src=src.replace("// EJEMPLO:{style:'Cazador'},","EJEMPLO:{style:'Cazador'},EJEMPLO2:{style:'Cazador'},");
require('vm').runInThisContext(src,{filename:'14-codes(test)'});
get('S.codes=[];S.own=[];S.slots=3;S.coins=0');
r=R('ejemplo');ok(r.ok&&get("S.own.some(o=>o.n==='Cazador')")&&/Nuevo estilo/.test(r.msg),'estilo nuevo: '+r.msg);
r=R('ejemplo2');ok(r.ok&&get('S.coins')===20&&/repetido/.test(r.msg),'estilo repetido da monedas: '+r.msg);

get('SRCodes.open()');                          // la pantalla se construye sin errores
ok(errors.length===0,'sin errores de carga: '+errors.join(';'));
console.log('codes: '+n+' comprobaciones OK');
