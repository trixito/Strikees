// node: TEST=tests/ai-skills.test.js node tests/harness.js www
const assert=require('assert');
const get=e=>run(e);
get("localStorage.setItem('sr_tut','1')");
let n=0;const ok=(c,m)=>{assert.ok(c,m);n++};
get("S.diff=3;S.style=S.style||{n:'Isagi',r:1,ab:'shot'};start(1,'t')");
get("G._aiN=0;var P=G.ps.find(q=>q.t==1&&!q.h);P._chr='Isagi';P.role='DEL';P._aw=0;G.b.o=P;P.x=120;P.y=225;P.fall=0;");
// Isagi: direct (pesada, con balón cerca de la portería) → debe avisar y luego ejecutarse
get("for(let k=0;k<400&&!P._pend;k++){G._aiN=0;aiAbilities(P,G,G.b,G.ps.filter(q=>q.t==0),.016,3,1.75)}");
ok(get("!!P._pend"),'aviso previo de habilidad pesada');
ok(get("G.fxs.some(f=>/⚠/.test(f.s))"),'texto de aviso');
// si la barren durante el aviso se interrumpe
get("P.fall=1");get("aiTickExtra(P,G,.016)");
ok(get("!P._pend"),'se interrumpe al caer');
// sin balón no lanza habilidades que lo necesitan
get("P.fall=0;G.b.o=null;P._skcd=[0,0,0]");
ok(get("window.aiCastSkill(P,0,1)")===false,'sin balón no hay Direct Shot');
// el despertar no ocurre al empezar el partido
get("G.sc=[0,0];G.time=60;P._aw=0;G._aiN=0;for(let k=0;k<2000;k++)aiAbilities(P,G,G.b,G.ps.filter(q=>q.t==0),.016,3,1.75)");
ok(get("(P._aw||0)===0"),'sin despertar a los 60 s sin goles');
console.log('ai-skills: '+n+' comprobaciones OK');
// portero: entrar con el balón pegado a la portería rival ya no es gol
get("S.diff=1;start(1,'t');G.pause=0;G.cin=null;var H0=human();H0.t=0;G.b.o=H0;H0.x=W-22;H0.y=H/2;H0.fx=1;H0.fy=0;H0.dr=0;H0.fall=0;G.kp[1].y=H/2;G.kp[1].cd=0;");
get("upd(.016)");
ok(get("G.sc[0]")===0,'no hay gol caminando con el balón');
ok(get("G.b.o")===null,'el portero roba el balón');
ok(get("G.fxs.some(f=>/portero/.test(f.s))"),'aviso del portero');
// con un regate en el momento justo sí puede pasar
get("start(1,'t');G.pause=0;G.cin=null;var H1=human();H1.t=0;G.b.o=H1;H1.x=W-22;H1.y=H/2;H1.fx=1;H1.fy=0;H1.dr=.3;H1.fall=0;G.kp[1].cd=0;");
get("upd(.016)");
ok(get("G.b.o")!==null,'con regate el portero no la roba');
console.log('portero: OK');
